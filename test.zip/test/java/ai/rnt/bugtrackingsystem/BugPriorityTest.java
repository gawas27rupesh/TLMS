package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.BugPriority;

@ExtendWith(MockitoExtension.class)
public class BugPriorityTest {

	
	BugPriority bugPriority = new BugPriority();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	@Test
	void setterTest() {
		bugPriority.setCreatedBy(1);
		bugPriority.setCreatedDate(createdDate);
		bugPriority.setPriority("P1");
		bugPriority.setPriorityId(1);
		bugPriority.setUpdatedBy(1);
		bugPriority.setUpdatedDate(updatedDate);
	}
	@Test
	void getterTest() {
		bugPriority.getCreatedBy();
		bugPriority.getCreatedDate();
		bugPriority.getPriority();
		bugPriority.getPriorityId();
		bugPriority.getUpdatedBy();
		bugPriority.getUpdatedDate();
	}
}
