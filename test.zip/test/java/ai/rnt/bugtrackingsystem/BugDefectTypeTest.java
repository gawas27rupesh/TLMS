package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.BugDefectType;

@ExtendWith(MockitoExtension.class)
public class BugDefectTypeTest {

	//private Logger log = LoggerFactory.getLogger(RtmTest.class);
	
	BugDefectType defectType = new BugDefectType();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	
	@Test
	void setterTest() {
		defectType.setCreatedBy(1304);
		defectType.setCreatedDate(createdDate);
		defectType.setDefectType("Front End");
		defectType.setDefectTypeId(1);
		defectType.setUpdatedBy(1304);
		defectType.setUpdatedDate(updatedDate);
	}
	
	@Test
	void getterTest() {
		defectType.getCreatedBy();
		defectType.getCreatedDate();
		defectType.getDefectType();
		defectType.getDefectTypeId();
		defectType.getUpdatedBy();
		defectType.getUpdatedDate();
	}
}
