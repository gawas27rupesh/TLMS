package ai.rnt.bugtrackingsystem.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

class CheckListContainsObjectUtilTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	CheckListContainsObjectUtil checkListContainsObjectUtil;

	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(checkListContainsObjectUtil).build();
	}
	
	@Test
	void findUsingIteratorTest(){
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectName("tlms");
		List<ProjectMaster> list = new ArrayList<>();
		list.add(projectMaster);
		checkListContainsObjectUtil.findUsingIterator("tlms", list);
	}

}
