package ai.rnt.bugtrackingsystem.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.Status;

class TlmsGeneralFunctionalityImplTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	TlmsGeneralFunctionalityImpl  tlmsGeneralFunctionalityImpl;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(tlmsGeneralFunctionalityImpl).build();
	}
	@Test
	void getProjectStatusTest() {
		Status st = new Status();
		st.setStatus("yet to start");
		st.setStatusId(1);
		List<Status> status = new ArrayList<>();
		status.add(st);
		
		tlmsGeneralFunctionalityImpl.getProjectStatus(status);
	}
	@Test
	void validateUserTest() {
		UserLoginDto userData = new UserLoginDto();
		userData.setRoleName("admin");
		tlmsGeneralFunctionalityImpl.validateUser(userData);
	}
}
