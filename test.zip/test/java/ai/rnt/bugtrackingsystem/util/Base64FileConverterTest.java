package ai.rnt.bugtrackingsystem.util;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

class Base64FileConverterTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	Base64FileConverter Base64FileConverter;
	@Mock
	MultipartFile file;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(Base64FileConverter).build();
	}

	@Test
	void encodeMultipartFileTest() throws IOException {
		String name = "file.txt";
		String originalFileName = "file.txt";
		String contentType = "text/plain";
		byte[] content = null;
		MultipartFile result = new MockMultipartFile(name, originalFileName, contentType, content);
		Base64FileConverter.encodeMultipartFile(result);
	}

	@Test
	void encodeFileTest() {
		try {
			 String expected = "VGhpcyBpcyBhIHRlc3QgZmlsZQ==";
			    File file = new File("test.txt");
			    byte[] b = new byte[100];
			    file.mkdir();
			Base64FileConverter.encodeFile(file);
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	@Test
	void decodeTest() throws IOException {
		Base64FileConverter.decode("vhbjn45fcgvj");
	}
	@Test
	void converByteArrayToFileTest() throws IOException {
		File file = new File("file");
		HttpServletRequest req = new MockHttpServletRequest();
		ServletContext con = new MockServletContext();
//		con.setAttribute(, con);
		Base64FileConverter.converByteArrayToFile("vhbjn45fcgvj", req);
	}

}
