package ai.rnt.bugtrackingsystem.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class StringEncryptionImplTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	StringEncryptionImpl stringEncryptionImpl;
	
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(stringEncryptionImpl).build();
	}
	
	@Test
	void encryptPasswordTest() {
		String pwsd = "H@!!!!@#$%^&*$%^&1%02x";
		stringEncryptionImpl.encryptPassword(pwsd);
	}

}
