package ai.rnt.bugtrackingsystem.util;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.entity.BugImage;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestResult;

class ZipDownloadUtilTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	ZipDownloadUtil zipDownloadUtil;
	
	@Mock
	HttpServletResponse response;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(zipDownloadUtil).build();
	}
	
	@Test
	void downloadZipTest() {
		TestResult testResult = new TestResult();
		testResult.setTestResultId(1);
		TestCase testCase = new TestCase();
		testCase.setTestCaseId("1");
		testResult.setTestCase(testCase);
		testResult.setImageName("h");
		testResult.setResultScreenshot("output");
		List<TestResult> listOfFileNames = new ArrayList<>();
		listOfFileNames.add(testResult);
		HttpServletResponse response = new MockHttpServletResponse();
		response.setStatus(0);
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectName("tlms");
		zipDownloadUtil.downloadZip(response, listOfFileNames, projectMaster);
		zipDownloadUtil.downloadZip(response, listOfFileNames, projectMaster);
	}
	
	
	@Test
	void downloadZip1() {
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectName("tlms");
		
		Bug bug = new Bug();
		//bug.setBugId("bug");
		bug.setProjectMaster(projectMaster);
		
		BugImage bugImage = new BugImage();
		bugImage.setFileName("file");
		byte[] image = new byte[1000];
		bugImage.setImage(image);
		bugImage.setBug(bug);
		
		List<BugImage> listOfFileNames = new ArrayList<>();
		listOfFileNames.add(bugImage);
		
		
		HttpServletResponse response = new MockHttpServletResponse();
		response.setStatus(0);
		zipDownloadUtil.downloadZip1(response,listOfFileNames );
	}

}
