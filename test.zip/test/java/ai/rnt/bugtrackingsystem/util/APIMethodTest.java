package ai.rnt.bugtrackingsystem.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class APIMethodTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	APIMethod aPIMethod;	
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(aPIMethod).build();
	}
	
	@Test
	void getOtpTest() {
		String mail = "@mail.com";
		String otp = "1234";
		aPIMethod.getOtp(mail);
	}
	
	
	@Test
	void getToken() {
		String mail = "@mail.com";
		String otp = "1234";
		aPIMethod.getToken(mail, otp);
	}
	
	@Test
	void parseTokenTest() {
		String token = "g5d4d1";
		String otp = "1234";
		aPIMethod.parseToken(token);
	}
	@Test
	void getProjectListTest() {
		String token = "g5d4d1";
		Integer userId = 123;
		aPIMethod.getProjectList(userId, token);
	}
	
}
