package ai.rnt.bugtrackingsystem.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class ImageUtilsTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	ImageUtils imageUtils;
	
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(imageUtils).build();
	}
	
	@Test
	void base64ToMultipartFile() {
		imageUtils.base64ToMultipartFile("gchv,jbknm,64562");
	}

}
