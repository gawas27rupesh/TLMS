package ai.rnt.bugtrackingsystem.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.entity.RoleMaster;

class StringFunctionalityImplTest {
	
	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	StringFunctionalityImpl stringFunctionalityImpl;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(stringFunctionalityImpl).build();
	}
	
	@Test
	void getNameTest(){
		EmployeeMaster employeeData = new EmployeeMaster();
		stringFunctionalityImpl.getName(employeeData);
	}
	@Test
	void getFullNameTest(){
		String firstName = "abc";
		String lastName = "def";
		stringFunctionalityImpl.getFullName(firstName, lastName);
		stringFunctionalityImpl.getFullName(null, lastName);
	}
	@Test
	void getSingleRoleTest(){
		RoleMaster master = new RoleMaster();
		master.setEmployeeRole("tlms admin");
		List<RoleMaster> role = new ArrayList<>();
		role.add(master);
		stringFunctionalityImpl.getSingleRole(role);
	}
	@Test
	void getSingleRoleTest2(){
		RoleMaster master = new RoleMaster();
		master.setEmployeeRole("Project Manager");
		master.setRoleId(1);
		List<RoleMaster> role = new ArrayList<>();
		role.add(master);
		stringFunctionalityImpl.getSingleRole(role);
	}
	@Test
	void getSingleRoleTest3(){
		RoleMaster master = new RoleMaster();
		master.setEmployeeRole("user");
		master.setRoleId(1);
		List<RoleMaster> role = new ArrayList<>();
		role.add(master);
		stringFunctionalityImpl.getSingleRole(role);
	}
	
	@Test
	void getRoleIdTest() {
		RoleMaster master = new RoleMaster();
		master.setEmployeeRole("tlms admin");
		master.setRoleId(1);
		List<RoleMaster> role = new ArrayList<>();
		role.add(master);
		stringFunctionalityImpl.getRoleId(role);
	}
	@Test
	void getRoleIdTest2() {
		RoleMaster master = new RoleMaster();
		master.setEmployeeRole("Project Manager");
		master.setRoleId(1);
		List<RoleMaster> role = new ArrayList<>();
		role.add(master);
		stringFunctionalityImpl.getRoleId(role);
	}
	@Test
	void getRoleIdTest3() {
		RoleMaster master = new RoleMaster();
		master.setEmployeeRole("user");
		master.setRoleId(1);
		List<RoleMaster> role = new ArrayList<>();
		role.add(master);
		stringFunctionalityImpl.getRoleId(role);
	}

}
