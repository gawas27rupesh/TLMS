package ai.rnt.bugtrackingsystem.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class JsonStringUtilTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	JsonStringUtil jsonStringUtil;
	
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(jsonStringUtil).build();
	}
	
	@Test
	void splitJsonArrayTest() {
		String A = "rm_1 \", \"rm_ 2";
		String B = "rm_ 1,rm_ 1";
		String C = "rm_ 1,rm_ 1";
		String D= "rm_ 1,rm_ 1";
		
		jsonStringUtil.splitJsonArray(A, B, C, D);
	}
	
	@Test
	void splitJsonArrayRtmTest() {
		String A = "rm_ 1,rm_ 1,rm_ 1,rm_ 1 ";
		String B = "rm_ 1,rm_ 1,rm_ 1,rm_ 1 ";
		String C = "rm_1,rm_1,rm_1,rm_1";
		String D= "rm_1 \", \"rm_ 2\", \"rm_ 3\", \"rm_ 4";
		String E= "rm_ 1,rm_ 1,rm_ 1,rm_ 1 ";
		String F= "rm_ 1,rm_ 1,rm_ 1,rm_ 1 ";
		
		jsonStringUtil.splitJsonArrayRtm(A, B, C,D, E,F);
	}
	
	@Test
	void splitJsonArrayCaseTest() {
		String A = "rm_1 ` rm_ 2";
		String B = "rm_ 1,rm_ 1";
		String C = "rm_ 1,rm_ 1";
		String D= "rm_ 1,rm_ 1";
		
		jsonStringUtil.splitJsonArrayCase(B, A, C, D);
	}
	
	@Test
	void splitJsonArrayScriptTest() {
		String A = "rm_1 \", \"rm_ 2";
		String B = "rm_1 \", \"rm_ 2";
		String C = "rm_1 \", \"rm_ 2";
		String D= "rm_1 \", \"rm_ 2";
		
		jsonStringUtil.splitJsonArrayScript(A, B, C, D);
	}

	@Test
	void splitJsonArrayResultTest() {
		String A = "rm_1 \", \"rm_ 2";
		String B = "rm_1 \", \"rm_ 2";
		String C = "rm_1 \", \"rm_ 2";
		String D= "rm_1 \", \"rm_ 2";
		String E= "rm_1 \", \"rm_ 2";
		String F= "rm_1 \", \"rm_ 2";
		String G= "rm_ 1,rm_ 1";
		
		jsonStringUtil.splitJsonArrayResult(A, B, C,D, E,F,G);
	}
	
	@Test
	void splitStringTest() {
		String A = "rm_1 \", \"rm_ 2";
		jsonStringUtil.splitString(A);
	}
}
