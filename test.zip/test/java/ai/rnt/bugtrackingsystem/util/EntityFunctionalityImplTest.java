package ai.rnt.bugtrackingsystem.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.Rtm;

class EntityFunctionalityImplTest {


	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	EntityFunctionalityImpl entityFunctionalityImpl;
	
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(entityFunctionalityImpl).build();
	}
	
	@Test
	void getRtmAndTestScenarioDataTest(){
		Object[] ob = new Object[5];
		List<Object[]> rtmAndTestScenario = new ArrayList<>();
		rtmAndTestScenario.add(ob);
		entityFunctionalityImpl.getRtmAndTestScenarioData(rtmAndTestScenario);
	}
	@Test
	void getRtmExpandDataTest(){
		Integer a = 10;
		Object[] ob = new Object[10];
		ob[0] = a;
		ob[1] = a;
		List<Object[]> rtmAndTestScenario = new ArrayList<>();
		rtmAndTestScenario.add(ob);
		entityFunctionalityImpl.getRtmExpandData(rtmAndTestScenario);
	}
	
	@Test
	void getSingleRtmDataTest() {
		Rtm rtm = new Rtm();
		rtm.setReqId("1");
		entityFunctionalityImpl.getSingleRtmData(Optional.of(rtm));
	}
	
	@Test
	void getRtmAndTestScenarioListTest(){
		Object[] ob = new Object[10];
		List<Object[]> rtmAndTestScenario = new ArrayList<>();
		rtmAndTestScenario.add(ob);
		entityFunctionalityImpl.getRtmAndTestScenarioList(rtmAndTestScenario);
	}

}
