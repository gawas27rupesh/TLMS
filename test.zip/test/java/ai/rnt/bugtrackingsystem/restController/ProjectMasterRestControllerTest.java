package ai.rnt.bugtrackingsystem.restController;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.dto.ProjectTeamDto;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;

class ProjectMasterRestControllerTest {

	@Autowired
	MockMvc mockMvc;
	
	@Mock
	ProjectMasterService project;

	@Mock
	ProjectTeamService projectTeamService;
	
	@Mock
	BugService bugService; 
	
	@InjectMocks
	ProjectMasterRestController projectMasterRestController;
	
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(projectMasterRestController).build();
	}
	
	@Test
	void findAllTest() {
		projectMasterRestController.findAll();
	}
	@Test
	void findByIdTest() {
		ProjectMaster projectMaster = new ProjectMaster();
		when(project.findById(1)).thenReturn(projectMaster);
		when(bugService.findBugCount(1)).thenReturn(1);
		projectMasterRestController.findById(1);
	}
	@Test
	void getProjectDataByClientIdTest() {
		//when(project.getProjectDataByClientId(1)).thenReturn(null);
		projectMasterRestController.getProjectDataByClientId(1);
	}
	@Test
	void getTesterRoleTest() {
		ProjectTeamDto projectTeamDto = new ProjectTeamDto();
		projectTeamDto.setRole("tester");
		List<ProjectTeamDto> project = new ArrayList<>();
		project.add(projectTeamDto);
		when(projectTeamService.findProjectTesterByProjectId(1)).thenReturn(project);
		projectMasterRestController.getTesterRole(1);
	}

}
