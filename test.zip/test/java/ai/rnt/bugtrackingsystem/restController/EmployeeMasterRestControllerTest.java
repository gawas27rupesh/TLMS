package ai.rnt.bugtrackingsystem.restController;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.service.EmployeeMasterService;
import ai.rnt.bugtrackingsystem.util.StringFunctionality;

class EmployeeMasterRestControllerTest {

	@Autowired
	MockMvc mockMvc;

	@Mock
	EmployeeMasterService employee;

	@Mock
	StringFunctionality stringFunctionality;

	@InjectMocks
	EmployeeMasterRestController employeeMasterRestController;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(employeeMasterRestController).build();
	}

	@Test
	void getEmployeeNameTest() {
		EmployeeMaster employeeData = new EmployeeMaster();
		when(employee.findById(1)).thenReturn(employeeData);
		when(stringFunctionality.getName(employeeData)).thenReturn("data");
		employeeMasterRestController.getEmployeeName(1);
	}

}
