package ai.rnt.bugtrackingsystem.restController;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.service.ClientMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;

class ClientMasterRestControllerTest {

	@Autowired
	MockMvc mockMvc;
	
	@Mock
 ClientMasterService client;
	
	@Mock
	ProjectMasterService project;
	
	@InjectMocks
	ClientMasterRestController clientMasterRestController;
	
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(clientMasterRestController).build();
	}
	
	@Test
	void getClientNameByProjectIdTest() {
		ClientMaster clientMaster = new ClientMaster();
		clientMaster.setCompanyName("RNT");
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setClientmaster(clientMaster);
		when(project.findById(1)).thenReturn(projectMaster);
		clientMasterRestController.getClientNameByProjectId(1);
	}
	
	@Test
	void findByProjectIdTest() {
		ClientMaster clientMaster = new ClientMaster();
		clientMaster.setCompanyName("RNT");
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setClientmaster(clientMaster);
		when(project.findById(1)).thenReturn(projectMaster);
		clientMasterRestController.findByProjectId(1);
	}
	@Test
	void findByProjectIdTest2() {
		ClientMaster clientMaster = new ClientMaster();
		clientMaster.setCompanyName("RNT");
		ProjectMaster projectMaster = new ProjectMaster();
		//projectMaster.setClientmaster(clientMaster);
		when(project.findById(1)).thenReturn(projectMaster);
		clientMasterRestController.findByProjectId(1);
	}
	@Test
	void findByProjectIdTest3() {
		ClientMaster clientMaster = new ClientMaster();
		clientMaster.setCompanyName("");
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setClientmaster(clientMaster);
		when(project.findById(1)).thenReturn(projectMaster);
		clientMasterRestController.findByProjectId(1);
	}

}
