package ai.rnt.bugtrackingsystem.entity;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import ai.rnt.bugtrackingsystem.repository.ProjectMasterRpository;

class ProjectMasterTest {

	private Logger log = LoggerFactory.getLogger(ProjectMasterTest.class);

	@Autowired
	private ProjectMasterRpository projectMaster;

	@Autowired
	EntityManager entityManager;
	
	ProjectMaster projectMaster1 = new ProjectMaster();
	
	@Test
	public void setterTest() {
		projectMaster1.setBug(null);
		projectMaster1.setClientmaster(null);
		projectMaster1.setEfforts(null);
		projectMaster1.setEffortsUnit(null);
		projectMaster1.setEndDate(null);
		projectMaster1.setEngagementModel(null);
		projectMaster1.setExecutionModel(null);
		projectMaster1.setPercentOfAllocationOfManager(null);
		projectMaster1.setProjectID(null);
		projectMaster1.setProjectManager(null);
		projectMaster1.setProjectName(null);
		projectMaster1.setProjectPhase(null);
		projectMaster1.setProjectStatus(null);
		projectMaster1.setProjectTeam(null);
		projectMaster1.setRtm(null);
		projectMaster1.setServiceId(null);
		projectMaster1.setSOWSigned(null);
		projectMaster1.setStartDate(null);
		projectMaster1.setTestCase(null);
		projectMaster1.setTestResult(null);
		projectMaster1.setTestScenarios(null);
		projectMaster1.setTestScript(null);
		projectMaster1.setCreatedBy(null);
		projectMaster1.setCreatedDate(null);
		projectMaster1.setUpdatedBy(null);
		projectMaster1.setUpdatedDate(null);
		projectMaster1.setDeletedBy(null);
		projectMaster1.setDeletedDate(null);
	}
	
	@Test
	public void getterTest() {
		projectMaster1.getBug();
		projectMaster1.getClientmaster();
		projectMaster1.getEfforts();
		projectMaster1.getEffortsUnit();
		projectMaster1.getEndDate();
		projectMaster1.getEngagementModel();
		projectMaster1.getExecutionModel();
		projectMaster1.getPercentOfAllocationOfManager();
		projectMaster1.getProjectID();
		projectMaster1.getProjectManager();
		projectMaster1.getProjectName();
		projectMaster1.getProjectPhase();
		projectMaster1.getProjectStatus();
		projectMaster1.getProjectTeam();
		projectMaster1.getRtm();
		projectMaster1.getServiceId();
		projectMaster1.getSOWSigned();
		projectMaster1.getStartDate();
		projectMaster1.getTestCase();
		projectMaster1.getTestResult();
		projectMaster1.getTestScenarios();
		projectMaster1.getTestScript();
		projectMaster1.getCreatedBy();
		projectMaster1.getCreatedDate();
		projectMaster1.getUpdatedBy();
		projectMaster1.getUpdatedDate();
		projectMaster1.getDeletedBy();
		projectMaster1.getDeletedDate();
	}

}
