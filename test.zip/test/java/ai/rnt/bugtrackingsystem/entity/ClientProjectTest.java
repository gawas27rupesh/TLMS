package ai.rnt.bugtrackingsystem.entity;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ClientProjectTest {

	private Logger log = LoggerFactory.getLogger(ClientProjectTest.class);
	ClientProject clientProject = new ClientProject();
	List<ClientMaster> clientMaster = new ArrayList<ClientMaster>();
	List<ProjectMaster> projectMaster = new ArrayList<ProjectMaster>();
//	@Test
//	void setterTest() {
//		clientProject.setcList(clientMaster);
//		clientProject.setpList(projectMaster);
//	}
//	
//	@Test
//	void getterTest() {
//		clientProject.getcList();
//		clientProject.getpList();
//	}

}
