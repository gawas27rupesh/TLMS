package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.TestScript;

@ExtendWith(MockitoExtension.class)
public class TestScriptTest {

	private static final LocalDateTime LocalDateTime = null;
	TestScript testScript = new TestScript();
	
	@Test
	public void testScript() {
		testScript.setTestScriptId(1);
		testScript.setTestCaseName("type orignal name");
		testScript.setDragAndDropArr(2);
		testScript.setExpectedResult("NA");
		testScript.setInputData("Enter user name and password");
		testScript.setScriptStepDesc("Step Description");
		testScript.setCreatedBy(1380);
		testScript.setSheetstatus(null);
		testScript.setTestResult(null);
		testScript.setRtm(null);
	    testScript.setTestCase(null);
	    testScript.setProjectMaster(null);
	    testScript.setUpdatedBy(1380);
	    testScript.setTestScenario(null);
	    testScript.setStep_no(1);
        testScript.setCreatedDate(LocalDateTime);
        testScript.setUpdatedDate(LocalDateTime);
	
	}
	
	
	@SuppressWarnings("static-access")
	@Test
	public void getTestScript() {
		testScript.getTestScriptId();
		testScript.getTestCaseName();
		testScript.getDragAndDropArr();
		testScript.getExpectedResult();
		testScript.getInputData();
		testScript.getScriptStepDesc();
		testScript.getCreatedBy();
		testScript.getSheetstatus();
		testScript.getTestResult();
		testScript.getRtm();
		testScript.getTestCase();
		testScript.getProjectMaster();
		testScript.getUpdatedBy();
		testScript.getTestScenario();
		testScript.getStep_no();
		testScript.getCreatedDate();
		testScript.getUpdatedDate();
	
	}
}
