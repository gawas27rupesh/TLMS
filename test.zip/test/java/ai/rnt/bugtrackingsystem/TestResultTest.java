package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectTeam;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.Status;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestResult;
import ai.rnt.bugtrackingsystem.entity.TestScenario;
import ai.rnt.bugtrackingsystem.entity.TestScript;

@ExtendWith(MockitoExtension.class)
public class TestResultTest {

	private static final LocalDateTime LocalDateTime = null;
	TestResult testResult = new TestResult();
	Status status = new Status();
	TestScenario testScenario = new TestScenario();
	Rtm rtm = new Rtm();
	TestCase testCase = new TestCase();
	TestScript testScript = new TestScript();
	ProjectMaster projectMaster = new ProjectMaster();
	ProjectTeam projectTeam = new ProjectTeam();

	@Test
	public void testResult() {
		testResult.setTestResultId(1);
		testResult.setActualResult("NA");
		testResult.setResultStatus("Pass");
		testResult.setResultScreenshot("Screenshot.png");
		testResult.setCreatedDate(LocalDateTime);
		testResult.setUpdatedBy(1380);
		testResult.setUpdatedDate(LocalDateTime);
		testResult.setImageName("Screenshot.png");
		testResult.setSheetstatus(status);
		testResult.setTestScenario(testScenario);
		testResult.setRtm(rtm);
		testResult.setTestCase(testCase);
		testResult.setTestScript(testScript);
		testResult.setProjectTeam(projectTeam);
		testResult.setProjectMaster(projectMaster);

	}

	@Test
	public void getTestResult() {
		testResult.getTestResultId();
		testResult.getActualResult();
		testResult.getResultStatus();
		testResult.getResultScreenshot();
		testResult.getCreatedDate();
		testResult.getUpdatedBy();
		testResult.getUpdatedDate();
		testResult.getImageName();
		testResult.getTestScenario();
		testResult.getProjectMaster();
		testResult.getRtm();
		testResult.getTestCase();
		testResult.getProjectTeam();
		testResult.getPhoto();
		testResult.getTestScript();
		testResult.getSheetstatus();
		testResult.toString();
	}
	
	@Test
	public void testTestResultConstructor() {
		String actualResult = "result";
		String resultStatus = "pass";
		Byte[] resultScreenshot = {1,2,3};
		Integer testedBy = 1;
		Integer createdBy = null;
		String createdDate = null;
		Integer updatedBy = null;
		String updatedDate = null;
		Integer deletedBy = null;
		String deletedDate = null ;
		
//		TestResult testResult = new TestResult(actualResult, resultStatus, resultScreenshot, testedBy,
//				createdBy, createdDate, updatedBy, updatedDate, deletedBy,
//				deletedDate);
//		
//		assertEquals(actualResult, testResult.getActualResult());
//		assertEquals(resultStatus, testResult.getResultStatus());
//		assertEquals(createdBy, testResult.getCreatedBy());
//		assertEquals(createdDate, testResult.getCreatedDate());
//		assertEquals(updatedBy, testResult.getUpdatedBy());
//		assertEquals(updatedDate, testResult.getUpdatedDate());
	}
}
