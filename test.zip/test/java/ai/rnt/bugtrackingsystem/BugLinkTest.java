package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.entity.BugLink;

@ExtendWith(MockitoExtension.class)
public class BugLinkTest {
	private Logger log = LoggerFactory.getLogger(RtmTest.class);
	BugLink bugLink = new BugLink();
	Bug bug = new Bug();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	
	@Test
	void setterTest() {
		bugLink.setBug(bug);
		bugLink.setBugLink("abc");
		bugLink.setCreatedBy(1);
		bugLink.setCreatedDate(createdDate);
		bugLink.setUpdatedBy(1);
		bugLink.setUpdatedDate(updatedDate);
	}
	
	@Test
	void getterTest() {
		bugLink.getBug();
		bugLink.getBugLink();
		bugLink.getCreatedBy();
		bugLink.getCreatedDate();
		bugLink.getUpdatedBy();
		bugLink.getUpdatedDate();
		bugLink.getLinkId();
	}
}
