package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.StatusByTester;

@ExtendWith(MockitoExtension.class)
public class StatusByTesterTest {
	//private Logger log = LoggerFactory.getLogger(RtmTest.class);
	StatusByTester statusByTester = new StatusByTester();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;

	@Test
	void setterTest() {
		statusByTester.setCreatedBy(1);
		statusByTester.setCreatedDate(createdDate);
		statusByTester.setStatusByTester("Open");
		statusByTester.setStatusTesterId(1);
		statusByTester.setUpdatedBy(1);
		statusByTester.setUpdatedDate(updatedDate);
	}

	@Test
	void getterTest() {
		statusByTester.getCreatedBy();
		statusByTester.getCreatedDate();
		statusByTester.getStatusByTester();
		statusByTester.getStatusTesterId();
		statusByTester.getUpdatedBy();
		statusByTester.getUpdatedDate();
	}
}
