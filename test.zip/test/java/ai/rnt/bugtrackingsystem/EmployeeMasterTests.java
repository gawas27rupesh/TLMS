/*
 * package ai.rnt.bugtrackingsystem;
 * 
 * import java.math.BigInteger; import java.security.MessageDigest; import
 * java.security.NoSuchAlgorithmException;
 * 
 * import javax.persistence.EntityManager; import javax.persistence.Query;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.junit.jupiter.api.extension.ExtendWith; import
 * org.mockito.junit.jupiter.MockitoExtension; import org.slf4j.Logger; import
 * org.slf4j.LoggerFactory; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * import ai.rnt.bugtrackingsystem.entity.EmployeeMaster; import
 * ai.rnt.bugtrackingsystem.service.EmployeeMasterService;
 * 
 *//**
	 * @author Pankaj Chauhan
	 * @Date 25th July 2022
	 * @version 1.0
	 *//*
		 * @ExtendWith(MockitoExtension.class)
		 * 
		 * @SpringBootTest public class EmployeeMasterTests {
		 * 
		 * private Logger log = LoggerFactory.getLogger(EmployeeMasterTests.class);
		 * 
		 * @Autowired private EmployeeMasterService employeeMaster;
		 * 
		 * @Autowired EntityManager entityManager;
		 * 
		 * EmployeeMaster empMaster = new EmployeeMaster();
		 * 
		 * @Test void checkUserAndPassword() { EmployeeMaster emp =
		 * employeeMaster.findByUserIdAndPassword("p.cauhan@rnt.ai",
		 * encryptThisString("RNT123")); System.out.println("Hello: " + emp);
		 * log.info("Emp: {}", emp); }
		 * 
		 * // using native query
		 * 
		 * 
		 * @Test void checkEmailAndPassword() { Query query =
		 * entityManager.createNativeQuery(
		 * "select * from employee_master emp where emp.email_id = ? and emp.password= ?"
		 * , EmployeeMaster.class); query.setParameter(1, "p.chauhan@rnt.ai");
		 * query.setParameter(2, encryptThisString("RNT123")); EmployeeMaster emp =
		 * (EmployeeMaster) query.getSingleResult(); log.info(" {} ", emp); }
		 * 
		 * public static String encryptThisString(String input) { try { // getInstance()
		 * // method is called with algorithm SHA-1 MessageDigest md =
		 * MessageDigest.getInstance("SHA-1");
		 * 
		 * // digest() method is called // to calculate message digest of the input //
		 * string returned as array of byte byte[] messageDigest =
		 * md.digest(input.getBytes());
		 * 
		 * // Convert byte array into signum representation BigInteger no = new
		 * BigInteger(1, messageDigest);
		 * 
		 * // Convert message digest into hex value String hashtext = no.toString(16);
		 * 
		 * // Add preceding 0s to make it 32 bit while (hashtext.length() < 32) {
		 * hashtext = "0" + hashtext; }
		 * 
		 * // return the HashText return hashtext; }
		 * 
		 * // For specifying wrong message digest algorithms catch
		 * (NoSuchAlgorithmException e) { throw new RuntimeException(e); } }
		 * 
		 * @Test public void setterTest() { empMaster.setFirstName(null);
		 * empMaster.setLastName(null); empMaster.setMiddleName(null);
		 * empMaster.setEmailID(null); empMaster.setPassword(null);
		 * empMaster.setDesignation(null); empMaster.setEmployeeJobTitle(null);
		 * empMaster.setEmployeeRole(null); empMaster.setProjectTeam(null);
		 * empMaster.setRole(null); }
		 * 
		 * @Test public void getterTest() { empMaster.getFirstName();
		 * empMaster.getLastName(); empMaster.getMiddleName(); empMaster.getEmailID();
		 * empMaster.getPassword(); empMaster.getDesignation();
		 * empMaster.getEmployeeJobTitle(); empMaster.getEmployeeRole();
		 * empMaster.getProjectTeam(); empMaster.getRole(); empMaster.getManagerID();
		 * empMaster.getStaffId(); empMaster.getUserID(); empMaster.toString(); }
		 * 
		 * 
		 * }
		 */