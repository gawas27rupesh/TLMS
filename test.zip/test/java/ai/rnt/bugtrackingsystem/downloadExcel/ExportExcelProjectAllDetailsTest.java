package ai.rnt.bugtrackingsystem.downloadExcel;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class ExportExcelProjectAllDetailsTest{

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	ExportExcelProjectAllDetails exportExcelProjectAllDetails;
	
	Workbook workbook;
	
	@Mock
	HttpServletRequest request;
	
	@Mock
	Sheet sheet7;
	
	@Mock
	HttpServletResponse response;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(exportExcelProjectAllDetails).build();
	}

	
	
}
