package ai.rnt.bugtrackingsystem.downloadExcel;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import ai.rnt.bugtrackingsystem.dto.TestScriptDto;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

@ExtendWith(MockitoExtension.class)
class ExcelReportViewForTestScriptTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	ExcelReportViewForTestScript excelReportViewForTestScript;	
	
	@Mock
	HttpServletRequest request;
	
	@Mock
	Sheet sheet;
	
	@Mock
	HttpServletResponse response;
	
	@Test
	void buildExcelDocumentTest() throws Exception {
		Workbook workbook = new HSSFWorkbook();
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> TesterList = new ArrayList<>();
		List<TestScriptDto> tscdList = new ArrayList<>();

		// remove me
		TesterList.add("Tlms");
		
		ProjectMaster projectMaster = new ProjectMaster();
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
		
		// remove me
		ClientMaster clientMaster =new ClientMaster();
		projectMaster.setClientmaster(clientMaster);
		
		TestScriptDto testScriptDto = new TestScriptDto();
		testScriptDto.setRequirementId("br2");
		testScriptDto.setTestCaseName("test");
		testScriptDto.setStepNo(10);
		testScriptDto.setStepDesc("test");
		testScriptDto.setInputData("test");
		testScriptDto.setExpectedResult("test");
		tscdList.add(testScriptDto);
		
		map.put("headerData", projectMaster);
		map.put("testerName", TesterList);
		map.put("list", tscdList);
		map.put("status", "completed");
		excelReportViewForTestScript.buildExcelDocument(map, workbook, request, response);;
	}
	@Test
	void buildExcelDocumentTest2() throws Exception {
		Workbook workbook = new HSSFWorkbook();
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> TesterList = new ArrayList<>();
		List<TestScriptDto> tscdList = new ArrayList<>();
		
		
		ProjectMaster projectMaster = new ProjectMaster();
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
		
		
		TestScriptDto testScriptDto = new TestScriptDto();
		testScriptDto.setRequirementId("br2");
		testScriptDto.setTestCaseName("test");
		testScriptDto.setStepNo(10);
		testScriptDto.setStepDesc("test");
		testScriptDto.setInputData("test");
		testScriptDto.setExpectedResult("test");
		tscdList.add(testScriptDto);
		
		map.put("headerData", projectMaster);
		map.put("testerName", TesterList);
		map.put("list", tscdList);
		map.put("status", null);
		excelReportViewForTestScript.buildExcelDocument(map, workbook, request, response);
	}

}
