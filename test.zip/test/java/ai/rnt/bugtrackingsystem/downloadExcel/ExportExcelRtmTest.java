package ai.rnt.bugtrackingsystem.downloadExcel;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.dto.RtmDto;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

class ExportExcelRtmTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	ExportExcelRtm exportExcelRtm;	
	@Mock
	HttpServletRequest request;
	
	@Mock
	Sheet sheet;
	
	@Mock
	HttpServletResponse response;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(exportExcelRtm).build();
	}
	
	@Test
	void buildExcelDocumentTest() throws Exception {
		Workbook workbook = new HSSFWorkbook();
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> TesterList = new ArrayList<>();
		List<RtmDto> Rtmlist = new ArrayList<>();
		
		
		TesterList.add("Ram");
		ProjectMaster projectMaster = new ProjectMaster();
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
		ClientMaster clientMaster =new ClientMaster();
		projectMaster.setClientmaster(clientMaster);
		
		
		RtmDto rtmDto = new RtmDto();
		rtmDto.setBrIdString("&apos;");
		rtmDto.setRequirementId("&apos;");
		rtmDto.setRequirement("&apos;");
		rtmDto.setRequirementDesc("&apos;");
		Rtmlist.add(rtmDto);
		
		map.put("headerData", projectMaster);
		map.put("projectId", 1);
		map.put("testerName", TesterList);
		map.put("list", Rtmlist);
		
		map.put("status", "completed");
		exportExcelRtm.buildExcelDocument(map, workbook, request, response);
	}
	
	
	

}
