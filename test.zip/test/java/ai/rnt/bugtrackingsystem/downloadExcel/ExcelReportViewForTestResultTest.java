package ai.rnt.bugtrackingsystem.downloadExcel;

import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.dto.TestResultDto;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

class ExcelReportViewForTestResultTest {

	@Autowired
	MockMvc mockMvc;
	
	@InjectMocks
	ExcelReportViewForTestResult excelReportViewForTestResult;
	
	Workbook workbook;
	
	@Mock
	HttpServletRequest request;
	
	@Mock
	Sheet sheet;
	
	@Mock
	HttpServletResponse response;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(excelReportViewForTestResult).build();
	}
	
	
	@Test
	void buildExcelDocumentTest2() throws Exception {
		Workbook workbook = new HSSFWorkbook();
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> TesterList = new ArrayList<>();
		List<TestResultDto> trdList = new ArrayList<>();
		
		//TesterList.add("Gns");
		
		ProjectMaster projectMaster = new ProjectMaster();
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
		ClientMaster clientMaster =new ClientMaster();
		projectMaster.setClientmaster(clientMaster);
		
		TestResultDto testResultDto = new TestResultDto();
		testResultDto.setReqId("br1");
		testResultDto.setStep_no(1);
		testResultDto.setScreenshot("hi");
		testResultDto.setTestCaseName("&apos;");
		testResultDto.setTestDesc("&apos;");
		testResultDto.setInputData("&apos;");
		testResultDto.setExpectedResult("&apos;");
		testResultDto.setActualResult("&apos;");
		trdList.add(testResultDto);
		
		
		when(request.getRequestURL()).thenReturn(new StringBuffer("Data"));
		map.put("headerData", projectMaster);
		map.put("testerName", TesterList);
		map.put("list", trdList);
		
		map.put("projectId", 1);
		map.put("status", "in progress");
		excelReportViewForTestResult.buildExcelDocument(map, workbook, request, response);
	}
}
