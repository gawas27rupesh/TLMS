package ai.rnt.bugtrackingsystem.downloadExcel;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.dto.SummaryDto;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

class ExportToExcelSummaryTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	ExportToExcelSummary exportToExcelSummary;
	
	@Mock
	HttpServletRequest request;

	@Mock
	HttpServletResponse response;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(exportToExcelSummary).build();
	}
	
	@Test
	void buildExcelDocumentTest() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		Workbook workbook = new HSSFWorkbook();
		ProjectMaster projectMaster = new ProjectMaster();
		List<SummaryDto> summaryList = new ArrayList<>();
		
		
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
		projectMaster.setProjectStatus('H');
		ClientMaster clientMaster = new ClientMaster();
		projectMaster.setClientmaster(clientMaster);
		
		SummaryDto summarydto = new SummaryDto();
		summarydto.setReqId("1");
		BigDecimal big = BigDecimal.ONE;
		BigInteger big1 = BigInteger.ONE;
		summarydto.setClosed(big);
		summarydto.setOpen(big);
		summarydto.setReopen(big);
		summarydto.setTotal(big1);;
		summaryList.add(summarydto);
		
		
		map.put("headerData", projectMaster);
		map.put("status", "completed");
		map.put("summary", summaryList);
		map.put("closeTotal", 1);
		map.put("openTotal", 1);
		map.put("reopenTotal", 1);
		map.put("allTotal", 1);
		exportToExcelSummary.buildExcelDocument(map, workbook, request, response);
	}
	@Test
	void buildExcelDocumentTest2() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		Workbook workbook = new HSSFWorkbook();
		ProjectMaster projectMaster = new ProjectMaster();
		List<SummaryDto> summaryList = new ArrayList<>();
		
		
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
		projectMaster.setProjectStatus('H');
//		ClientMaster clientMaster = new ClientMaster();
//		projectMaster.setClientmaster(clientMaster);
		
		SummaryDto summarydto = new SummaryDto();
		summarydto.setReqId("1");
		BigDecimal big = BigDecimal.ONE;
		BigInteger big1 = BigInteger.ONE;
		summarydto.setClosed(big);
		summarydto.setOpen(big);
		summarydto.setReopen(big);
		summarydto.setTotal(big1);;
		summaryList.add(summarydto);
		
		
		map.put("headerData", projectMaster);
		map.put("status", "completed");
		map.put("summary", summaryList);
		map.put("closeTotal", 1);
		map.put("openTotal", 1);
		map.put("reopenTotal", 1);
		map.put("allTotal", 1);
		exportToExcelSummary.buildExcelDocument(map, workbook, request, response);
	}

}
