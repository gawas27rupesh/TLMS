package ai.rnt.bugtrackingsystem.downloadExcel;

import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.entity.BugImage;
import ai.rnt.bugtrackingsystem.entity.BugLink;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

class ExportToExcelProjectBugsTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	ExportToExcelProjectBugs exportToExcelProjectBugs;

	@Mock
	HttpServletRequest request;

	@Mock
	Sheet sheet7;

	@Mock
	HttpServletResponse response;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(exportToExcelProjectBugs).build();
	}

	@Test
	void buildExcelDocumentTest() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		Workbook workbook = new HSSFWorkbook();
		List<Bug> bugList = new ArrayList<>();
		List<String> createdByName = new ArrayList<>();
		List<BugLink> bugLinksList = new ArrayList<>();
		List<BugImage> imageList = new ArrayList<>();
		ProjectMaster projectMaster = new ProjectMaster();
		

		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");

		// remove me
		ClientMaster clientMaster = new ClientMaster();
		projectMaster.setClientmaster(clientMaster);
		
		Bug bug = new Bug();
		//bug.setBugId("br");
		EmployeeMaster employeeMaster = new EmployeeMaster();
		employeeMaster.setFirstName("Ganesh");
		bug.setEmployeeMaster(employeeMaster);
		
		BugLink bugLink = new BugLink();
		bugLink.setUpdatedBy(1);
		bugLink.setBugLink("H");
		bugLinksList.add(bugLink);
		bug.setBugLink(bugLinksList);
		
		BugImage bugImage = new BugImage();
		bugImage.setFileName("image.jpg");
		imageList.add(bugImage);
		//bug.setBugImage(imageList);
		bugList.add(bug);
		
		createdByName.add("Test");
		
		map.put("headerData", projectMaster);
		map.put("Export_bugList", bugList);
		map.put("createdByName", createdByName);
		when(request.getRequestURL()).thenReturn(new StringBuffer("Data"));
		exportToExcelProjectBugs.buildExcelDocument(map, workbook, request, response);
	}
	

}
