package ai.rnt.bugtrackingsystem.downloadExcel;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.entity.BusinessRequirement;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

class ExportToExcelBrTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	ExportToExcelBr exportToExcelBr;
	
	@Mock
	HttpServletRequest request;

	@Mock
	HttpServletResponse response;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(exportToExcelBr).build();
	}

	@Test
	void buildExcelDocumentTest() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		Workbook workbook = new HSSFWorkbook();
		ProjectMaster projectMaster = new ProjectMaster();
		List<String> TesterList = new ArrayList<>();
		List<BusinessRequirement> brList = new ArrayList<>();

		TesterList.add("Ram");
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
		ClientMaster clientMaster = new ClientMaster();
		projectMaster.setClientmaster(clientMaster);

		BusinessRequirement brq = new BusinessRequirement();
		brq.setBrIdString("brId");
		brq.setBrName("Br");
		brq.setBrDescription("desc");
		brList.add(brq);

		map.put("headerData", projectMaster);
		map.put("status", "completed");
		map.put("testerName", TesterList);
		map.put("projectId", 1);
		map.put("brListExport", brList);
		exportToExcelBr.buildExcelDocument(map, workbook, request, response);

	}

	@Test
	void buildExcelDocumentTest2() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		Workbook workbook = new HSSFWorkbook();
		ProjectMaster projectMaster = new ProjectMaster();
		List<String> TesterList = new ArrayList<>();
		List<BusinessRequirement> brList = new ArrayList<>();

		// TesterList.add("Ram");
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");
//		ClientMaster clientMaster =new ClientMaster();
//		projectMaster.setClientmaster(clientMaster);

		BusinessRequirement brq = new BusinessRequirement();
		brq.setBrIdString("brId");
		brq.setBrName("Br");
		brq.setBrDescription("desc");
		brList.add(brq);

		map.put("headerData", projectMaster);
		map.put("status", null);
		map.put("testerName", TesterList);
		map.put("projectId", 1);
		map.put("brListExport", brList);
		exportToExcelBr.buildExcelDocument(map, workbook, request, response);

	}

}
