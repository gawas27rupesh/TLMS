package ai.rnt.bugtrackingsystem.downloadExcel;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import ai.rnt.bugtrackingsystem.dto.TestScenarioDto;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

class ExportToExcelTestScenarioTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	ExportToExcelTestScenario exportToExcelTestScenario;
	@Mock
	HttpServletRequest request;

	@Mock
	Sheet sheet;

	@Mock
	HttpServletResponse response;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(exportToExcelTestScenario).build();
	}

	@Test
	void buildExcelDocumentTest() throws Exception {
		Workbook workbook = new HSSFWorkbook();
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> TesterList = new ArrayList<>();
		List<TestScenarioDto> tsdList = new ArrayList<>();
		
		// remove me
		TesterList.add("Tlms");

		ProjectMaster projectMaster = new ProjectMaster();
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");

		// remove me
		ClientMaster clientMaster = new ClientMaster();
		projectMaster.setClientmaster(clientMaster);

		TestScenarioDto testSd = new TestScenarioDto();
		testSd.setTestScenarioDescription("&apos;");
		testSd.setRequirement("1");
		tsdList.add(testSd);
		
		map.put("headerData", projectMaster);
		map.put("testerName", TesterList);
		map.put("list", tsdList);
		map.put("status", "completed");
		
		exportToExcelTestScenario.buildExcelDocument(map, workbook, request, response);
	}
	
	@Test
	void buildExcelDocumentTest2() throws Exception {
		Workbook workbook = new HSSFWorkbook();
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> TesterList = new ArrayList<>();
		List<TestScenarioDto> tsdList = new ArrayList<>();
		

		ProjectMaster projectMaster = new ProjectMaster();
		LocalDateTime date = LocalDateTime.MAX;
		projectMaster.setStartDate(date);
		projectMaster.setEndDate(date);
		projectMaster.setProjectName("tlms");


		TestScenarioDto testSd = new TestScenarioDto();
		testSd.setTestScenarioDescription("&apos;");
		testSd.setRequirement("1");
		tsdList.add(testSd);
		
		map.put("headerData", projectMaster);
		map.put("testerName", TesterList);
		map.put("list", tsdList);
		map.put("status", null);
		
		exportToExcelTestScenario.buildExcelDocument(map, workbook, request, response);
	}

}
