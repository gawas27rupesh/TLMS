
package ai.rnt.bugtrackingsystem;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.ClientMaster;

/**
 * @author Pankaj Chauhan
 * @Date 25th July 202
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
//@SpringBootTest
public class ClientMasterTest {

	private Logger log = LoggerFactory.getLogger(ClientMasterTest.class);
	ClientMaster clientMaster1 = new ClientMaster();

	@Test
	 void setterTest() {
		clientMaster1.setAccountNo(null);
		clientMaster1.setAddress(null);
		clientMaster1.setAwsImgUrl(null);
		clientMaster1.setCompanyName(null);
		clientMaster1.setContactPersonMobileNumber(null);
		clientMaster1.setContactPersonName(null);
		clientMaster1.setContactPersonNumber(null);
		clientMaster1.setCreatedBy(null);
		clientMaster1.setCreatedDate(null);
		clientMaster1.setCustomerCode(null);
		clientMaster1.setDeletedBy(null);
		clientMaster1.setDeletedDate(null);
		clientMaster1.setDomainName(null);
		clientMaster1.setEmailId(null);
		clientMaster1.setGSTIN(null);
		clientMaster1.setInternalNotes(null);
		clientMaster1.setLastName(null);
		clientMaster1.setLocationId(null);
		clientMaster1.setOfficeContactNumber(null);
		clientMaster1.setPAN(null);
		clientMaster1.setStartDate(null);
		clientMaster1.setTechnology(null);
		clientMaster1.setUpdatedBy(null);
		clientMaster1.setUpdatedDate(null);
		clientMaster1.setWebsite(null);
		clientMaster1.setCustomerStatus('a');
		clientMaster1.setMSASigned('b');
		clientMaster1.setNDASigned('v');
	}

	@Test
	 void getterTest() {
		clientMaster1.getAccountNo();
		clientMaster1.getAddress();
		clientMaster1.getAwsImgUrl();
		clientMaster1.getCompanyName();
		clientMaster1.getContactPersonMobileNumber();
		clientMaster1.getContactPersonName();
		clientMaster1.getContactPersonNumber();
		clientMaster1.getCreatedBy();
		clientMaster1.getCreatedDate();
		clientMaster1.getCustomerCode();
		clientMaster1.getDeletedBy();
		clientMaster1.getDeletedDate();
		clientMaster1.getDomainName();
		clientMaster1.getEmailId();
		clientMaster1.getGSTIN();
		clientMaster1.getInternalNotes();
		clientMaster1.getLastName();
		clientMaster1.getLocationId();
		clientMaster1.getOfficeContactNumber();
		clientMaster1.getPAN();
		clientMaster1.getStartDate();
		clientMaster1.getTechnology();
		clientMaster1.getUpdatedBy();
		clientMaster1.getUpdatedDate();
		clientMaster1.getWebsite();
		clientMaster1.getCustomerStatus();
		clientMaster1.getMSASigned();
		clientMaster1.getNDASigned();
		clientMaster1.getCustomerID();
		clientMaster1.getProjectMaster();
		clientMaster1.toString();

	}

//	@Test
//	void testClientMaster() {
//		ClientMaster cm = new ClientMaster("companyName", "customerCode", "domainName", "officeContactNumber",
//				"contactPersonName", "contactPersonNumber", "contactPersonMobileNumber", "emailId", "website", 1,
//				new Date(0), "technology", 'M', 'N', 'C', "address", "lastName", "accountNo", "gSTIN", "pAN",
//				"internalNotes", 1, new Date(0), 1, new Date(0), "deletedBy", new Date(0), "awsImgUrl");
//
//		assertEquals("companyName", cm.getCompanyName());
//		assertEquals("customerCode", cm.getCustomerCode());
//		assertEquals("domainName", cm.getDomainName());
//		assertEquals("officeContactNumber", cm.getOfficeContactNumber());
//		assertEquals("contactPersonName", cm.getContactPersonName());
//		assertEquals("contactPersonNumber", cm.getContactPersonNumber());
//		assertEquals("contactPersonMobileNumber", cm.getContactPersonMobileNumber());
//		assertEquals("emailId", cm.getEmailId());
//		assertEquals("website", cm.getWebsite());
//		assertEquals(1, cm.getLocationId());
//		assertNotNull(cm.getStartDate());
//		assertEquals("technology", cm.getTechnology());
//		assertEquals('M', cm.getMSASigned());
//		assertEquals('N', cm.getNDASigned());
//		assertEquals('C', cm.getCustomerStatus());
//		assertEquals("address", cm.getAddress());
//		assertEquals("lastName", cm.getLastName());
//		assertEquals("accountNo", cm.getAccountNo());
//		assertEquals("gSTIN", cm.getGSTIN());
//		assertEquals("pAN", cm.getPAN());
//		assertEquals("internalNotes", cm.getInternalNotes());
//		assertEquals(1, cm.getCreatedBy());
//		assertNotNull(cm.getCreatedDate());
//		assertEquals(1, cm.getUpdatedBy());
//		assertNotNull(cm.getUpdatedDate());
//		assertEquals("deletedBy", cm.getDeletedBy());
//		assertNotNull(cm.getDeletedDate());
//		assertEquals("awsImgUrl", cm.getAwsImgUrl());
//	}
}
