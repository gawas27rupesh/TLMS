package ai.rnt.bugtrackingsystem;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectTeam;
import ai.rnt.bugtrackingsystem.entity.RoleMaster;
import ai.rnt.bugtrackingsystem.entity.TestResult;

@ExtendWith(MockitoExtension.class)
public class ProjectTeamTest {
	
	ProjectTeam projectTeam = new ProjectTeam();
	EmployeeMaster empMaster = new EmployeeMaster();
	ProjectMaster projMaster = new ProjectMaster();
	RoleMaster roleMaster = new RoleMaster();
	TestResult testResult = new TestResult();
	
	@Test
	public void setterTest() {
		projectTeam.setEmployeeMaster(null);
		projectTeam.setProjectMaster(null);
		projectTeam.setRoleMaster(null);
		projectTeam.setTestResult(null);
	}
	
	@Test
	public void getterTest() {
		projectTeam.getEmployeeMaster();
		projectTeam.getProjectMaster();
		projectTeam.getRoleMaster();
		projectTeam.getTestResult();
		projectTeam.getProjectTeamId();
	}
	
}
