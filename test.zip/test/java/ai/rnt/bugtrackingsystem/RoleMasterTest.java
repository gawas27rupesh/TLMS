
package ai.rnt.bugtrackingsystem;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.ProjectTeam;
import ai.rnt.bugtrackingsystem.entity.RoleMaster;

/**
 * @author Madhuri Patil
 * @Date 2th Feb 2023
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
public class RoleMasterTest {

	private Logger log = LoggerFactory.getLogger(RoleMasterTest.class);

	RoleMaster roleMaster = new RoleMaster();
	Set<ProjectTeam> projectTeam = new HashSet<ProjectTeam>();

	@Test
	void setterTest() {
		roleMaster.setEmployeeRole("tester");
		roleMaster.setProjectTeam(projectTeam);
		roleMaster.setRoleId(2);

	}

	@Test
	void getterTest() {
		roleMaster.getEmployeeRole();
		roleMaster.getEmployees();
		roleMaster.getProjectTeam();
		roleMaster.getRoleId();
		roleMaster.toString();
	}

//	@Test
//	void testRoleMaster() {
//		String employeeRole = "Test";
//		RoleMaster roleMaster = new RoleMaster(employeeRole);
//		assertEquals(employeeRole, roleMaster.getEmployeeRole());
//	}
}
