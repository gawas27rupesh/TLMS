package ai.rnt.bugtrackingsystem.dto;

import java.math.BigInteger;

import org.junit.jupiter.api.Test;

class ProjectTeamDtoTest {
	
	ProjectTeamDto projectTeamDto = new ProjectTeamDto();
	 private BigInteger bug;
	@Test
	public void setterTest() {
		projectTeamDto.setBug(bug);
		projectTeamDto.setEndDate("2022-12-22");
		projectTeamDto.setIndexCount(1);
		projectTeamDto.setOwner("RNT");
		projectTeamDto.setProjectId(1);
		projectTeamDto.setProjectName("TLMS");
		projectTeamDto.setRole("tester");
		projectTeamDto.setStartDate("2022-07-13");
		projectTeamDto.setStatus('A');
		projectTeamDto.setEmployeeName("xyz");
	}
	
	@Test
	public void getterTest() {
		projectTeamDto.getBug();
		projectTeamDto.getEndDate();
		projectTeamDto.getIndexCount();
		projectTeamDto.getOwner();
		projectTeamDto.getProjectId();
		projectTeamDto.getProjectName();
		projectTeamDto.getRole();
		projectTeamDto.getStartDate();
		projectTeamDto.getStatus();
		projectTeamDto.getEmployeeId();
	}
}
