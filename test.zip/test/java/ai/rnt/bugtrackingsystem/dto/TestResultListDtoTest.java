package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class TestResultListDtoTest {
	
	TestResultListDto testResultDto = new TestResultListDto();
	
	@Test
	public void setterTest() {
		testResultDto.setActualResultList(null);
		testResultDto.setDragAndDropList(null);
		testResultDto.setExpectedResultList(null);
		testResultDto.setImageNameList(null);
		testResultDto.setInputDataList(null);
		testResultDto.setReqIdList(null);
		testResultDto.setScreenshotList(null);
		testResultDto.setStatusList(null);
		testResultDto.setStepDescList(null);
		testResultDto.setStepNoList(null);
		testResultDto.setTestCaseIdList(null);
		testResultDto.setTestCaseNameList(null);
		testResultDto.setTestList(null);
		testResultDto.setTestResultId(null);
		testResultDto.setTestScenarioIdList(null);
		
	}
	@Test
	public void getterTest() {
		testResultDto.getActualResultList();
		testResultDto.getDragAndDropList();
		testResultDto.getExpectedResultList();
		testResultDto.getImageNameList();
		testResultDto.getInputDataList();
		testResultDto.getReqIdList();
		testResultDto.getScreenshotList();
		testResultDto.getStatusList();
		testResultDto.getStepDescList();
		testResultDto.getStepNoList();
		testResultDto.getTestCaseIdList();
		testResultDto.getTestCaseNameList();
		testResultDto.getTestList();
		testResultDto.getTestResultId();
		testResultDto.getTestScenarioIdList();
		
	}
}
