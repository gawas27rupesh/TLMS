package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class SummaryDtoTest {
	
	SummaryDto summaryDto = new SummaryDto();
	@Test
	void setterTest() {
		summaryDto.setClosed(null);
		summaryDto.setDefectArea(null);
		summaryDto.setDeveloper(null);
		summaryDto.setModule(null);
		summaryDto.setOpen(null);
		summaryDto.setPriority(null);
		summaryDto.setReopen(null);
		summaryDto.setReqId(null);
		summaryDto.setSubModule(null);
		summaryDto.setTestCaseId(null);
		summaryDto.setTester(null);
		summaryDto.setTestScenarioId(null);
		summaryDto.setTotal(null);
	}
	
	@Test
	void getterTest() {
		summaryDto.getClosed();
		summaryDto.getDefectArea();
		summaryDto.getDeveloper();
		summaryDto.getModule();
		summaryDto.getOpen();
		summaryDto.getPriority();
		summaryDto.getReopen();
		summaryDto.getReqId();
		summaryDto.getSubModule();
		summaryDto.getTestCaseId();
		summaryDto.getTester();
		summaryDto.getTestScenarioId();
		summaryDto.getTotal();
	}
}
