package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class RtmDtoTest {

	RtmDto rtmDto = new RtmDto();
	@Test
	public void setterTest() {
		rtmDto.setBrId(null);
		rtmDto.setBrIdString(null);
		rtmDto.setIndexCount(null);
		rtmDto.setProjectId(null);
		rtmDto.setRequirement(null);
		rtmDto.setRequirementDesc(null);
		rtmDto.setRequirementDescList(null);
		rtmDto.setRequirementId(null);
		rtmDto.setRequirementIdList(null);
		rtmDto.setRequirementList(null);
		rtmDto.setRtmId(null);
		rtmDto.setRtmIdList(null);
		rtmDto.setRtmList(null);
		rtmDto.setScenarioId(null);
		rtmDto.setTestCase(null);
		rtmDto.setTestCaseList(null);
		rtmDto.setTestScenarioDesc(null);
		rtmDto.setTestScenarioDescList(null);
		rtmDto.setTestScenarioId(null);
		rtmDto.setNewTag(null);
		rtmDto.setCreatedDate(null);
	}
	
	@Test
	public void getterTest() {
		rtmDto.getBrId();
		rtmDto.getBrIdString();
		rtmDto.getIndexCount();
		rtmDto.getProjectId();
		rtmDto.getRequirement();
		rtmDto.getRequirementDesc();
		rtmDto.getRequirementDescList();
		rtmDto.getRequirementId();
		rtmDto.getRequirementIdList();
		rtmDto.getRequirementList();
		rtmDto.getRtmId();
		rtmDto.getRtmIdList();
		rtmDto.getRtmList();
		rtmDto.getScenarioId();
		rtmDto.getTestCase();
		rtmDto.getTestCaseList();
		rtmDto.getTestScenarioDesc();
		rtmDto.getTestScenarioDescList();
		rtmDto.getTestScenarioId();
		rtmDto.getCreatedDate();
		rtmDto.getNewTag();
		rtmDto.toString();
	}
}
