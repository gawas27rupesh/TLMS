package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

public class ProjectExistingTest {
	
	ProjectExisting projExist = new ProjectExisting();
	
	@Test
	public void setterTest() {
		projExist.setDomainName(null);
		projExist.setIndexCount(null);
		projExist.setProjectName(null);
		projExist.setProjectId(null);
	}
	
	@Test
	public void getterTest() {
		projExist.getDomainName();
		projExist.getIndexCount();
		projExist.getProjectName();
		projExist.getProjectId();
	}
}
