package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class TestScriptDtoTest {

	TestScriptDto testScriptDto = new TestScriptDto();
	@Test
	public void setterTest() {
		testScriptDto.setDragAndDropArr(null);
		testScriptDto.setDragAndDropArrList(null);
		testScriptDto.setExpectedResult(null);
		testScriptDto.setExpectedResultArray(null);
		testScriptDto.setExpectedResultList(null);
		testScriptDto.setInputData(null);
		testScriptDto.setInputDataArray(null);
		testScriptDto.setInputDataList(null);
		testScriptDto.setRequirement(null);
		testScriptDto.setRequirementId(null);
		testScriptDto.setRtmId(null);
		testScriptDto.setStepDesc(null);
		testScriptDto.setStepDescArray(null);
		testScriptDto.setStepDescList(null);
		testScriptDto.setStepId(null);
		testScriptDto.setStepIdDataArray(null);
		testScriptDto.setStepNo(null);
		testScriptDto.setStepNoList(null);
		testScriptDto.setSteps(null);
		testScriptDto.setStepsArray(null);
		testScriptDto.setTestCaseId(null);
		testScriptDto.setTestCaseName(null);
		testScriptDto.setTestCaseNameList(null);
		testScriptDto.setTestCaseViewId(null);
		testScriptDto.setTestList(null);
		testScriptDto.setTestScenarioId(null);
		testScriptDto.setTestScriptId(null);
		testScriptDto.setReqId(null);
		testScriptDto.setCreatedDate(null);
		testScriptDto.setNewTag(null);
		testScriptDto.setIndexCount(null);
	}
	
	@Test
	public void getterTest() {
		testScriptDto.getDragAndDropArr();
		testScriptDto.getDragAndDropArrList();
		testScriptDto.getExpectedResult();
		testScriptDto.getExpectedResultArray();
		testScriptDto.getExpectedResultList();
		testScriptDto.getInputData();
		testScriptDto.getInputDataArray();
		testScriptDto.getInputDataList();
		testScriptDto.getRequirement();
		testScriptDto.getRequirementId();
		testScriptDto.getRtmId();
		testScriptDto.getStepDesc();
		testScriptDto.getStepDescArray();
		testScriptDto.getStepDescList();
		testScriptDto.getStepId();
		testScriptDto.getStepIdDataArray();
		testScriptDto.getStepNo();
		testScriptDto.getStepNoList();
		testScriptDto.getSteps();
		testScriptDto.getStepsArray();
		testScriptDto.getTestCaseId();
		testScriptDto.getTestCaseName();
		testScriptDto.getTestCaseNameList();
		testScriptDto.getTestCaseViewId();
		testScriptDto.getTestList();
		testScriptDto.getTestScenarioId();
		testScriptDto.getTestScriptId();
		testScriptDto.toString();
		testScriptDto.getReqId();
		testScriptDto.getCreatedDate();
		testScriptDto.getNewTag();
		testScriptDto.getIndexCount();
	}
}
