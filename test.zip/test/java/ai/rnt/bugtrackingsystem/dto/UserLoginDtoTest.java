package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;
/**
 * @author Madhuri Patil
 * @Date 30, Jan 2023
 * @version 1.0
 */
class UserLoginDtoTest {
	
	UserLoginDto userLoginDto = new UserLoginDto();
	
	@Test
	public void setterTest() {
		userLoginDto.setAdmin(false);
		userLoginDto.setEmailId("m.patil@rnt.ai");
		userLoginDto.setFullName("Madhuri Patil");
		userLoginDto.setHasUserRole(false);
		userLoginDto.setList(userLoginDto);
		userLoginDto.setPassword("1304");
		userLoginDto.setProjectList(null);
		userLoginDto.setRoleId(1);
		userLoginDto.setRoleName("Developer");
		userLoginDto.setStaffId(1304);
		userLoginDto.setUserName("Madhuri Patil");
	}
	
	@Test
	public void getterTest() {
		userLoginDto.getEmailId();
		userLoginDto.getFullName();
		userLoginDto.getPassword();
		userLoginDto.getProjectList();
		userLoginDto.getRoleId();
		userLoginDto.getRoleName();
		userLoginDto.getStaffId();
		userLoginDto.getUserName();
		userLoginDto.toString();
	}
}
