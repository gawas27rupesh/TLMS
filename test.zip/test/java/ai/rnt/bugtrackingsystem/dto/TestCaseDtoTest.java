package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class TestCaseDtoTest {
	
	TestCaseDto testCaseDto = new TestCaseDto();
	
	@Test
	public void setterTest() {
		testCaseDto.setCaseId(null);
		testCaseDto.setCaseIdList(null);
		testCaseDto.setIndexCount(null);
		testCaseDto.setProjectId(null);
		testCaseDto.setRequirement(null);
		testCaseDto.setRequirementId(null);
		testCaseDto.setRequirementIdList(null);
		testCaseDto.setRoleName(null);
		testCaseDto.setRtmId(null);
		testCaseDto.setScenarioId(null);
		testCaseDto.setScenarioIdList(null);
		testCaseDto.setTest(null);
		testCaseDto.setTestCaseId(null);
		testCaseDto.setTestCaseIdList(null);
		testCaseDto.setTestCases(null);
		testCaseDto.setTestCasesList(null);
		testCaseDto.setTestScenarioId(null);
		testCaseDto.setTestScenarioIdList(null);
	}
	
	@Test
	public void getterTest() {
		testCaseDto.getCaseId();
		testCaseDto.getCaseIdList();
		testCaseDto.getIndexCount();
		testCaseDto.getProjectId();
		testCaseDto.getRequirement();
		testCaseDto.getRequirementId();
		testCaseDto.getRequirementIdList();
		testCaseDto.getRoleName();
		testCaseDto.getRtmId();
		testCaseDto.getScenarioId();
		testCaseDto.getScenarioIdList();
		testCaseDto.getTest();
		testCaseDto.getTestCaseId();
		testCaseDto.getTestCaseIdList();
		testCaseDto.getTestCases();
		testCaseDto.getTestCasesList();
		testCaseDto.getTestScenarioId();
		testCaseDto.getTestScenarioIdList();
		testCaseDto.toString();
	}

}
