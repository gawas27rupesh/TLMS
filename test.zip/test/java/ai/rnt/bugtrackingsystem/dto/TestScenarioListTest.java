package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class TestScenarioListTest {
	
	TestScenarioList testScenarioList = new TestScenarioList();
	
	@Test
	public void setterTest() {
		testScenarioList.setCaseId("TC_1");
		testScenarioList.setIndexCount(1);
		testScenarioList.setReqId("FR_1.1");
		testScenarioList.setRequirement("Add the input field");
		testScenarioList.setRtmId(1);
		testScenarioList.setScenarioId(1);
		testScenarioList.setTcaseId(1);
		testScenarioList.setTestCaseId("TC_1");
		testScenarioList.setTestCases("Add input field for username");
		testScenarioList.setTestScenarioDesc("Add input field for username");
		testScenarioList.setTestScenarioId("TS_1");
	}
	
	@Test
	public void getterTest() {
		testScenarioList.getCaseId();
		testScenarioList.getIndexCount();
		testScenarioList.getReqId();
		testScenarioList.getRequirement();
		testScenarioList.getRtmId();
		testScenarioList.getScenarioId();
		testScenarioList.getTcaseId();
		testScenarioList.getTestCaseId();
		testScenarioList.getTestCases();
		testScenarioList.getTestScenarioDesc();
		testScenarioList.getTestScenarioId();
	}

}
