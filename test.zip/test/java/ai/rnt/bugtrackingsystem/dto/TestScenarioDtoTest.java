package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class TestScenarioDtoTest {
	
	TestScenarioDto testScenarioDto = new TestScenarioDto();
	@Test
	public void setterTest() {
		testScenarioDto.setIndexCount(null);
		testScenarioDto.setProjectId(null);
		testScenarioDto.setRequirement(null);
		testScenarioDto.setRequirementId(null);
		testScenarioDto.setRequirementIdList(null);
		testScenarioDto.setRtmId(null);
		testScenarioDto.setScenarioId(null);
		testScenarioDto.setScenarioId1(null);
		testScenarioDto.setScenarioIdList(null);
		testScenarioDto.setTestCaseName(null);
		testScenarioDto.setTestCaseNameList(null);
		testScenarioDto.setTestList(null);
		testScenarioDto.setTestScenarioDescription(null);
		testScenarioDto.setTestScenarioDescriptionList(null);
		testScenarioDto.setTestScenarioId(null);
		testScenarioDto.setTestScenarioIdList(null);
	}
	
	@Test
	public void getterTest() {
		testScenarioDto.getIndexCount();
		testScenarioDto.getProjectId();
		testScenarioDto.getRequirement();
		testScenarioDto.getRequirementId();
		testScenarioDto.getRequirementIdList();
		testScenarioDto.getRtmId();
		testScenarioDto.getScenarioId();
		testScenarioDto.getScenarioId1();
		testScenarioDto.getScenarioIdList();
		testScenarioDto.getTestCaseName();
		testScenarioDto.getTestCaseNameList();
		testScenarioDto.getTestList();
		testScenarioDto.getTestScenarioDescription();
		testScenarioDto.getTestScenarioDescriptionList();
		testScenarioDto.getTestScenarioId();
		testScenarioDto.getTestScenarioIdList();
		testScenarioDto.toString();
	}
}
