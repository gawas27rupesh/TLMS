package ai.rnt.bugtrackingsystem.dto;


import org.junit.jupiter.api.Test;

class BugDtoTest {
	
	BugDto dto = new BugDto();

	@Test
	void test() {
		//dto.setBid(1);
		//dto.getBid();
	}

}
