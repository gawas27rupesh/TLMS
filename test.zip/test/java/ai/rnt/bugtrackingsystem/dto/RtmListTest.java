package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class RtmListTest {
	
	RtmList rtmList = new RtmList();
	@Test
	public void setterTest() {
		rtmList.setBrId(null);
		rtmList.setBrIdString(null);
		rtmList.setIndexCount(null);
		rtmList.setRequirement(null);
		rtmList.setRequirementDesc(null);
		rtmList.setRequirementId(null);
		rtmList.setRtmId(null);
		rtmList.setScenarioId(null);
		rtmList.setTestCase(null);
		rtmList.setTestScenarioDesc(null);
		rtmList.setTestScenarioId(null);
	}
	@Test
	public void getterTest() {
		rtmList.getBrId();
		rtmList.getBrIdString();
		rtmList.getIndexCount();
		rtmList.getRequirement();
		rtmList.getRequirementDesc();
		rtmList.getRequirementId();
		rtmList.getRtmId();
		rtmList.getScenarioId();
		rtmList.getTestCase();
		rtmList.getTestScenarioDesc();
		rtmList.getTestScenarioId();
	}
}
