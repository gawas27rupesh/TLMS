package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

class TestResultDtoTest {
	
	TestResultDto testDto = new TestResultDto();
	@Test
	public void setterTest() {
		
		testDto.setActualResult(null);
		testDto.setCaseId(null);
		testDto.setDragAndDropStep(null);
		testDto.setExpectedResult(null);
		testDto.setImageName(null);
		testDto.setInputData(null);
		testDto.setReqId(null);
		testDto.setRequirement(null);
		testDto.setResultId(null);
		testDto.setScreenshot(null);
		testDto.setStatus(null);
		testDto.setStep_no(null);
		testDto.setTestCaseId(null);
		testDto.setTestCaseName(null);
		testDto.setTestDesc(null);
		testDto.setTestList(null);
		testDto.setTestScenarioDesc(null);
		testDto.setTestScenarioId(null);
		testDto.setTestScriptId(null);
	}
	
	@Test
	public void getterTest() {
		testDto.getActualResult();
		testDto.getCaseId();
		testDto.getDragAndDropStep();
		testDto.getExpectedResult();
		testDto.getImageName();
		testDto.getInputData();
		testDto.getReqId();
		testDto.getRequirement();
		testDto.getResultId();
		testDto.getScreenshot();
		testDto.getStatus();
		testDto.getStep_no();
		testDto.getTestCaseId();
		testDto.getTestCaseName();
		testDto.getTestDesc();
		testDto.getTestList();
		testDto.getTestScenarioDesc();
		testDto.getTestScenarioId();
		testDto.getTestScriptId();
		testDto.toString();
	}
}
