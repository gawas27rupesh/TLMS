package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TestScriptListTest {

	TestScriptList testScriptList = new TestScriptList();

	@Test
	void setterTest() {
		testScriptList.setDragAndDropArrList(1);
		testScriptList.setExpectedResultList("test");
		testScriptList.setIndexCount(1);
		testScriptList.setInputDataList("test");
		testScriptList.setStepDescList("test data");
		testScriptList.setStepNoList(1);
		testScriptList.setTestCaseNameList("test data");
		testScriptList.setTestScriptId(1);
	}

	@Test
	void getterTest() {
		testScriptList.getDragAndDropArrList();
		testScriptList.getExpectedResultList();
		testScriptList.getIndexCount();
		testScriptList.getInputDataList();
		testScriptList.getStepDescList();
		testScriptList.getStepNoList();
		testScriptList.getTestCaseNameList();
		testScriptList.getTestScriptId();

	}
}
