package ai.rnt.bugtrackingsystem.dto;

import org.junit.jupiter.api.Test;

public class HomeDtoTest {

	HomeDto homeDto = new HomeDto();
	
	@Test
	void setterTest() {
		homeDto.setBrStatus(null);
		homeDto.setCloesdBug(null);
		homeDto.setOpenBug(null);
		homeDto.setProjectId(null);
		homeDto.setProjectName(null);
		homeDto.setReopenBug(null);
		homeDto.setRtmStatus(null);
		homeDto.setStatus('1');
		homeDto.setTestCaseStatus(null);
		homeDto.setTestPlanStatus(null);
		homeDto.setTestResultStatus(null);
		homeDto.setTestscenariostatus(null);
		homeDto.setTestScriptStatus(null);
		homeDto.setTotalBug(null);
	}
	
	@Test
	void getterTest() {
		homeDto.getBrStatus();
		homeDto.getCloesdBug();
		homeDto.getOpenBug();
		homeDto.getProjectId();
		homeDto.getProjectName();
		homeDto.getReopenBug();
		homeDto.getRtmStatus();
		homeDto.getStatus();
		homeDto.getTestCaseStatus();
		homeDto.getTestPlanStatus();
		homeDto.getTestResultStatus();
		homeDto.getTestscenariostatus();
		homeDto.getTestScriptStatus();
		homeDto.getTotalBug();
		homeDto.toString();
	}

}
