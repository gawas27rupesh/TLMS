package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.BusinessRequirement;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;

/**
 * @author Madhuri Patil
 * @Date 2th Feb 2023
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
public class BusinessRequirementTest {
	private Logger log = LoggerFactory.getLogger(RoleMasterTest.class);

	BusinessRequirement businessRequirement = new BusinessRequirement();
	ProjectMaster projectMaster = new ProjectMaster();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	@Test
	void setterTest() {
		businessRequirement.setBrDescription("BusinessRequirement Description");
		businessRequirement.setBrId(1);
		businessRequirement.setBrIdString("BR_1");
		businessRequirement.setBrName("BusinessRequirement ");
		businessRequirement.setCreatedBy(1);
		businessRequirement.setCreatedDate(createdDate);
		businessRequirement.setProjectMaster(projectMaster);
		businessRequirement.setUpdatedBy(1);
		businessRequirement.setUpdatedDate(updatedDate);
	}
	
	@Test
	void getterTest() {
		businessRequirement.getBrDescription();
		businessRequirement.getBrId();
		businessRequirement.getBrIdString();
		businessRequirement.getBrName();
		businessRequirement.getCreatedBy();
		businessRequirement.getCreatedDate();
		businessRequirement.getProjectMaster();
		businessRequirement.getUpdatedBy();
		businessRequirement.getUpdatedDate();
	}
}
