package ai.rnt.bugtrackingsystem;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.Status;

@ExtendWith(MockitoExtension.class)
public class StatusTest {

	Status status = new Status();
	
	@Test
	public void setterTest() {
		status.setStatus("completed");
		status.setStatusId(1);
	}
	@Test
	public void getterTest() {
		status.getStatus();
		status.getStatusId();
	}
}
