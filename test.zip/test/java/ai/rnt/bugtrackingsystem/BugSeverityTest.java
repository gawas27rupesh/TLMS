package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.BugSeverity;

@ExtendWith(MockitoExtension.class)

public class BugSeverityTest {
	private Logger log = LoggerFactory.getLogger(RtmTest.class);
	BugSeverity bugSeverity = new BugSeverity();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	
	@Test
	void setterTest() {
		bugSeverity.setCreatedBy(1);
		bugSeverity.setCreatedDate(createdDate);
		bugSeverity.setSeverity("Critical");
		bugSeverity.setSeverityId(1);
		bugSeverity.setUpdatedBy(1);
		bugSeverity.setUpdatedDate(updatedDate);
	}
	
	@Test
	void getterTest() {
		bugSeverity.getCreatedBy();
		bugSeverity.getCreatedDate();
		bugSeverity.getSeverity();
		bugSeverity.getSeverityId();
		bugSeverity.getUpdatedBy();
		bugSeverity.getUpdatedDate();
	}
}
