
package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.BusinessRequirement;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.TestResult;
import ai.rnt.bugtrackingsystem.entity.TestScript;

/**
 * @author Madhuri Patil
 * @Date 31th Jan 2023
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
public class RtmTest {

	private Logger log = LoggerFactory.getLogger(RtmTest.class);

	Rtm rtm = new Rtm();
	BusinessRequirement br = new BusinessRequirement();
	ProjectMaster projMaster = new ProjectMaster();
	List<TestResult> testResult = new ArrayList<TestResult>();
	List<TestScript> testScript = new ArrayList<TestScript>();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	@Test
	public void setterTest() {
		rtm.setRtmId(1);
		rtm.setBrId(br);
		rtm.setProjectMaster(projMaster);
		rtm.setReqId("FR_1");
		rtm.setRequirement("Add the input field");
		rtm.setRequirementDesc("Add the input field");
		rtm.setTestResult(testResult);
		rtm.setTestScript(testScript);
		rtm.setCreatedBy(1304);
		rtm.setCreatedDate(createdDate);
		rtm.setUpdatedBy(1304);
		rtm.setUpdatedDate(updatedDate);
	}

	@Test
	public void getterTest() {
		rtm.getRtmId();
		rtm.getBrId();
		rtm.getProjectMaster();
		rtm.getReqId();
		rtm.getRequirement();
		rtm.getRequirementDesc();
		rtm.getTestCase();
		rtm.getTestResult();
		rtm.getTestScript();
		rtm.getCreatedBy();
		rtm.getCreatedDate();
		rtm.getUpdatedBy();
		rtm.getUpdatedDate();

	}

}
