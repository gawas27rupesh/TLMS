
package ai.rnt.bugtrackingsystem.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.TestResultDto;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestResult;
import ai.rnt.bugtrackingsystem.entity.TestScenario;
import ai.rnt.bugtrackingsystem.entity.TestScript;
import ai.rnt.bugtrackingsystem.repository.RtmRepository;
import ai.rnt.bugtrackingsystem.repository.TestCaseRepository;
import ai.rnt.bugtrackingsystem.repository.TestResultRepository;
import ai.rnt.bugtrackingsystem.repository.TestScenarioRepository;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.service.TestCaseService;
import ai.rnt.bugtrackingsystem.service.TestResultService;
import ai.rnt.bugtrackingsystem.service.TestScriptService;

@AutoConfigureMockMvc
public class TestResultControllerTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	TestResultController testResultController;

	@Mock
	TestResultRepository tresultrepo;
	
	@Mock
	TestScriptService testScriptService;
	
	@Mock
	ProjectMasterService projectMasterService;

	@Mock
	TestCaseService testCaseService;

	@Mock
	StatusService statusService;

	@Mock
	BugService bugService;

	@Mock
	ProjectTeamService projectTeamService;

	@Mock
	TestResultRepository testResultRepository;

	@Mock
	TestCaseRepository testCaseRepository;

	@Mock
	TestScenarioRepository testScenarioRepository;

	@Mock
	TestCaseService testService;
	
	@Mock
	RtmRepository rtmRepository;

	@Mock
	TestResultService testResultService;

	@Mock
	Model model;

	@Mock
	HttpSession session;

	@Mock
	RedirectAttributes red;
	
	@Mock
	HttpServletRequest request;

	String result;
	private final int size = 100;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(testResultController).build();
	}
	
	@Test
	void updateTestSciptTest() throws IOException {
		UserLoginDto userData = new UserLoginDto();
		userData.setRoleName("tlms admin");
		userData.setStaffId(1);
		when(session.getAttribute("userData")).thenReturn(userData);
		
		MultipartFile file = new MockMultipartFile("testImage.jpg", new byte[]{1, 2, 3, 4, 5});
		String imageName = "testImage.jpg";
		TestResult testresult = new TestResult();
		when(testResultService.findById(1)).thenReturn(testresult);
		testResultController.updateTestScipt(file, 1, imageName, "RNT", imageName, session);
	}

	//@Test
	void saveTestResultTest() throws IOException {
		
		testResultController.saveTestResult(model, session, request, null, red);
		
		HttpServletRequest request = mock(MockHttpServletRequest.class);
		
		UserLoginDto userData = new UserLoginDto();
		userData.setRoleName("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		when(request.getParameter("stepId0")).thenReturn("1");
		when(request.getParameter("reqId")).thenReturn("1");
		when(request.getParameter("tscenId")).thenReturn("1");
		when(request.getParameter("tcaseId")).thenReturn("1");
		when(request.getParameter("resultId0")).thenReturn("1");
		when(request.getParameter("result0")).thenReturn("Result");
		when(request.getParameter("status0")).thenReturn("Status");
		
		MultipartFile file = new MockMultipartFile("testImage.jpg", new byte[200000]);
		MultipartFile[] file2 = new MockMultipartFile[2];
		file2[0] = file;
		file2[1] = file;
		Rtm rtm = new Rtm();
		rtm.setRtmId(1);
		ProjectMaster projectMaster = new ProjectMaster();
		rtm.setProjectMaster(projectMaster);
		when(rtmRepository.findById(1)).thenReturn(Optional.of(rtm));
		
		TestScenario testScenario = new TestScenario();
		testScenario.setTestScenarioId("1");
		when(testScenarioRepository.findById(1)).thenReturn(Optional.of(testScenario));
		
		TestCase testCase = new TestCase();
		testCase.setTestCaseId("1");
		when(testService.findById(1)).thenReturn(testCase);
		
		TestResult testResult1 = new TestResult();
		testResult1.setResultScreenshot("");
		
		testResultController.saveTestResult(model, session, request, file2, red);
		
		when(request.getParameter("resultId0")).thenReturn("null");
		
		TestScript testScript = new TestScript();
		when(testScriptService.findById(1)).thenReturn(testScript);
		testResultController.saveTestResult(model, session, request, file2, red);
	}

	@Test
	public void testScaleImage() {
		BufferedImage image = null;
		BufferedImage scaledImage = scaleImage(image, size);
		//assertEquals(null, testResultController.scaleImage(scaledImage, size));
	}

	// written these to create scaleImage method
	private BufferedImage scaleImage(BufferedImage image, int size2) {
		return null;
	}

	@Test
	void testGetDatabyCase() {
		// Given
		Integer caseId = 1;
		List<TestResultDto> expectedList = Arrays.asList(new TestResultDto(), new TestResultDto());
		when(testResultService.stepByActualResult(caseId)).thenReturn(expectedList);

		// When
		List<TestResultDto> actualList = testResultController.getDatabyCase(caseId);

		// Then
		assertEquals(expectedList, actualList);
	}

	@Test
	public void testGetExpandForTestResult() {
		// Given
		String reqId = "reqId_1";
		Integer projectId = 1;
		String caseID = "caseID_1";
		Integer caseId = 1;

		Rtm rtm = new Rtm();
		rtm.setReqId("reqId_1");
		rtm.setRtmId(1);
		rtm.setProjectMaster(new ProjectMaster());

		TestCase testCase = new TestCase();
		testCase.setTestCaseId("caseID_1");
		testCase.setRtm(rtm);
		testCase.setProject(new ProjectMaster());

		List<TestResultDto> expectedResult = Arrays.asList(new TestResultDto(), new TestResultDto());

		when(rtmRepository.findByReqIdAndProjectMaster(reqId, projectId)).thenReturn(rtm);
		when(testCaseRepository.findById(caseId)).thenReturn(Optional.of(testCase));
		when(testResultService.getResultExpandDtl(rtm.getRtmId(), projectId, testCase.getCaseId()))
				.thenReturn(expectedResult);

		// When
		List<TestResultDto> result = testResultController.getAllProjectById(reqId, projectId, caseID, caseId);

		// Then
		assertEquals(expectedResult, result);
		verify(rtmRepository).findByReqIdAndProjectMaster(reqId, projectId);
		verify(testCaseRepository).findById(caseId);
		verify(testResultService).getResultExpandDtl(rtm.getRtmId(), projectId, testCase.getCaseId());
	}

	@Test
	public void testEditTestResultByRtmId() {
		int projectId = 1;
		String rtmId = "RTM001";
		String caseID = "TC001";
		HttpSession session = mock(HttpSession.class);

		Rtm rtm = new Rtm();
		rtm.setRtmId(1);
		when(rtmRepository.findByReqIdAndProjectMaster(rtmId, projectId)).thenReturn(rtm);

		TestCase testCase = new TestCase();
		testCase.setTestCaseId("TC001");
		when(testCaseRepository.findByCaseIdAndProjectMaster(caseID, projectId, rtm.getRtmId())).thenReturn(testCase);

		List<TestResultDto> expectedResult = new ArrayList<>();
		when(testResultService.getResultExpandDtl(rtm.getRtmId(), projectId, testCase.getCaseId()))
				.thenReturn(expectedResult);

		List<TestResultDto> actualResult = testResultController.editTestResultByRtmId(projectId, rtmId, caseID,
				session);

		assertEquals(expectedResult, actualResult);
		verify(rtmRepository).findByReqIdAndProjectMaster(rtmId, projectId);
		verify(testCaseRepository).findByCaseIdAndProjectMaster(caseID, projectId, rtm.getRtmId());
		verify(testResultService).getResultExpandDtl(rtm.getRtmId(), projectId, testCase.getCaseId());
	}

	@Test
	void deleteByRtmIdTest() {
		testResultController.deleteByRtmId(1);
		
		when(tresultrepo.updateStatusId(1, null)).thenReturn(null);
		testResultController.deleteByRtmId(1);
	}

	@Test
	void testUpdateStatus_Success() {
		when(testResultService.updateAllByProjectId(1, 1)).thenReturn(1);
		ResponseEntity<String> response = testResultController.updateStatus(1, 1);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("success", response.getBody());
	}

	@Test
	void testUpdateStatus_Error() {
		when(testResultService.updateAllByProjectId(1, 1)).thenReturn(0);
		ResponseEntity<String> response = testResultController.updateStatus(1, 1);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("error", response.getBody());
	}

	@Test
	void testGetStatus() {
		Integer projectId = 1;
		int status = 1;

		when(testResultService.findStatusByProject(projectId)).thenReturn(status);

		ResponseEntity<Integer> result = testResultController.getStatus(projectId);

		verify(testResultService).findStatusByProject(projectId);
		assertThat(result).isNotNull();
		assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(result.getBody()).isEqualTo(status);
	}

	@Test
	public void testDownloadZipFile() throws Exception {
		Integer projectId = 1;
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectName("TestProject");

		MockHttpServletResponse response = new MockHttpServletResponse();

		when(projectMasterService.findById(projectId)).thenReturn(projectMaster);

		testResultController.downloadZipFile(response, projectId);

		verify(projectMasterService).findById(projectId);
	}
	

	@Test
	public void updateTestResult_ShouldUpdateTestResult() throws IOException {
		// Arrange

		HttpSession session = mock(HttpSession.class);
		UserLoginDto userData = new UserLoginDto();
		userData.setStaffId(1);
		when(session.getAttribute("userData")).thenReturn(userData);

		 MultipartFile file = mock(MultipartFile.class);
		    when(file.getSize()).thenReturn(10L);
		    when(file.isEmpty()).thenReturn(false);

		    TestResult existingTestResult = new TestResult();
		    existingTestResult.setTestResultId(1);
		    existingTestResult.setActualResult("Actual Result");
		    existingTestResult.setResultStatus("PASS");
		    existingTestResult.setImageName("Test Result Image");

		    TestResult updatedTestResult = new TestResult();
		    updatedTestResult.setTestResultId(1);
		    updatedTestResult.setActualResult("Actual Result");
		    updatedTestResult.setResultStatus("PASS");
		    updatedTestResult.setImageName("Test Result Image");
		    updatedTestResult.setUpdatedBy(1);
		    updatedTestResult.setUpdatedDate(LocalDateTime.now());

		when(testResultService.findById(1)).thenReturn(existingTestResult);
		when(testResultService.testResultSave(updatedTestResult)).thenReturn("success");

		/*
		 * // Act JSONObject actualMainJson = testResultController.updateTestScipt(file,
		 * 1, "result status", "actual result", "image name", session);
		 */

		/*
		 * // Assert assertEquals(expectedMainJson.toString(),
		 * actualMainJson.toString()); verify(testResultService).findById(1);
		 * verify(testResultService).save(updatedTestResult);
		 */
	}

}
