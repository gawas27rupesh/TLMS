package ai.rnt.bugtrackingsystem.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.ProjectExisting;
import ai.rnt.bugtrackingsystem.dto.ProjectTeamDto;
import ai.rnt.bugtrackingsystem.dto.TestCaseDto;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestScenario;
import ai.rnt.bugtrackingsystem.repository.TestCaseRepository;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.RtmService;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.service.TestCaseService;
import ai.rnt.bugtrackingsystem.service.TestScenarioService;

class TestCaseControllerTest2 {

	@Autowired
	MockMvc mockMvc;
	@Mock
	Model model;
	@Mock
	ModelMap mp;
	@Mock
	RedirectAttributes redirectAttributes;
	@Mock
	HttpSession session;
	@Mock
	HttpServletResponse response;
	@Mock
	HttpServletRequest request;
	@Mock
	private ProjectMasterService projectMasterService;

	@Mock
	RtmService rtmService;

	@Mock
	TestScenarioService testscenarioService;

	@Mock
	TestCaseService testCaseService;

	@Mock
	ProjectTeamService projectTeamService;

	@Mock
	BugService bugService;
	@Mock
	StatusService statusService;

	@Mock
	TestCaseRepository testRepo;

	@InjectMocks
	TestCaseController testCaseController;

	String result;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(testCaseController).build();
	}

	//@Test
	void testCasePageTest() {
		// tlms admin
		UserLoginDto userData = new UserLoginDto();
		userData.setRoleName("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		List<ProjectMaster> projectData = new ArrayList<>();
		when(projectMasterService.findAll()).thenReturn(projectData);
		result = testCaseController.testCasePage(model, session, redirectAttributes);

		// for Developer
		ArrayList<ProjectExisting> projectList = new ArrayList<>();
		ProjectExisting projectExisting = new ProjectExisting();
		projectExisting.setProjectName("tlms");
		projectList.add(projectExisting);
		userData.setProjectList(projectList);
		userData.setRoleName("developer");
		when(session.getAttribute("userData")).thenReturn(userData);
		when(projectMasterService.findAll()).thenReturn(projectData);
		result = testCaseController.testCasePage(model, session, redirectAttributes);

		// for else condition
		userData.setRoleName("user");
		when(session.getAttribute("userData")).thenReturn(userData);
		ArrayList<Integer> ids = new ArrayList<>();
		ids.add(1);
		when(projectTeamService.getProjectByRoleAndStaffId(0, 0)).thenReturn(ids);
		result = testCaseController.testCasePage(model, session, redirectAttributes);

		// for userData is null
		UserLoginDto userData1 = null;
		when(session.getAttribute("userData")).thenReturn(userData1);
		result = testCaseController.testCasePage(model, session, redirectAttributes);
	}

	/*
	 * @Test void getAllProjectListTest() { testCaseController.getAllProjectList(1,
	 * session); }
	 * 
	 * @Test void getAllTestCaseScenarioListTest() {
	 * testCaseController.getAllTestCaseScenarioList(null, session); }
	 */

	@Test
	void addTestCaseTest() {
		TestCaseDto testCaseDto = new TestCaseDto();
		// testCaseDto.setCaseId(1);
		testCaseDto.setTestCaseId("123");
		testCaseDto.setTestCases("Test Case");
		testCaseDto.setRequirementId("456");
		testCaseDto.setProjectId(789);
		testCaseDto.setTestScenarioId("0123");

		HttpSession session = mock(HttpSession.class);
		UserLoginDto userData = new UserLoginDto();
		userData.setStaffId(1380);
		when(session.getAttribute("userData")).thenReturn(userData);

		Rtm rtm = new Rtm();
		rtm.setRtmId(123);
		rtm.setProjectMaster(new ProjectMaster());
		when(rtmService.findByReqIdAndProjectMaster(testCaseDto.getRequirementId(), testCaseDto.getProjectId()))
				.thenReturn(rtm);

		TestScenario testScenario = new TestScenario();
		testScenario.setTestScenarioId("TS_01");
		when(testscenarioService.findByTestScenarioIdAndProjectMaster(testCaseDto.getTestScenarioId(),
				testCaseDto.getProjectId(), rtm.getRtmId())).thenReturn(testScenario);
		testCaseController.addTestCase(testCaseDto, request, session, redirectAttributes);

	}

	@Test
	void getAllProjectByIdTest() {
		int id = 1;
		UserLoginDto userData = new UserLoginDto();
		TestScenario testScenario = new TestScenario();
		testScenario.setTestScenarioId("TS_01");
		TestCase testCase = new TestCase();
		testCase.setRtm(null);
		testCase.setTestScenario(testScenario);
		List<TestScenario> scenarioList = Arrays.asList(testScenario);
		List<TestCase> testCases = Arrays.asList(testCase);

		when(session.getAttribute("userData")).thenReturn(userData);
		when(testscenarioService.findByRtmId(id)).thenReturn(scenarioList);
		when(testCaseService.findByRtmAndTestScenario(id, testScenario.getScenarioId())).thenReturn(testCases);

		// Act
		testCaseController.getAllProjectById(id, session);

		testCaseController.getAllProjectById(1, session);
	}

	@Test
	void deleteTest() {
		// for userData == null
		result = testCaseController.delete(1, session, redirectAttributes);

		// for else Condition
		Integer id = 1;
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);

		TestCase testCase = new TestCase();
		testCase.setTestCaseId("TC01");
		TestScenario testScenario = new TestScenario();
		testScenario.setTestScenarioId("TS_01");
		ProjectMaster project = new ProjectMaster();
		project.setProjectID(3);
		testCase.setTestScenario(testScenario);
		testCase.setProject(project);

		when(testCaseService.findById(id)).thenReturn(testCase);
		result = testCaseController.delete(1, session, redirectAttributes);

		// for catch block
		result = testCaseController.delete(null, session, redirectAttributes);

	}

	@Test
	void deleteByRtmId() {
		// for try block
		TestCase testCase = new TestCase();
		
		TestScenario testScenario = new TestScenario();
		testCase.setTestScenario(testScenario);
		when(testCaseService.findById(1)).thenReturn(testCase);
		result = testCaseController.deleteByRtmId(1);

		// for Catch Block
		result = testCaseController.deleteByRtmId(null);
	}
	
	@Test
	void getAllProjectById3Test() {
		testCaseController.getAllProjectById3(1, session);
	}
	
	@Test
	void getAllDataForAddTestCaseTEst() {
		testCaseController.getAllDataForAddTestCase(1, session);
	}
	@Test
	void getDataTest() {
		testCaseController.getData(1, session);
	}
	@Test
	void duplicateRecordOrNotTest() {
		// for try block
		when(testCaseService.checkDuplicateTestCase("1", 2, 3, 4)).thenReturn(true);
		testCaseController.duplicateRecordOrNot("1", 2, 3, 4);
		
		// for Catch block
		testCaseController.duplicateRecordOrNot("Hi", null, null, null);
	}
	
	@Test
	void updateStatusTest(){
		testCaseController.updateStatus(1, 1);
	}
	@Test
	void getStatusTest(){
		testCaseController.getStatus(1);
	}
	@Test
	void exportExcelTest(){
		// for Object isNull
		testCaseController.exportExcel(1, redirectAttributes, mp, session);
		
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);
	
		
		List<String> projectInfo = new ArrayList<String>();
		projectInfo.add("Active");
		projectInfo.add("26-09-2023");
		projectInfo.add("26-09-2023");
		
		
		ProjectMaster pm = new ProjectMaster();
		ClientMaster cm = new ClientMaster();
		cm.setCompanyName("RNT");
		pm.setClientmaster(cm);
		
		List<ProjectTeamDto> project = new ArrayList<>();
		ProjectTeamDto projectTeamDto = new ProjectTeamDto();
		projectTeamDto.setRole("Tester");
		project.add(projectTeamDto);
		
		
		when(projectMasterService.findById(1)).thenReturn(pm);
		when(bugService.findBugCount(1)).thenReturn(1);
	//	when(projectMasterService.getProjectStatusWithStartAndEndDate(1)).thenReturn(projectInfo);
		when(projectTeamService.findProjectTesterByProjectId(1)).thenReturn(project);
		testCaseController.exportExcel(1, redirectAttributes, mp, session);
	}
	
	@Test
	void getAutoPopulatedTestCaseIdTest() {
		result = testCaseController.getAutoPopulatedTestCaseId(1, 1, "test Case1");
	}
	
	@Test
	void updateTestCaseTest() {
		 UserLoginDto userData = new UserLoginDto();
	      userData.setStaffId(1);
	      when(session.getAttribute("userData")).thenReturn(userData);
	      
	      TestCase existingTestCase = new TestCase();
	      existingTestCase.setTestCaseId("TC_01");
	      existingTestCase.setTestCase("Test Case");
	      when(testCaseService.findById(1)).thenReturn(existingTestCase);
	      
	      when(testCaseService.save(existingTestCase)).thenReturn(null);
		result = testCaseController.updateTestCase(1, "testCase", session);
	}

}
