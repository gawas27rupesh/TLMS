package ai.rnt.bugtrackingsystem.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.constant.AttributeName;
import ai.rnt.bugtrackingsystem.constant.URLConstant;
import ai.rnt.bugtrackingsystem.dto.ProjectExisting;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.BusinessRequirement;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.BusinessRequirementService;
import ai.rnt.bugtrackingsystem.service.HomeService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.RtmService;
import ai.rnt.bugtrackingsystem.service.StatusService;

class HomeControllerTest {

	@Autowired
	MockMvc mockMvc;

	@Mock
	RedirectAttributes rbAttributes;

	@Mock
	ProjectMasterService projectMasterService;

	@Mock
	ProjectTeamService projectTeamService;

	@InjectMocks
	HomeController homeController;

	@Mock
	Model model;

	@Mock
	HttpSession session;

	@Mock
	StatusService statusService;

	@Mock
	BugService bugService;
	
	@Mock
	BusinessRequirementService businessRequirementService;

	@Mock
	RtmService rtmService;

	@Mock
	BusinessRequirementService brService;

	@Mock
	HttpServletRequest request;

	@Mock
	HomeService homeService;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(homeController).build();
	}

	//@Test
	void testTest1() {
		homeController.homeToPopup(model, session, rbAttributes);
		
		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		
		
		homeController.homeToPopup(model, session, rbAttributes);
	}

	//@Test
	void testTest2() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		assertNotNull(homeController.homeToPopupUrlEncode(projectId, rbAttributes, session, model));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);


	}

	@Test
	void getRtmforEditTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		assertNotNull(homeController.getRtmforEdit(session, 1, "BR_1", rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Integer projectId = 1;
		String brId = "";
		String result = homeController.getRtmforEdit(session, projectId, brId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.RTM_MAIN, result);
	}

	@Test
	void getRtmforExpandTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		assertNotNull(homeController.getRtmforExpand(session, 1, 2, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Optional<BusinessRequirement> br = Optional.of(new BusinessRequirement());
		when(brService.findBrById(1)).thenReturn(br);
		String result = homeController.getRtmforExpand(session, 1, 2, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.RTM_MAIN, result);
	}

	@Test
	void getRtmforDeleteTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer brId = 1;
		assertNotNull(homeController.getRtmforDelete(session, projectId, brId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getRtmforDelete(session, projectId, brId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.RTM_MAIN, result);
	}

	@Test
	void getRtmforAddTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		assertNotNull(homeController.getRtmforAdd(session, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getRtmforAdd(session, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.RTM_MAIN, result);
	}

	@Test
	void getScenarioforEditTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer rtmId = 1;
		assertNotNull(homeController.getScenarioforEdit(session, rtmId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Optional<Rtm> rtm = Optional.of(new Rtm());
		when(rtmService.findRtmById(rtmId)).thenReturn(rtm);
		String result = homeController.getScenarioforEdit(session, rtmId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_SCENARIO_MAIN, result);
	}

	@Test
	void getScenarioforExpandTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer rtmId = 1;
		assertNotNull(homeController.getScenarioforExpand(session, rtmId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Optional<Rtm> rtm = Optional.of(new Rtm());
		when(rtmService.findRtmById(rtmId)).thenReturn(rtm);
		String result = homeController.getScenarioforExpand(session, rtmId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_SCENARIO_MAIN, result);
	}

	@Test
	void getScenarioforDeleteTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer rtmId = 1;
		assertNotNull(homeController.getScenarioforDelete(session, rtmId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Optional<Rtm> rtm = Optional.of(new Rtm());
		when(rtmService.findRtmById(rtmId)).thenReturn(rtm);
		String result = homeController.getScenarioforDelete(session, rtmId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_SCENARIO_MAIN, result);
	}

	@Test
	void getScenarioforAddTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		assertNotNull(homeController.getScenarioforAdd(session, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getScenarioforAdd(session, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_SCENARIO_MAIN, result);
	}

	@Test
	void getTestCaseforEditTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer rtmId = 1;
		assertNotNull(homeController.getTestCaseforEdit(session, rtmId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Optional<Rtm> rtm = Optional.of(new Rtm());
		when(rtmService.findRtmById(rtmId)).thenReturn(rtm);
		String result = homeController.getTestCaseforEdit(session, rtmId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_CASE_MAIN, result);
	}

	@Test
	void getTestCaseforExpandTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer rtmId = 1;
		assertNotNull(homeController.getTestCaseforExpand(session, rtmId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		Optional<Rtm> rtm = Optional.of(new Rtm());
		when(rtmService.findRtmById(rtmId)).thenReturn(rtm);
		String result = homeController.getTestCaseforExpand(session, rtmId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_CASE_MAIN, result);
	}

	@Test
	void getTestCaseforDeleteTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer rtmId = 1;
		assertNotNull(homeController.getTestCaseforDelete(session, rtmId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestCaseforDelete(session, rtmId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_CASE_MAIN, result);
	}

	@Test
	void getTestCaseforAddTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		assertNotNull(homeController.getTestCaseforAdd(session, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestCaseforAdd(session, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TEST_CASE_MAIN, result);
	}

	@Test
	void getTestScriptforEditAdd() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer testCaseId = 1;
		assertNotNull(homeController.getTestScriptforEdit(session, testCaseId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestScriptforEdit(session, testCaseId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTSCRIPT, result);
	}

	@Test
	void getTestScriptforExpandTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer testCaseId = 1;
		assertNotNull(homeController.getTestScriptforExpand(session, testCaseId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestScriptforExpand(session, testCaseId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTSCRIPT, result);
	}

	@Test
	void getTestScriptforDeleteTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer testCaseId = 1;
		assertNotNull(homeController.getTestScriptforDelete(session, testCaseId, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestScriptforDelete(session, testCaseId, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTSCRIPT, result);
	}

	@Test
	void gettestScriptforAddTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		assertNotNull(homeController.gettestScriptforAdd(session, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.gettestScriptforAdd(session, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTSCRIPT, result);
	}

	@Test
	void getTestResultforEditTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		String testCaseId = "TS_1";
		String reqId = "FR_1.1";
		assertNotNull(homeController.getTestResultforEdit(session, reqId, projectId, testCaseId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestResultforEdit(session, reqId, projectId, testCaseId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTRESULT, result);
	}

	@Test
	void getTestResultforExpandTest() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		String testCaseId = "TS_1";
		String reqId = "FR_1.1";
		Integer caseId = 1;
		assertNotNull(
				homeController.getTestResultforExpand(session, reqId, testCaseId, projectId, caseId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestResultforExpand(session, reqId, testCaseId, projectId, caseId,
				rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTRESULT, result);
	}

	@Test
	void getTestResultforDelete() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		Integer caseId = 1;
		assertNotNull(homeController.getTestResultforDelete(session, projectId, caseId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.getTestResultforDelete(session, projectId, caseId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTRESULT, result);
	}

	@Test
	void gettestResultforAdd() {
		UserLoginDto userData = new UserLoginDto();
		session.setAttribute("userData", userData);
		Integer projectId = 1;
		assertNotNull(homeController.gettestResultforAdd(session, projectId, rbAttributes));
		Mockito.when(session.getAttribute("userData")).thenReturn(userData);
		rbAttributes.addFlashAttribute(AttributeName.MESSAGE, URLConstant.SESSION_MESSAGE);
		String result = homeController.gettestResultforAdd(session, projectId, rbAttributes);
		assertEquals(URLConstant.REDIRECT + URLConstant.TESTRESULT, result);
	}

	@Test
	 void getProjectsTest() throws MalformedURLException {
		String keyWord = "1";
		
		UserLoginDto userData = mock(UserLoginDto.class);
		List<ProjectExisting> projectList = new ArrayList<>();
		List<ProjectMaster> list2 = new ArrayList<>();
		ProjectExisting projectExisting = new ProjectExisting();
		projectExisting.setProjectName("tlms");
		projectList.add(projectExisting);
		userData.setProjectList(projectList);
		
		char[] statusList = {'a','h','i','c'};
		for(int j = 0; j <4; j++) {
			ProjectMaster master = new ProjectMaster();
			master.setProjectName("tlms");
			master.setProjectStatus(statusList[j]);
			list2.add(master);
		}
		
		List<Integer> projectId = new ArrayList<>();
		projectId.add(1);
		when(projectTeamService.getProjectByRoleAndStaffId(0, 0)).thenReturn(projectId);
		when(projectMasterService.findById(1)).thenReturn(list2.get(0));
		when(projectMasterService.findByKeyWord("1", projectId)).thenReturn(list2);
		when(userData.getProjectList()).thenReturn(projectList);
		when(projectMasterService.findAll()).thenReturn(list2);
		
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		homeController.getProjects(keyWord, session, "a", rbAttributes);
		homeController.getProjects(keyWord, session, "h", rbAttributes);
		homeController.getProjects(keyWord, session, "i", rbAttributes);
		homeController.getProjects(keyWord, session, "c", rbAttributes);
	
		when(userData.getRoleName()).thenReturn("developer");
		when(session.getAttribute("userData")).thenReturn(userData);
		homeController.getProjects(keyWord, session, "a", rbAttributes);

		when(userData.getRoleName()).thenReturn("user");
		when(session.getAttribute("userData")).thenReturn(userData);
		homeController.getProjects(keyWord, session, "a", rbAttributes);
		
	}
	
	/*
	 * //@Test void getDetailsByProjectIdTest() {
	 * homeController.getDetailsByProjectId(1, session);
	 * 
	 * UserLoginDto userData = new UserLoginDto();
	 * when(session.getAttribute("userData")).thenReturn(userData); Integer
	 * projectId = 1; ArrayList<BusinessRequirement> brList = new
	 * ArrayList<BusinessRequirement>(); brList.add(new BusinessRequirement());
	 * when(brService.findAllBrByProjectId(projectId)).thenReturn(brList);
	 * List<BusinessRequirement> rtmListActual =
	 * homeController.getDetailsByProjectId(projectId, session);
	 * assertNotEquals(brList, rtmListActual);
	 * 
	 * when(businessRequirementService.findAllBrByProjectId(1)).thenThrow(
	 * NullPointerException.class); homeController.getDetailsByProjectId(1,
	 * session);
	 * 
	 * }
	 */

	@Test
	void getStatus() {
		when(businessRequirementService.findBrStatus(1)).thenReturn(1);
		homeController.getStatus(1);
	}

	@Test
	void getPlanforEditTest() {
		assertNotNull(homeController.getPlanforEdit(session, null, null, rbAttributes));
		
		UserLoginDto userData = mock(UserLoginDto.class);
		when(session.getAttribute("userData")).thenReturn(userData);
		assertNotNull(homeController.getPlanforEdit(session, null, null, rbAttributes));
	}
	@Test
	void getPlanforViewTest() {
		assertNotNull(homeController.getPlanforView(session, null, null, rbAttributes));
		
		UserLoginDto userData = mock(UserLoginDto.class);
		when(session.getAttribute("userData")).thenReturn(userData);
		assertNotNull(homeController.getPlanforView(session, null, null, rbAttributes));
	}
	@Test
	void addTestPlanTest() {
		assertNotNull(homeController.addTestPlan(session, null, rbAttributes));
		
		UserLoginDto userData = mock(UserLoginDto.class);
		when(session.getAttribute("userData")).thenReturn(userData);
		assertNotNull(homeController.addTestPlan(session, null, rbAttributes));
	}

}
