package ai.rnt.bugtrackingsystem.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.constant.AttributeName;
import ai.rnt.bugtrackingsystem.constant.URLConstant;
import ai.rnt.bugtrackingsystem.dto.RbacDTO;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.repository.RoleMasterRepository;
import ai.rnt.bugtrackingsystem.service.EmployeeMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.util.Comparison;
import ai.rnt.bugtrackingsystem.util.StringFunctionality;

@ExtendWith(MockitoExtension.class)
class LoginControllerTest {

	@Mock
	Model model;

	@Mock
	RedirectAttributes redirectAttributes;

	@Mock
	HttpSession session;
	
	@Mock
	EmployeeMaster emp;
	
	@Mock
	HttpServletResponse response;

	@Mock
	HttpServletRequest request;

	@Mock
	private EmployeeMasterService employeeMasterService;

	@Mock
	StringFunctionality stringFunctionality;

	@Mock
	private Comparison comparison;

	@Mock
	RoleMasterRepository roleRepo;

	@Mock
	ProjectTeamService projectTeamService;

	@InjectMocks
	LoginController loginController;
	
	String result;
	

	
	//@Test
	void fromRntCorpTest() throws SQLException {
		Map<String, String> map = new HashMap<>();
		request.setAttribute("username", "xyz");
		request.setAttribute("password", "1234");
		//result  = loginController.fromRntCorp(request, session, redirectAttributes, response, null, model);
		map.put("username", "xyz");
		map.put("email", "xyz");
		map.put("password", "1234");
		map.put("backUrl", "/tlms/home");
		result  = loginController.fromRntCorp(request, session, redirectAttributes, response, null, model);
	}
	
	@Test
	void homePageTest() {
		EmployeeMaster emp = new EmployeeMaster();
		RbacDTO dto = new RbacDTO();
		dto.setUserRole("Tlms Admin");
		emp.setStaffId(1);
		emp.setFirstName("xyz");
		emp.setRole("tester");
		ArrayList<RbacDTO> list = new ArrayList<RbacDTO>();
		list.add(dto);
		loginController.homePage(model, session, redirectAttributes, request, response, null);
		
		
		Map<String, String> map = new HashMap<>();
		map.put("username", "xyz");
		map.put("password", "1234");
		map.put("backUrl", "/tlms/home");
		loginController.homePage(model, session, redirectAttributes, request, response, map);
		
		Map<Integer, String> singleRole = new HashMap<Integer, String>();
		singleRole.put(1, "key");
		when(employeeMasterService.findByUserIdAndPassword("xyz","7110eda4d09e062aa5e4a390b0a572ac0d2c0220")).thenReturn(emp);
		when(employeeMasterService.findRbackUseCases(1)).thenReturn(list);
		loginController.homePage(model, session, redirectAttributes, request, response, map);
		when(employeeMasterService.findByUserIdAndPassword("xyz","7110eda4d09e062aa5e4a390b0a572ac0d2c0220")).thenThrow(NullPointerException.class);
		loginController.homePage(model, session, redirectAttributes, request, response, map);
	}
	
	@Test
	void homePageTest2() {
		loginController.homePage(model, session, redirectAttributes, request, response, null);
		request.setAttribute(AttributeName.EMAIL, "xyz");
		request.setAttribute(AttributeName.PSWD, "xyz");
		loginController.homePage(model, session, redirectAttributes, request, response, null);
	}
	
	@Test
	void logOutTest() {
		result = loginController.logOut(session, model, redirectAttributes);
		
		UserLoginDto userData = mock(UserLoginDto.class);
		userData.setRoleName("tlmsAdmin");
		when(session.getAttribute("userData")).thenReturn(userData);
		result = loginController.logOut(session, model, redirectAttributes);
	}

}
