
package ai.rnt.bugtrackingsystem.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.ProjectTeamDto;
import ai.rnt.bugtrackingsystem.dto.TestCaseOptionDTO;
import ai.rnt.bugtrackingsystem.dto.TestScriptDto;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestScript;
import ai.rnt.bugtrackingsystem.repository.TestScriptRepository;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.RtmService;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.service.TestCaseService;
import ai.rnt.bugtrackingsystem.service.TestScenarioService;
import ai.rnt.bugtrackingsystem.service.TestScriptService;

@AutoConfigureMockMvc
class TestScriptControllerTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	TestScriptController testController;

	@Mock
	private TestScriptRepository testScriptRepo;

	@Mock
	RtmService rtmService;

	@Mock
	TestScriptService testScriptService;

	@Mock
	TestScenarioService testScenarioService;

	@Mock
	TestCaseService testCaseService;

	@Mock
	ProjectMasterService projectMasterService;

	@Mock
	StatusService statusService;

	@Mock
	ProjectTeamService projectTeamService;

	@Mock
	Model model;

	@Mock
	HttpSession session;

	@Mock
	RedirectAttributes red;
	
	@Mock
	HttpServletRequest request;

	@Mock
	ModelMap mp;
	
	@Mock
	HttpServletResponse response;
	
	@Mock
	BugService bugService;
	
	@Mock
	private List<TestScriptDto> testScriptDtoList;

	String result;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(testController).build();
	}
	

	@Test
	public void testSaveAllTestScript() throws Exception {
		// for session Expired
		result = testController.saveAllTestScript(request, session, red);
		
		UserLoginDto userData = new UserLoginDto();
		userData.setRoleName("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		when(request.getParameter("reqId")).thenReturn("1");
		when(request.getParameter("tscenId")).thenReturn("1");
		when(request.getParameter("tcaseId")).thenReturn("1");
		result = testController.saveAllTestScript(request, session, red);

		// for req.getParameter("reqId" + start_r) != null
		when(request.getParameter("Step"+1)).thenReturn("1");
		when(request.getParameter("stepId"+1)).thenReturn("1");
		when(request.getParameter("tSceId"+1)).thenReturn("1");
		when(request.getParameter("testSceId"+1)).thenReturn("1");
		when(request.getParameter("testDesc"+1)).thenReturn("1");
		TestScript script = new TestScript();
		when(testScriptService.findById(1)).thenReturn(script);
		result = testController.saveAllTestScript(request, session, red);
		
		// for req.getParameter("reqId" + start_r) == null
		when(request.getParameter("stepId"+1)).thenReturn("");
		Rtm rtm = new Rtm();
		ProjectMaster projectMaster = new ProjectMaster();
		rtm.setProjectMaster(projectMaster);
		//when(rtm.getProjectMaster()).thenReturn(projectMaster);
		result = testController.saveAllTestScript(request, session, red);
		
	}

	@Test
	public void testGetTestScript() throws Exception {
		// Setup
		Integer testScriptId = 1;
		TestScriptDto testScript1 = new TestScriptDto();
		testScript1.setStepDesc("Step 1");
		testScript1.setInputData("Input data for step 1");
		testScript1.setExpectedResult("Expected result for step 1");
		testScript1.setTestScriptId(1);
		List<TestScriptDto> testScriptList = new ArrayList<>();
		testScriptList.add(testScript1);
		when(testScriptService.getTestScriptById(testScriptId)).thenReturn(testScriptList);

		// Execution
		mockMvc.perform(post("/getByTestScript/{id}", testScriptId)).andExpect(status().isOk())
				.andReturn();

		// Verification
		List<TestScriptDto> testScript = new ArrayList<>();
		assertEquals(0, testScript.size());
	}

	@Test
	public void testDeleteByRtmId_Success() {
		// given
		Integer testScriptId = 1;
		when(testScriptRepo.updateStatusId(testScriptId, testScriptId)).thenReturn(testScriptId);

		// when
		testController.deleteByRtmId(testScriptId);

		
	}

	@Test
	public void testDeleteByRtmId_Error() {
		// given
		Integer testScriptId = 1;
		doThrow(new RuntimeException()).when(testScriptRepo).updateStatusId(testScriptId, null);

		// when
		testController.deleteByRtmId(testScriptId);

	
	}

	//@Test
	public void testGetTestCaseId() {
		Integer rtmId = 1;
		Integer testSceneId = 2;
		List<TestCase> expectedTestCases = new ArrayList<>();
		expectedTestCases.add(new TestCase());
		when(testCaseService.findByRtmAndTestScenario(rtmId, testSceneId)).thenReturn(expectedTestCases);

		List<TestCaseOptionDTO> actualTestCases = testController.getTestCaseId(rtmId, testSceneId);

		assertEquals(expectedTestCases, actualTestCases);
	}

	@Test
	public void testGetAllProjectById3() {
		int projectId = 1;
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);

		List<TestScriptDto> expectedTestScriptDtos = new ArrayList<>();
		expectedTestScriptDtos.add(new TestScriptDto());
		when(testScriptService.getTestScriptById(projectId)).thenReturn(expectedTestScriptDtos);

		List<TestScriptDto> actualTestScriptDtos = testController.getAllProjectById3(projectId, session);

		assertEquals(expectedTestScriptDtos, actualTestScriptDtos);
	}

	@Test
	public void testGetAllProjectById() {
		int projectId = 1;
		int caseId = 1;

		List<TestScriptDto> expectedTestScriptDtos = new ArrayList<>();
		expectedTestScriptDtos.add(new TestScriptDto());
		when(testScriptService.FetchEditFromRtmId(caseId, projectId)).thenReturn(expectedTestScriptDtos);

		List<TestScriptDto> actualTestScriptDtos = testController.getAllProjectById(projectId, caseId, session);

		assertEquals(expectedTestScriptDtos, actualTestScriptDtos);
	}

	@Test
	public void testEditTestScriptByProjectId() {
		int projectId = 1;
		int caseId = 1;

		List<TestScriptDto> expectedTestScriptDtos = new ArrayList<>();
		expectedTestScriptDtos.add(new TestScriptDto());
		when(testScriptService.FetchEditFromRtmId(caseId, projectId)).thenReturn(expectedTestScriptDtos);

		List<TestScriptDto> actualTestScriptDtos = testController.editTestScriptByProjectId(projectId, caseId, session);

		assertEquals(expectedTestScriptDtos, actualTestScriptDtos);
	}

	@Test
	public void testUpdateStatus() {
		int projectId = 1;
		int statusId = 1;

		when(testScriptService.updateAllByProjectId(projectId, statusId)).thenReturn(1);

		ResponseEntity<String> response = testController.updateStatus(projectId, statusId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("success", response.getBody());
	}

	@Test
	public void testUpdateStatus_failure() {
		int projectId = 1;
		int statusId = 1;

		when(testScriptService.updateAllByProjectId(projectId, statusId)).thenReturn(0);

		ResponseEntity<String> response = testController.updateStatus(projectId, statusId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("error", response.getBody());
	}

	@Test
	public void testGetStatus() {
		// Initialize the TestScriptService instance
		TestScriptService testScriptService = mock(TestScriptService.class);

		// Call the getStatus method
		Integer projectId = 1;
		Integer expectedResult = 2;
		when(testScriptService.findTestScriptStatus(projectId)).thenReturn(expectedResult);
		ResponseEntity<Integer> response = testController.getStatus(projectId);

		// Verify the result
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotEquals(expectedResult, response.getBody());
	}

	@Test
	void testEditRtmByRtmAndProjectId() {
		when(testScriptService.ExpandForTestScript("caseId", 1)).thenReturn(testScriptDtoList);

		List<TestScriptDto> result = testController.editRtmByRtmAndProjectId(1, "caseId", session);

		assertNotEquals(testController, result);
		verify(testScriptService).ExpandForTestScript("caseId", 1);
	}

	@Test
	void testGetTestCaseName() {
		TestCase testCase = new TestCase();
		when(testCaseService.findById(1)).thenReturn(testCase);
		String currentName = testController.getTestCaseName(1);
		assertEquals(currentName, result);
	}

	@Test
	public void downloadExcelReportTest() {
		ProjectMaster projectMaster = new ProjectMaster();
		when( projectMasterService.findById(1)).thenReturn(projectMaster);
		when(bugService.findBugCount(1)).thenReturn(10);
		List<ProjectTeamDto> project = new ArrayList<>();
		ProjectTeamDto  projectTeamDto = new ProjectTeamDto();
		projectTeamDto.setRole("tester");
		project.add(projectTeamDto);
		when(projectTeamService.findProjectTesterByProjectId(1)).thenReturn(project);
		testController.downloadExcelReport(1, request, response, mp);
	}

	@Test
	public void whenValidData_thenUpdateTestScript() {
		// Given
		Integer testScriptId = 1;
		String scriptStepDesc = "Step 1";
		String inputData = "Test data";
		String expectedResult = "Expected result";

		TestScript testScript = new TestScript();
		testScript.setTestScriptId(testScriptId);
		testScript.setScriptStepDesc(scriptStepDesc);
		testScript.setInputData(inputData);
		testScript.setExpectedResult(expectedResult);

		// When
		when(testScriptService.findById(testScriptId)).thenReturn(testScript);
		when(testScriptService.save(testScript)).thenReturn(testScript);

		testController.updateTestScipt(testScriptId, scriptStepDesc, inputData, expectedResult, session);
	}

}
