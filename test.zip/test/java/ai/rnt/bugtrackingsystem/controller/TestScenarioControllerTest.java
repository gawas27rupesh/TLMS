package ai.rnt.bugtrackingsystem.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.ProjectTeamDto;
import ai.rnt.bugtrackingsystem.dto.TestScenarioDto;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.Status;
import ai.rnt.bugtrackingsystem.entity.TestScenario;
import ai.rnt.bugtrackingsystem.repository.ProjectTeamRepository;
import ai.rnt.bugtrackingsystem.repository.RtmRepository;
import ai.rnt.bugtrackingsystem.repository.TestScenarioRepository;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.service.TestScenarioService;

class TestScenarioControllerTest {

	@Autowired
	MockMvc mockMvc;

	@Mock
	Model model;

	@Mock
	HttpSession session;
	
	@Mock
	HttpServletRequest request;

	@Mock
	RedirectAttributes rbAttributes;

	@InjectMocks
	TestScenarioController scenarioController;

	@Mock
	TestScenarioService testScenarioService;

	@Mock
	ProjectMasterService projectMasterService;

	@Mock
	TestScenarioRepository testScenarioRepository;

	@Mock
	RtmRepository rtmRepository;

	@Mock
	ProjectTeamRepository projectTeamRepository;

	@Mock
	ProjectTeamService projectTeamService;

	@Mock
	BugService bugService;

	@Mock
	StatusService statusService;
	
	String result;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(scenarioController).build();
	}
	
	

	/*
	 * @Test void getAllProjectList() { // for session expired
	 * scenarioController.getAllProjectList(null, session);
	 * 
	 * // else UserLoginDto userData = new UserLoginDto();
	 * when(session.getAttribute("userData")).thenReturn(userData); Integer
	 * projectId = 1; List<Rtm> scenarioTest = new ArrayList<Rtm>();
	 * scenarioTest.add(new Rtm());
	 * when(rtmRepository.findByProjectMasterProjectID1(projectId)).thenReturn(
	 * scenarioTest); scenarioController.getAllProjectList(projectId, session); }
	 */

	@Test
	void getAllProjectList1() {
		// for session expired
		//scenarioController.getAllProjectById1(null, session);
		
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);
		Integer projectId = 1;
		ProjectMaster scenarioTest = new ProjectMaster();
		when(projectMasterService.findById(projectId)).thenReturn(scenarioTest);
		//scenarioController.getAllProjectById1(projectId, session);
		// assertEquals(rtmTest, actualTest);
	}

	@Test
	void getAllProjectById2() {
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);
		Integer projectId = 1;
		List<TestScenarioDto> scenarioTest = new ArrayList<TestScenarioDto>();
		scenarioTest.add(new TestScenarioDto());
		when(testScenarioService.getTestScenarioDataByProjectId(projectId)).thenReturn(scenarioTest);
		List<TestScenarioDto> actualTest = scenarioController.getAllProjectById2(projectId, session);
		assertEquals(scenarioTest, actualTest);
	}

	@Test
	void getTestScenarioById() {
		Integer testScenarioId = 1;
		TestScenario scenarioTest = new TestScenario();
		when(testScenarioService.getReferenceById(testScenarioId)).thenReturn(scenarioTest);
		TestScenario actualTest = scenarioController.getTestScenarioById(testScenarioId);
		assertEquals(scenarioTest, actualTest);
	}
	
	//@Test
	void saveAllTestCasesTest() {
		// for session Expired
		result = scenarioController.saveAllTestCases(request, session, rbAttributes);
		
		
		UserLoginDto userData = new UserLoginDto();
		userData.setRoleName("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		when(request.getParameter("projectId")).thenReturn("1");
		result = scenarioController.saveAllTestCases(request, session, rbAttributes);

		// for req.getParameter("reqId" + start_r) != null
		when(request.getParameter("reqId"+1)).thenReturn("1");
		when(request.getParameter("tSceId"+1)).thenReturn("1");
		when(request.getParameter("testSceId"+1)).thenReturn("1");
		when(request.getParameter("testDesc"+1)).thenReturn("1");
		TestScenario testScenario = new TestScenario();
		when(testScenarioService.findById(1)).thenReturn(testScenario);
		result = scenarioController.saveAllTestCases(request, session, rbAttributes);
		
		
//		when(request.getParameter("tSceId"+1)).thenReturn("");
//		Rtm rtm = new Rtm();
//		ProjectMaster projectMaster = new ProjectMaster();
//		projectMaster.setProjectID(1);
//		rtm.setProjectMaster(projectMaster);
//		when(testScenario.getRtm()).thenReturn(rtm);
//		result = scenarioController.saveAllTestCases(request, session, rbAttributes);
	}

	@Test
	public void testScenarioSaveTest() {
		TestScenarioDto testSceDto = new TestScenarioDto();
		testSceDto.setTestScenarioId("123");
		testSceDto.setTestScenarioDescription("Test Scenario");
		testSceDto.setRequirementId("456");
		testSceDto.setProjectId(7);

		HttpSession session = mock(HttpSession.class);
		UserLoginDto userData = new UserLoginDto();
		userData.setStaffId(1304);
		when(session.getAttribute("userData")).thenReturn(userData);

		HttpServletRequest req = mock(HttpServletRequest.class);
		RedirectAttributes red = mock(RedirectAttributes.class);

		Rtm rtm = new Rtm();
		rtm.setRtmId(123);
		rtm.setProjectMaster(new ProjectMaster());
		when(rtmRepository.findByReqIdAndProjectMaster(testSceDto.getRequirementId(), testSceDto.getProjectId()))
				.thenReturn(rtm);

		// test for if condition
		testSceDto.setScenarioId(1);
		TestScenario testScenario = new TestScenario();
		testScenario.setTestScenarioId("TS_1");
		testScenario.setTestScenarioDescription("Test testScenario");
		testScenario.setRtm(rtm);
		testScenario.setCreatedBy(1304);
		testScenario.setCreatedDate(LocalDateTime.now());
		testScenario.setProjectMaster(rtm.getProjectMaster());
		when(testScenarioService.findById(testSceDto.getScenarioId())).thenReturn(testScenario);
		when(testScenarioService.save(testScenario)).thenReturn(testScenario);
		when(testScenarioService.getDataforAddTabel(rtm.getRtmId())).thenReturn(Collections.emptyList());

		//List<TestScenarioDto> result = scenarioController.addTestScenario(testSceDto, req, session, red);
//		assertThat(result).isNotNull();
//		verify(testScenarioService).findById(testSceDto.getScenarioId());
//		verify(testScenarioService).save(testScenario);
//		verify(testScenarioService).getDataforAddTabel(rtm.getRtmId());

		// test for else condition
		testSceDto.setScenarioId(null);
		when(testScenarioService.findById(testSceDto.getScenarioId())).thenReturn(null);
		when(testScenarioService.save(ArgumentMatchers.any(TestScenario.class))).thenReturn(new TestScenario());
		//result = scenarioController.addTestScenario(testSceDto, req, session, red);
//		assertThat(result).isNotNull();
//		verify(testScenarioService).findById(ArgumentMatchers.any());
//		verify(testScenarioService, times(2)).save(ArgumentMatchers.any(TestScenario.class));
//		verify(testScenarioService, times(2)).getDataforAddTabel(rtm.getRtmId());

	}

	@Test
	void getRtmAndTestScenario() {
		Integer projectId = 1;
		List<Map<String, String>> scenarioTest = new ArrayList<Map<String, String>>();
		when(testScenarioService.findTestScenarioByRtmId(projectId)).thenReturn(scenarioTest);
		List<Map<String, String>> actualTest = scenarioController.getRtmAndTestScenario(projectId);
		assertEquals(scenarioTest, actualTest);
		verify(testScenarioService).findTestScenarioByRtmId(1);
	}

	@Test
	void getAllProjectById() {
		Integer projectId = 1;
		List<TestScenario> scenarioTest = new ArrayList<TestScenario>();
		scenarioTest.add(new TestScenario());
		when(testScenarioRepository.findByRtmId(projectId)).thenReturn(scenarioTest);
		List<TestScenario> actualTest = scenarioController.getAllProjectById(projectId);
		assertEquals(scenarioTest, actualTest);
		//verify(testScenarioService).findByRtmId(projectId);
	}

	@Test
	void getExpandData() {
		Integer rtmId = 1;
		List<TestScenarioDto> scenarioTest = new ArrayList<TestScenarioDto>();
		scenarioTest.add(new TestScenarioDto());
		when(testScenarioService.expandDataTestScenario(rtmId)).thenReturn(scenarioTest);
		List<TestScenarioDto> actualTest = scenarioController.getExpandData(rtmId);
		assertEquals(scenarioTest, actualTest);
		verify(testScenarioService).expandDataTestScenario(rtmId);
	}

	@Test
	public void deleteScenarioIdSuccess() {
		result = scenarioController.delete(null, session);
		
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);
		Integer rtmId = 1;
		Integer testSceId = 1;
		Integer projectId = 1;
		TestScenario testScenario = new TestScenario();
		testScenario.setTestScenarioId("TS_1");
		Rtm rtm = new Rtm();
		rtm.setReqId("FR_1.1");
		ProjectMaster project = new ProjectMaster();
		project.setProjectID(projectId);
		testScenario.setRtm(rtm);
		testScenario.setProjectMaster(project);
		when(testScenarioService.findById(rtmId)).thenReturn(testScenario);
		scenarioController.delete(testSceId, session);

	}

	@Test
	public void deleteScenarioIdSuccess2() {
		result = scenarioController.deleteByRtmId(null);
		
		Integer rtmId = 1;
		Integer testSceId = 1;
		Integer projectId = 1;
		TestScenario testScenario = new TestScenario();
		testScenario.setTestScenarioId("TS_1");
		Rtm rtm = new Rtm();
		rtm.setReqId("FR_1.1");
		ProjectMaster project = new ProjectMaster();
		project.setProjectID(projectId);
		testScenario.setRtm(rtm);
		testScenario.setProjectMaster(project);
		when(testScenarioService.findById(rtmId)).thenReturn(testScenario);
		String result = scenarioController.deleteByRtmId(testSceId);
		assertEquals("success", result);
		verify(testScenarioService, times(1)).findById(testSceId);
		verify(testScenarioService, times(1)).suffleTS_No(rtm.getRtmId(),
				testScenario.getProjectMaster().getProjectID());

	}
	
	@Test
	void updateTestScenarioTest() {
		scenarioController.updateTestScenario(request, rbAttributes, session);
		
		UserLoginDto userData = new UserLoginDto();
		userData.setRoleName("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		when(request.getParameter("projectId")).thenReturn("1");
		when(request.getParameter("reqId"+1)).thenReturn("11");
		when(request.getParameter("scenarioId"+1)).thenReturn("11");
		when(request.getParameter("testSceId"+1)).thenReturn("11");
		when(request.getParameter("testSceDesc"+1)).thenReturn("11");
		scenarioController.updateTestScenario(request, rbAttributes, session);
	}

	@Test
	void getAllDataForAddTestCase() {
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);
		Integer rtmId = 1;
		List<TestScenarioDto> scenarioTest = new ArrayList<TestScenarioDto>();
		scenarioTest.add(new TestScenarioDto());
		when(testScenarioService.getDataforAddTabel(rtmId)).thenReturn(scenarioTest);
		List<TestScenarioDto> actualTest = scenarioController.getAllDataForAddTestCase(rtmId, session);
		assertEquals(scenarioTest, actualTest);
	}


	@Test
	void openListPopUPForTestCase() {
		Integer projectId = 1;
		scenarioController.openListPopUPForTestCase(projectId, rbAttributes);
	}

	@Test
	public void duplicateRecordOrNot_WithValidData_ReturnsSuccess() {
		// Arrange
		String testSceId = "TS_1";
		Integer projectId = 1;
		Integer rtmId = 2;

		when(testScenarioService.checkDuplicateTestScenario(testSceId, projectId, rtmId)).thenReturn(true);

		// Act
		String result = scenarioController.duplicateRecordOrNot(testSceId, projectId, rtmId);

		// Assert
		assertEquals("success", result);
		verify(testScenarioService).checkDuplicateTestScenario(testSceId, projectId, rtmId);
	}

	@Test
	public void duplicateRecordOrNot_WithException_ReturnsError() {
		// Arrange
		String testSceId = "TS_1";
		Integer projectId = 1;
		Integer rtmId = 2;

		doThrow(new RuntimeException()).when(testScenarioService).checkDuplicateTestScenario(testSceId, projectId,
				rtmId);

		// Act
		String result = scenarioController.duplicateRecordOrNot(testSceId, projectId, rtmId);

		// Assert
		assertEquals("error", result);
		verify(testScenarioService).checkDuplicateTestScenario(testSceId, projectId, rtmId);
	}

	@Test
	public void updateStatus() {
		Integer projectId = 1;
		Integer statusId = 2;
		when(testScenarioService.updateAllByProjectIdStatus(projectId, statusId)).thenReturn(projectId);
		ResponseEntity<String> response = scenarioController.updateStatus(projectId, statusId);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("success", response.getBody());
	}

	@Test
	public void getStatus() {
		Integer projectId = 1;
		Integer status = 1;
		when(testScenarioService.findTestScenarioStatus(projectId)).thenReturn(projectId);
		ResponseEntity<Integer> response = scenarioController.getStatus(projectId);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(status, response.getBody());
	}

	@Test
	public void downloadExcelReport() {
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);
		Integer projectId = 1;
		Integer count = 5;
		List<TestScenarioDto> exportData = Arrays.asList(new TestScenarioDto(), new TestScenarioDto());
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setBug(count);
		String status = "Success";
		Status s = new Status();
		s.setStatus(status);
		ModelMap mp = mock(ModelMap.class);

		when(testScenarioService.getExcelReportData(projectId)).thenReturn(exportData);
		when(bugService.findBugCount(projectId)).thenReturn(count);
		when(projectMasterService.findById(projectId)).thenReturn(projectMaster);
		List<ProjectTeamDto> project1 = new ArrayList<>();
		ProjectTeamDto  projectTeamDto = new ProjectTeamDto();
		projectTeamDto.setRole("tester");
		project1.add(projectTeamDto);
		when(projectTeamService.findProjectTesterByProjectId(1)).thenReturn(project1);		// when(statusService.findById(Mockito.anyInt())).thenReturn(s);
		when(testScenarioService.findStatusByProjectId(projectId)).thenReturn("completed");

		//ModelAndView result = scenarioController.exportExcel(projectId, mp);

//		verify(testScenarioService).getExcelReportData(projectId);
//		verify(bugService).findBugCount(projectId);
//		verify(projectMasterService).findById(projectId);
//		verify(projectTeamService).findProjectTesterByProjectId(projectId);
		// verify(statusService).findById(Mockito.anyInt());
		//verify(testScenarioService).findStatusByProjectId(projectId);
		//assertThat(result).isNotNull();
		//assertThat(result.getView()).isInstanceOf(ExportToExcelTestScenario.class);
	}

	@Test
	public void getAutoPopulatedTestScenarioId() {
		Integer projectId = 1;
		Integer rtmId = 1;
		String testScenarioId = "TS_1";
		when(testScenarioService.getAutoGenerated(projectId, rtmId, testScenarioId)).thenReturn("TS_1");
		scenarioController.getAutoPopulatedTestScenarioId(projectId, rtmId, testScenarioId);
		verify(testScenarioService).getAutoGenerated(projectId, rtmId, testScenarioId);
	}

	@Test
	public void updateScenarioSuccess() {
		UserLoginDto userData = new UserLoginDto();
		userData.setStaffId(1);
		when(session.getAttribute("userData")).thenReturn(userData);

		TestScenario existingTestSce = new TestScenario();
		existingTestSce.setTestScenarioId("TS_1");
		existingTestSce.setTestScenarioDescription("Test Scenario Description");
		when(testScenarioService.findById(1)).thenReturn(existingTestSce);

		TestScenario updatedTestSce = new TestScenario();
		updatedTestSce.setTestScenarioId("TS_1");
		updatedTestSce.setTestScenarioDescription("Test Scenario Description");
		updatedTestSce.setUpdatedBy(1);
		updatedTestSce.setUpdatedDate(LocalDateTime.now());
		when(testScenarioService.save(existingTestSce)).thenReturn(updatedTestSce);

		String result = scenarioController.updateTestCase(1, "Test Scenario Description", session);
		assertEquals("success", result);
	}

	@Test
	public void updateTestScenarioError() {
		UserLoginDto userData = new UserLoginDto();
		userData.setStaffId(1);
		when(session.getAttribute("userData")).thenReturn(userData);

		TestScenario existingTestSce = new TestScenario();
		existingTestSce.setTestScenarioId("TS_1");
		existingTestSce.setTestScenarioDescription("Test Scenario Description");
		when(testScenarioService.findById(1)).thenReturn(existingTestSce);

		when(testScenarioService.save(existingTestSce)).thenReturn(null);

		String result = scenarioController.updateTestCase(1, "Test Scenario Description", session);
		assertEquals("error", result);
	   }
	

}
