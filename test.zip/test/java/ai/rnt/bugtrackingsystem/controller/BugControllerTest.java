package ai.rnt.bugtrackingsystem.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.entity.BugDefectType;
import ai.rnt.bugtrackingsystem.entity.BugImage;
import ai.rnt.bugtrackingsystem.entity.BugPriority;
import ai.rnt.bugtrackingsystem.entity.BugSeverity;
import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.StatusByDeveloper;
import ai.rnt.bugtrackingsystem.entity.StatusByTester;
import ai.rnt.bugtrackingsystem.entity.TestResult;
import ai.rnt.bugtrackingsystem.entity.TestScript;
import ai.rnt.bugtrackingsystem.service.BugDefectTypeService;
import ai.rnt.bugtrackingsystem.service.BugImageService;
import ai.rnt.bugtrackingsystem.service.BugLinkService;
import ai.rnt.bugtrackingsystem.service.BugPriorityService;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.BugSeverityService;
import ai.rnt.bugtrackingsystem.service.BugVideoService;
import ai.rnt.bugtrackingsystem.service.EmployeeMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.RoleMasterService;
import ai.rnt.bugtrackingsystem.service.RtmService;
import ai.rnt.bugtrackingsystem.service.StatusByDeveloperService;
import ai.rnt.bugtrackingsystem.service.StatusByTesterService;
import ai.rnt.bugtrackingsystem.service.TestCaseService;
import ai.rnt.bugtrackingsystem.service.TestResultService;
import ai.rnt.bugtrackingsystem.service.TestScenarioService;
import ai.rnt.bugtrackingsystem.service.TestScriptService;

class BugControllerTest {
	@Autowired
	MockMvc mockMvc;
	@Mock
	BugImage fileInfo;
	@Mock
	Model model;
	@Mock
	ModelMap mp;
	@Mock
	RedirectAttributes redirectAttributes;
	@Mock
	HttpSession session;
	@Mock
	HttpServletResponse response;
	@Mock
	HttpServletRequest request;
	@Mock
	UserLoginDto userLoginDto;
	@Mock
	TestCaseService testCaseService;
	@Mock
	ProjectMasterService projectMasterService;
	@Mock
	TestScenarioService testScenarioService;
	@Mock
	RtmService rtmService;
	@Mock
	BugService bugService;
	@Mock
	RoleMasterService roleRepo;
	@Mock
	TestScriptService testScriptService;
	@Mock
	TestResultService testResultService;
	@Mock
	BugImageService bugImageService;
	@Mock
	BugLinkService bugLinkService;
	@Mock
	BugPriorityService bugPriorityService;
	@Mock
	BugSeverityService bugSeverityService;
	@Mock
	BugDefectTypeService bugDefectTypeService;
	@Mock
	StatusByTesterService statusByTesterService;
	@Mock
	StatusByDeveloperService statusByDeveloperService;
	@Mock
	EmployeeMasterService employeeMasterService;
	@Mock
	ProjectTeamService projectTeamService;
	@Mock
	static EmployeeMaster employeeMaster;
	@Mock
	DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
	ProjectMaster projectMaster = new ProjectMaster();

	@Mock
	BufferedImage bufferedImage;
	@Mock
	Bug bug;

	static Bug bug1;
	@Mock
	BugVideoService bugVideoService;

	@InjectMocks
	BugController bugController;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(bugController).build();
	}

	@BeforeAll
	static void setValue() {
		bug1 = new Bug();
		//bug1.setId(1);
		bug1.setAssignedDate("21-02-2023");
		bug1.setClosedDate("21-02-2023");
		bug1.setReopenDate("21-02-2023");
		bug1.setResolvedDate("21-02-2023");

		ProjectMaster projectMaster = mock(ProjectMaster.class);
		projectMaster.setProjectName("TLMS");
		projectMaster.setProjectID(1);
		bug1.setProjectMaster(projectMaster);
		EmployeeMaster employeeMaster = mock(EmployeeMaster.class);
		bug1.setEmployeeMaster(employeeMaster);

		TestScript testScript = new TestScript();
		TestResult testResult = new TestResult();
		testResult.setResultScreenshot("");
		testScript.setTestResult(testResult);
		bug1.setTestScript(testScript);

		BugPriority bugPriority = new BugPriority();
		BugSeverity bugSeverity = new BugSeverity();
		StatusByTester statusByTester = new StatusByTester();
		StatusByDeveloper statusByDeveloper = new StatusByDeveloper();
		BugDefectType bugDefectType = new BugDefectType();
		bug1.setBugPriority(bugPriority);
		bug1.setBugSeverity(bugSeverity);
		bug1.setStatByTester(statusByTester);
		bug1.setStatByDeveloper(statusByDeveloper);
		bug1.setBugDefectType(bugDefectType);
	}



	//@Test
	void saveBugTest2() throws IOException {
		String str = "tlms project.jpg";
		byte[] bytes = str.getBytes();
		MultipartFile file2 = new MockMultipartFile(str, str, str, bytes);
		MultipartFile[] inputHiddenFile = new MultipartFile[2];
		// inputHiddenFile[0] = file;
		inputHiddenFile[0] = file2;
		Rtm rtm = new Rtm();
		rtm.setReqId("1");
		BugPriority bp = new BugPriority();
		bp.setPriorityId(1);
		BugSeverity bs = new BugSeverity();
		bs.setSeverityId(1);
		BugDefectType bd = new BugDefectType();
		bd.setDefectTypeId(1);
		StatusByTester st = new StatusByTester();
		st.setStatusTesterId(1);
		TestScript tsData = new TestScript();
		TestResult trs = new TestResult();
		trs.setImageName("tlms");
		trs.setResultScreenshot("tlms");
		tsData.setTestResult(trs);

		UserLoginDto userData = mock(UserLoginDto.class);
		//bugController.saveBug(null, redirectAttributes, session, mp);

		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		when(rtmService.findRtmById(null)).thenReturn(Optional.of(rtm));
		when(bugPriorityService.findById(null)).thenReturn(bp);
		when(bugSeverityService.findById(null)).thenReturn(bs);
		when(bugDefectTypeService.findById(null)).thenReturn(bd);
		when(statusByTesterService.findById(null)).thenReturn(st);
		when(testScriptService.findById(null)).thenReturn(tsData);
		//when(bugService.save(any(Bug.class))).thenReturn(bug1);
		
		when(bufferedImage.getWidth()).thenReturn(1);
		//bugController.saveBug(null, redirectAttributes, session, mp);
	}

	@Test
	void deleteBugTest() {
		setValue();
		when(bugService.getBugId(1)).thenReturn(bug1);
		//bugController.deleteBug(1, redirectAttributes);
	}

	//@Test
	void getCreteBugInfoTest() {

		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		when(projectMasterService.findById(1)).thenReturn(projectMaster);
		ArrayList<StatusByTester> list = new ArrayList<>();
		StatusByTester ts = new StatusByTester();
		ts.setStatusByTester("success");
		list.add(ts);
		StatusByTester ts1 = new StatusByTester();
		ts1.setStatusByTester("success");
		list.add(ts1);
		when(statusByTesterService.findAll()).thenReturn(list);
	//	assertNotNull(bugController.getCreteBugInfo(1, session));
	}


	@Test
	void getViewBugDeatilsByIdForAdminTest() {
		setValue();
		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);

		when(bugService.findById(1)).thenReturn(Optional.of(bug1));

		// bugObj3.isPresent()
		TestResult testResult = new TestResult();
		testResult.setResultScreenshot("tlms");
		List<TestResult> list = new ArrayList<>();
		list.add(testResult);
		when(testResultService.findByTestscriptId(0)).thenReturn(list);
		bugController.getViewBugDeatilsByIdForAdmin(request, 1, session);

		when(bugService.findById(1)).thenReturn(null);
		bugController.getViewBugDeatilsByIdForAdmin(request, 1, session);

	}
	
	@Test
	void checkRepeatedBugIdTest() {
		assertNotNull(bugController.checkRepeatedBugId("1", 1));
		bugController.checkRepeatedBugId(null, null);
	}

	@Test
	void exportToExcelBugTest() {
		Bug bug = new Bug();
		bug.setProjectMaster(projectMaster);
		bug.setCreatedBy(1);
		ArrayList<Bug> bList = new ArrayList<Bug>();
		bug.setStatusByTester("Open");
		bList.add(bug);
		//when(bugService.findAllBugByProjectId(1)).thenReturn(bList);
		EmployeeMaster employeeMaster = new EmployeeMaster();
		employeeMaster.setFirstName("Ganesh");
		employeeMaster.setLastName("Shinde");
		when(employeeMasterService.findById(1)).thenReturn(employeeMaster);
		assertNotNull(bugController.exportToExcelBug(mp, response, 1));
	}

	@Test
	void getBugByIdTest(){
		when(bugService.findById(1)).thenReturn(Optional.of(bug1));
		//bugController.getBugById(1);
	}
}