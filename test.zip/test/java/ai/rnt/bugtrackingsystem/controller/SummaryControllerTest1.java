package ai.rnt.bugtrackingsystem.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.SummaryDto;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.BugImage;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.SummaryService;

class SummaryControllerTest1 {

	@Autowired
	MockMvc mockMvc;
	@Mock
	BugImage fileInfo;
	@Mock
	Model model;
	@Mock
	ModelMap mp;
	@Mock
	RedirectAttributes redirectAttributes;
	@Mock
	HttpSession session;
	@Mock
	HttpServletResponse response;
	@Mock
	HttpServletRequest request;

	@Mock
	SummaryService summaryService;

	@Mock
	ProjectMasterService projectMasterService;

	@Mock
	ProjectTeamService projectTeamService;

	@InjectMocks
	SummaryController summaryController;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(summaryController).build();
	}
	
	@Test
	void summaryPageTest() {
		// for session expired
		summaryController.summaryPage(model, session, redirectAttributes);
		
		// for tlms admin condition 
		UserLoginDto userData = mock(UserLoginDto.class);
		userData.setRoleId(1);
		userData.setStaffId(1);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		
		ProjectMaster master = new ProjectMaster();
		List<ProjectMaster> projectData =new ArrayList<ProjectMaster>();
		projectData.add(master);
		when(projectMasterService.findAll()).thenReturn(projectData);
		//summaryController.summaryPage(model, session, redirectAttributes);
		
		// for else condition 
		when(userData.getRoleName()).thenReturn("user");
		when(session.getAttribute("userData")).thenReturn(userData);
		
		List<Integer> IntList = new ArrayList<>();
		IntList.add(1);
		when(projectTeamService.getProjectByRoleAndStaffId(0, 0)).thenReturn(IntList);
		ProjectMaster projectMaster=new ProjectMaster();
		when(projectMasterService.findById(1)).thenReturn(projectMaster);
		//summaryController.summaryPage(model, session, redirectAttributes);
		
		// for catch block
		//when(projectMasterService.findAll()).thenReturn(null);
		//summaryController.summaryPage(model, session, redirectAttributes);
	}
	
	@Test
	void getAllSummaryDetailsTest() {
		summaryController.getAllSummaryDetails(1, model, session);
		
		BigDecimal i = BigDecimal.ONE;
		SummaryDto summaryDto = new SummaryDto();
		summaryDto.setClosed(i);
		summaryDto.setOpen(i);
		summaryDto.setReopen(i);
		List<SummaryDto> summary= new ArrayList<>();
		summary.add(summaryDto);
		when(summaryService.getAllDetails(1)).thenReturn(summary);
		summaryController.getAllSummaryDetails(1, model, session);
		
		when(summaryService.getAllDetails(1)).thenReturn(null);
		summaryController.getAllSummaryDetails(1, model, session);
	}
	

}
