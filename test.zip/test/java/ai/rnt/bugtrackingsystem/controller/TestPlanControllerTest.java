package ai.rnt.bugtrackingsystem.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.constant.AttributeName;
import ai.rnt.bugtrackingsystem.dto.ProjectMasterSelectDTO;
import ai.rnt.bugtrackingsystem.dto.RbacDTO;
import ai.rnt.bugtrackingsystem.dto.TestPlanDto;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.TestPlan;
import ai.rnt.bugtrackingsystem.repository.TestCaseRepository;
import ai.rnt.bugtrackingsystem.service.DataFilterFunction;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.service.TestPlanService;

class TestPlanControllerTest {

	@Mock
	MockMvc mockMvc;

	@Mock
	TestCaseRepository testRepo;

	@Mock
	private ProjectMasterService projectMasterService;

	@Mock
	ProjectTeamService projectTeamService;

	@Mock
	StatusService statusService;

	@Mock
	TestPlanService testPlanService;

	@Mock
	TestPlanService planService;

	@InjectMocks
	TestPlanController testPlanController;

	@Mock
	Model model;

	@Mock
	RedirectAttributes redirectAttributes;

	@Mock
	HttpSession session;

	@Mock
	HttpServletResponse response;

	@Mock
	HttpServletRequest request;
	
	@Mock
	DataFilterFunction multipleUsefFunction;
	
	@Mock
	ModelMapper modelMapper;

	String result;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(testPlanController).build();
	}

	@Test
	void testPlanViewTest() {
		
		UserLoginDto userData = new UserLoginDto();
		List<RbacDTO> rbacDTOList = new ArrayList<RbacDTO>();
		userData.setRbacDTOList(rbacDTOList);
		when(session.getAttribute(AttributeName.USERDATA)).thenReturn(userData);
		assertNotNull(testPlanController.testPlanView(model, session, redirectAttributes));
		
		
		List<ProjectMasterSelectDTO> projectSelectList = new ArrayList<>();
		ProjectMasterSelectDTO pmsd = Mockito.mock(ProjectMasterSelectDTO.class);
		projectSelectList.add(pmsd);
	
		RbacDTO rbac = Mockito.mock(RbacDTO.class);
		rbacDTOList.add(rbac);
		userData.setRbacDTOList(rbacDTOList);
		when(session.getAttribute(AttributeName.USERDATA)).thenReturn(userData);
		when(session.getAttribute(AttributeName.PROJECTTRACKID)).thenReturn("1");
		when(multipleUsefFunction.getProjectListBasedOnRole(userData)).thenReturn(projectSelectList);
		assertNotNull(testPlanController.testPlanView(model, session, redirectAttributes));
		
		when(session.getAttribute(AttributeName.PROJECTTRACKID)).thenThrow(NullPointerException.class);
		assertNotNull(testPlanController.testPlanView(model, session, redirectAttributes));
		
	}


	@Test
	void addTestPlanTest() {
		TestPlanDto test = new TestPlanDto();
		TestPlan testPlan = new TestPlan();
		testPlan.setIntroduction("tetPlan");
		testPlanController.addTestPlan(test, request, session, redirectAttributes, model);

		UserLoginDto userData = mock(UserLoginDto.class);
		when(session.getAttribute("userData")).thenReturn(userData);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setParameter("projectId", "1");
		when(modelMapper.map(test, TestPlan.class)).thenReturn(testPlan);
		when(testPlanService.save(testPlan)).thenReturn(testPlan);
		assertNotNull(testPlanController.addTestPlan(test, request, session, redirectAttributes, model));

		when(testPlanService.save(testPlan)).thenReturn(null);
		assertNotNull(testPlanController.addTestPlan(test, request, session, redirectAttributes, model));

		when(testPlanService.save(testPlan)).thenThrow(NullPointerException.class);
		assertNotNull(testPlanController.addTestPlan(test, request, session, redirectAttributes, model));
	}

	@Test
	void getAllProjectByIdTest() {
		testPlanController.getAllProjectById(session, 1);
		
		when(testPlanService.getTestPlanDataByProjectId(1)).thenThrow(NullPointerException.class);
		testPlanController.getAllProjectById(session, 1);
	}

	@Test
	void deleteTestPlanTest() {
		testPlanController.deleteTestPlan(1);
		
		when(testPlanService.deleteTestPlan(1)).thenThrow(NullPointerException.class);
		testPlanController.deleteTestPlan(1);
	}

	@Test
	void updateByIdTest() {
		UserLoginDto userData = new UserLoginDto();
		TestPlanDto test = new TestPlanDto();
		testPlanController.updateById(test, session, model, redirectAttributes);
		
		
		test.setTestPlanId(1);
		when(session.getAttribute(AttributeName.USERDATA)).thenReturn(userData);
		testPlanController.updateById(test, session, model, redirectAttributes);
		
		when(testPlanService.update(1,test)).thenThrow(NullPointerException.class);
		testPlanController.updateById(test, session, model, redirectAttributes);
	}

	@Test
	void updateStatusTest() {
		assertNotNull(testPlanController.updateStatus(1, 1));
		
		when(testPlanService.updateAllByProjectId(1, 1)).thenThrow(NullPointerException.class);
		testPlanController.updateStatus(1, 1);
	}
	
	@Test
	void getStatusTest() {
		assertNotNull(testPlanController.getStatus(1));
		
		when(testPlanService.findTestPlanStatus(1)).thenThrow(NullPointerException.class);
		testPlanController.getStatus(1);
	}
	
//	@Test
//	void viewPdfTest() {
//		assertNotNull(testPlanController.viewPdf(model, null, session, redirectAttributes, null, null));
//	
//		ModelMap mp = new ModelMap();
//		UserLoginDto userData = new UserLoginDto();
//		when(session.getAttribute(AttributeName.USERDATA)).thenReturn(userData);
//		when(testPlanService.getProjectNameById(1)).thenReturn("test");
//		assertNotNull(testPlanController.viewPdf(model, mp, session, redirectAttributes, 1, 1));
//		
//		when(testPlanService.getProjectNameById(1)).thenThrow(NullPointerException.class);
//		assertNotNull(testPlanController.viewPdf(model, mp, session, redirectAttributes, 1, 1));
//	}
	
	@Test
	void redirectPage2Test() {
		assertNotNull(testPlanController.redirectFromPlanToHome(redirectAttributes, session));
		
		when(session.getAttribute(AttributeName.PROJECTID)).thenReturn(1);
		assertNotNull(testPlanController.redirectFromPlanToHome(redirectAttributes, session));
	}
	
}
