package ai.rnt.bugtrackingsystem.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

import ai.rnt.bugtrackingsystem.constant.AttributeName;
import ai.rnt.bugtrackingsystem.dto.BRDataDto;
import ai.rnt.bugtrackingsystem.dto.BusinessRequirementDTO;
import ai.rnt.bugtrackingsystem.dto.ProjectMasterSelectDTO;
import ai.rnt.bugtrackingsystem.dto.RbacDTO;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.BusinessRequirement;
import ai.rnt.bugtrackingsystem.service.BusinessRequirementService;
import ai.rnt.bugtrackingsystem.service.DataFilterFunction;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.StatusService;



@ExtendWith(MockitoExtension.class)
class BusinessRequirementControllerTest {

	
	@Mock
	Model model;
	
	@Mock
	ModelMap modelMap;
	
	@Mock
	HttpSession session;
	
	@Mock
	HttpServletResponse response;
	
	@Mock
	DataFilterFunction multipleUsefFunction;
	
	@Mock
	StatusService statusService;;
	
	@InjectMocks
	BusinessRequirementController businessController;
	
	@Mock
	BusinessRequirementService businessRequirementService;
	
	@Mock
	ProjectMasterService projectMasterService;

	@Test
	void getBrReqTest() {

		UserLoginDto userData = new UserLoginDto();
		List<RbacDTO> rbacDTOList = new ArrayList<RbacDTO>();
		userData.setRbacDTOList(rbacDTOList);
		when(session.getAttribute(AttributeName.USERDATA)).thenReturn(userData);
		assertNotNull(businessController.getBrReq(model, session, null));

		List<ProjectMasterSelectDTO> projectSelectList = new ArrayList<>();
		ProjectMasterSelectDTO pmsd = Mockito.mock(ProjectMasterSelectDTO.class);
		projectSelectList.add(pmsd);

		RbacDTO rbac = Mockito.mock(RbacDTO.class);
		rbacDTOList.add(rbac);
		userData.setRbacDTOList(rbacDTOList);
		when(session.getAttribute(AttributeName.USERDATA)).thenReturn(userData);
		when(session.getAttribute(AttributeName.PROJECTTRACKID)).thenReturn("1");
		when(multipleUsefFunction.getProjectListBasedOnRole(userData)).thenReturn(projectSelectList);
		String resultView = businessController.getBrReq(model, session, null);
		assertEquals("business_req", resultView);

		when(multipleUsefFunction.getProjectListBasedOnRole(userData)).thenThrow(NullPointerException.class);
		assertNotNull(businessController.getBrReq(model, session, null));
	}
	
//	@Test
//	void findByIdTest() {
//		Integer brId = 12;
//		BusinessRequirementDTO dto = mock(BusinessRequirementDTO.class);
//		when(businessRequirementService.findById2(brId)).thenReturn(dto);
//		assertEquals(dto,businessController.findById(brId));
//		
//		when(businessRequirementService.findById2(brId)).thenThrow(NullPointerException.class);
//		assertEquals(null, businessController.findById(brId));
//	}
	
	@Test
	void getBrListByProjectIdTest() {
		BusinessRequirement brEntity = mock(BusinessRequirement.class);
		List<BusinessRequirement> list = new ArrayList<>();
		list.add(brEntity);
		when(businessRequirementService.getBrListByProjectId(1)).thenReturn(list);
		assertEquals(list, businessController.getBrListByProjectId(1));
	}
	
	@Test
	void forBusinessRequirementInfoTest() {
		assertNotNull(businessController.forBusinessRequirementInfo(1));
		
		when(businessRequirementService.getBusinessRequirementsByProjectId(1)).thenThrow(NullPointerException.class);
		assertNotNull(businessController.forBusinessRequirementInfo(1));
	}
	
	@Test
	void deleteBussReqTest() {
		assertNotNull(businessController.deleteBussReq(1, 1, session, null, null));
		
		when(businessRequirementService.deleteBr(1)).thenThrow(NullPointerException.class);
		assertNotNull(businessController.deleteBussReq(1, 1, session, null, null));
	}
	
	@Test
	void saveNewBusinessReqTest() {
		HttpServletRequest request = new MockHttpServletRequest();
		UserLoginDto userData = mock(UserLoginDto.class);
		userData.setStaffId(1);
		HttpSession session = request.getSession();
		session.setAttribute("userData", userData);
		BRDataDto brDataDto = mock(BRDataDto.class);
		when(userData.getStaffId()).thenReturn(1);
		assertNotNull(businessController.saveNewBusinessReq(brDataDto, request));
		
		assertNotNull(businessController.saveNewBusinessReq(null, null));
		
	}
	
	@Test
	void updateNewBusinessReqTest() {
		HttpServletRequest request = new MockHttpServletRequest();
		UserLoginDto userData = mock(UserLoginDto.class);
		userData.setStaffId(1);
		HttpSession session = request.getSession();
		session.setAttribute("userData", userData);
		BRDataDto brDataDto = mock(BRDataDto.class);
		when(userData.getStaffId()).thenReturn(1);
		assertNotNull(businessController.updateNewBusinessReq(brDataDto, request));
		
		assertNotNull(businessController.updateNewBusinessReq(null, null));
	}

	@Test
	void checkRepeatedBrIdTest() {
		businessController.checkRepeatedBrId("BR_1", 1);
		
		List<BusinessRequirement> brList = new ArrayList<>();
		BusinessRequirement br = new BusinessRequirement();
		br.setBrIdString("Br_1");
		brList.add(br);
		when(businessRequirementService.findBrtoCheckRepeat("BR_1", 1)).thenReturn(brList);
		businessController.checkRepeatedBrId("BR_1", 1);
	}
	
	
	@Test
	void getDetailsOfBrByBrIdTest() {
		businessController.getDetailsOfBrByBrId(1, session);
		
		UserLoginDto userData = new UserLoginDto();
		when(session.getAttribute("userData")).thenReturn(userData);
		businessController.getDetailsOfBrByBrId(1, session);
		
		when(businessRequirementService.findBrByBrId(1)).thenThrow(NullPointerException.class);
		assertNotNull(businessController.getDetailsOfBrByBrId(1, session));
	}
	
	@Test
	void exportToExcelBugTest() {
		List<BusinessRequirement> brListExport = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		when(businessRequirementService.findAllBrByProjectId(1)).thenReturn(brListExport);
		when(projectMasterService.getProjectStatusWithStartAndEndDate(1)).thenReturn(map);
		assertNotNull(businessController.exportToExcelBug(modelMap, response, session, 1));
		
		when(projectMasterService.getProjectStatusWithStartAndEndDate(1)).thenThrow(NullPointerException.class);
		assertNotNull(businessController.exportToExcelBug(modelMap, response, session, 1));
	}
	
	@Test
	void updateStatusTest() {
		assertNotNull(businessController.updateStatus(1, 1));
	}
	
	@Test
	void getStatusTest() {
		assertNotNull(businessController.getStatus(1));
	}
	
	@Test
	void getBrIdAndBusReqIdTest() {
		assertNotNull(businessController.getBrIdAndBusReqId(1, session));
	}
	
	@Test
	void deleteBrByStringBrIdAndProjectIdTest() {
		assertNotNull(businessController.deleteBrByStringBrIdAndProjectId(1));
	}
	
	@Test
	void dragAndDropBrDataTest() {
		String[] brDataDto = {"BR_1","BR_2"};
		when(businessRequirementService.dragAndDropBrData(1, brDataDto)).thenReturn("success");
		assertNotNull(businessController.dragAndDropBrData(brDataDto, 1));
		
		when(businessRequirementService.dragAndDropBrData(1, brDataDto)).thenThrow(NullPointerException.class);
		assertNotNull(businessController.dragAndDropBrData(brDataDto, 1));
	}
	
	@Test
	void redirectBrtoHomeTest() {
		assertNotNull(businessController.redirectBrtoHome(1, session, model));
	}
}
