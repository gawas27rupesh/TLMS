package ai.rnt.bugtrackingsystem.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.BusinessRequirementService;
import ai.rnt.bugtrackingsystem.service.EmployeeMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.RtmService;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.service.TestCaseService;
import ai.rnt.bugtrackingsystem.service.TestResultService;
import ai.rnt.bugtrackingsystem.service.TestScenarioService;
import ai.rnt.bugtrackingsystem.service.TestScriptService;

class ProjectTeamControllerTest {
	
	@Autowired
	MockMvc mockMvc;
	@Mock
	Model model;
	@Mock
	ModelMap mp;
	@Mock
	RedirectAttributes redirectAttributes;
	@Mock
	HttpSession session;
	@Mock
	HttpServletResponse response;
	@Mock
	HttpServletRequest request;
	
	@Mock
	EmployeeMasterService employeeMasterService;

	@Mock
	ProjectMasterService projectMasterService;

	@Mock
	ProjectTeamService projectTeamService;

	@Mock
	ProjectTeamService projectTeamService1;

	@Mock
	BugService bugService;

	@Mock
	RtmService rtmService;

	@Mock
	TestScenarioService testScenarioService;

	@Mock
	TestCaseService testCaseService;

	@Mock
	TestScriptService testScriptService;

	@Mock
	TestResultService testResultService;
	
	@Mock
	BusinessRequirementService businessRequirementService;
	
	@Mock
	StatusService  statusService;
	@Mock
	ProjectMaster projectMaster;
	@InjectMocks
	ProjectTeamController projectTeamController;
	
	String result;
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(projectTeamController).build();
	}
	
	
	
	@Test
	void viewProjectInfoTest() {
		when(projectMasterService.findById(1)).thenReturn(projectMaster);
		assertNotNull(projectTeamController.viewProjectInfo("1"));
		ClientMaster cm = new ClientMaster();
		cm.setCompanyName("abcd");
		ProjectMaster pm = new ProjectMaster();
		pm.setClientmaster(cm);
		pm.setProjectManager(1);
		when(projectMasterService.findById(1)).thenReturn(pm);
		EmployeeMaster employeeMaster = new EmployeeMaster();
		when(employeeMasterService.findAllByID(1)).thenReturn(employeeMaster);
		assertNotNull(projectTeamController.viewProjectInfo("1"));
	}
	
	@Test
	void saveProjectPhaseTest() {
		ProjectMaster pm = new ProjectMaster();
		pm.setProjectID(123);
		when(projectMasterService.findById(1)).thenReturn(pm);
		assertNotNull(projectTeamController.saveProjectPhase(1, "Data"));
	}
}
