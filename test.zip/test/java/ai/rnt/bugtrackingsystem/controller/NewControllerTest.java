/*
 * package ai.rnt.bugtrackingsystem.controller;
 * 
 * 
 * 
 * import static org.junit.Assert.assertNotNull; import static
 * org.mockito.Mockito.when; import static
 * org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
 * import static
 * org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
 * import static
 * org.springframework.test.web.servlet.result.MockMvcResultMatchers.
 * forwardedUrl; import static
 * org.springframework.test.web.servlet.result.MockMvcResultMatchers.
 * redirectedUrl; import static
 * org.springframework.test.web.servlet.result.MockMvcResultMatchers.
 * redirectedUrlPattern;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import org.assertj.core.util.Arrays; import
 * org.hibernate.criterion.ProjectionList; import org.junit.Before; import
 * org.junit.Test; import org.junit.runner.RunWith; import org.mockito.Mock;
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.test.context.SpringBootTest; import
 * org.springframework.mock.web.MockHttpSession; import
 * org.springframework.test.context.junit4.SpringRunner; import
 * org.springframework.test.web.servlet.MockMvc; import
 * org.springframework.test.web.servlet.MvcResult; import
 * org.springframework.test.web.servlet.result.FlashAttributeResultMatchers;
 * import org.springframework.test.web.servlet.setup.MockMvcBuilders; import
 * org.springframework.web.context.WebApplicationContext;
 * 
 * import ai.rnt.bugtrackingsystem.dto.ProjectExisting; import
 * ai.rnt.bugtrackingsystem.dto.UserLoginDto; import
 * ai.rnt.bugtrackingsystem.entity.ProjectMaster; import
 * ai.rnt.bugtrackingsystem.service.ProjectMasterService; import
 * ai.rnt.bugtrackingsystem.service.ProjectTeamService;
 * 
 * @SpringBootTest
 * 
 * @RunWith(SpringRunner.class) public class NewControllerTest {
 * 
 * 
 * private MockMvc mvc;
 * 
 * @Autowired private WebApplicationContext context;
 * 
 * private UserLoginDto userData=null;
 * 
 * @Mock private ProjectMasterService projectMasterService;
 * 
 * @Mock ProjectTeamService projectTeamService;
 * 
 * List<ProjectMaster> list = new ArrayList<>();
 * 
 * @Before public void setup() {
 * mvc=MockMvcBuilders.webAppContextSetup(context).build(); userData=new
 * UserLoginDto(); }
 * 
 * //for mvc is not nul test
 * 
 * @Test public void firstTest() { assertNotNull(mvc); }
 * 
 * @Test public void testCasePageInvalidSessionTest() throws Exception {
 * MockHttpSession session=new MockHttpSession();
 * 
 * MvcResult result=mvc.perform(get("/testCase").session(session))
 * .andDo(print()) .andExpect(redirectedUrl("/")) .andReturn();
 * System.out.println(result.getModelAndView().getModel()+"\n data: "+result.
 * getResponse().getContentType() +" =----hgsdj");
 * 
 * 
 * }
 * 
 * @Test public void testCasePageAdminTest() throws Exception { MockHttpSession
 * session=new MockHttpSession(); userData.setRoleName("admin");
 * userData.setStaffId(1302); session.setAttribute("userData", userData);
 * 
 * ProjectMaster pm=new ProjectMaster(); pm.setProjectName("new Project");
 * pm.setProjectStatus('C'); pm.setDatabaseName("mysql"); ProjectMaster pm1 =
 * new ProjectMaster(); pm1.setProjectName("new dsaProject");
 * pm1.setProjectStatus('I'); pm1.setDatabaseName("dsd"); list.add(pm1);
 * list.add(pm);
 * 
 * when(projectMasterService.findAll()).thenReturn(list); MvcResult
 * result=mvc.perform(get("/testCase").session(session)) // .andDo(print())
 * //.andExpect(forwardedUrl("TestCase")) .andReturn();
 * System.out.println(result.getModelAndView().getModel()+"\n data: "+result.
 * getResponse().getContentType() +" =----hgsdj");
 * 
 * 
 * }
 * 
 * //for External user
 * 
 * @Test public void testCasePageDeveloperTest() throws Exception {
 * MockHttpSession session=new MockHttpSession(); List<ProjectExisting>
 * list1=new ArrayList<>(); ProjectExisting pl=new ProjectExisting();
 * pl.setProjectId(1); pl.setProjectName("Amiance"); ProjectExisting pl2=new
 * ProjectExisting(); pl2.setProjectId(2); pl2.setProjectName("Amdocs");
 * list1.add(pl2); list1.add(pl); userData.setRoleName("developer");
 * userData.setStaffId(1302); userData.setProjectList(list1);
 * session.setAttribute("userData", userData);
 * 
 * ProjectMaster pm=new ProjectMaster(); pm.setProjectName("new Project");
 * pm.setProjectStatus('C'); pm.setDatabaseName("mysql"); ProjectMaster pm1 =
 * new ProjectMaster(); pm1.setProjectName("new dsaProject");
 * pm1.setProjectStatus('I'); pm1.setDatabaseName("dsd"); list.add(pm1);
 * list.add(pm);
 * 
 * when(projectMasterService.findAll()).thenReturn(list); MvcResult
 * result=mvc.perform(get("/testCase").session(session)) .andDo(print())
 * //.andExpect(forwardedUrl("TestCase")) .andReturn();
 * System.out.println(result.getModelAndView().getModel()+"\n data: "+result.
 * getResponse().getContentType() +" =----hgsdj");
 * 
 * 
 * } //for other user
 * 
 * @Test public void testCasePageOtherTest() throws Exception { MockHttpSession
 * session=new MockHttpSession(); userData.setRoleName("mysql developer");
 * userData.setStaffId(1302); userData.setRoleId(100);
 * session.setAttribute("userData", userData);
 * 
 * ProjectMaster pm=new ProjectMaster(); pm.setProjectID(1);
 * pm.setProjectName("new Project"); pm.setProjectStatus('C');
 * pm.setDatabaseName("mysql"); ProjectMaster pm1 = new ProjectMaster();
 * pm1.setProjectName("new dsaProject"); pm1.setProjectStatus('I');
 * pm1.setDatabaseName("dsd"); list.add(pm1); list.add(pm); List<Integer>
 * intList=List.of(1);
 * when(projectTeamService.getProjectByRoleAndStaffId(100,1302)).thenReturn(
 * intList); when(projectMasterService.findById(1)).thenReturn(pm);
 * when(projectMasterService.findAll()).thenReturn(list); MvcResult
 * result=mvc.perform(get("/testCase").session(session)) .andDo(print())
 * //.andExpect(forwardedUrl("TestCase")) .andReturn();
 * System.out.println(result.getModelAndView().getModel()+"\n data: "+result.
 * getResponse().getContentType() +" =----hgsdj");
 * 
 * 
 * }
 * 
 * 
 * }
 */