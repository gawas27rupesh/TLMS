package ai.rnt.bugtrackingsystem.controller;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;

class GlobalExceptionControllerTest {

	@Autowired
	MockMvc mockMvc;
	
	@Mock
	Model model;
	
	@Mock
	Exception exc;
	
	@InjectMocks
	GlobalExceptionController globalExceptionController;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(globalExceptionController).build();
	}

}
