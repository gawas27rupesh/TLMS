package ai.rnt.bugtrackingsystem.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.ProjectTeamDto;
import ai.rnt.bugtrackingsystem.dto.RtmDto;
import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.BusinessRequirement;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.repository.BusinessReuirementRepository;
import ai.rnt.bugtrackingsystem.repository.ProjectMasterRpository;
import ai.rnt.bugtrackingsystem.repository.ProjectTeamRepository;
import ai.rnt.bugtrackingsystem.repository.RtmRepository;
import ai.rnt.bugtrackingsystem.service.BugService;
import ai.rnt.bugtrackingsystem.service.ProjectMasterService;
import ai.rnt.bugtrackingsystem.service.ProjectTeamService;
import ai.rnt.bugtrackingsystem.service.RtmService;
import ai.rnt.bugtrackingsystem.service.StatusService;

class RtmControllerTest {

	@Autowired
	MockMvc mockMvc;
	@Mock
	Model model;
	@Mock
	ModelMap mp;
	@Mock
	RedirectAttributes redirectAttributes;
	@Mock
	HttpSession session;
	@Mock
	HttpServletResponse response;
	@Mock
	HttpServletRequest request;
	@Mock
	RtmRepository rtmRepo;
	@Mock
	RtmService rtmService;

	@Mock
	ProjectMasterService projectMasterService;

	@Mock
	ProjectMasterRpository projectMasterRpository;

	@Mock
	BusinessReuirementRepository brRepository;

	@Mock
	ProjectTeamRepository projectTeamRepository;
	Rtm rtm;

	@Mock
	ProjectTeamService projectTeamService;

	@Mock
	BugService bugService;

	@Mock
	StatusService statusService;
	
	@InjectMocks
	RtmController rtmController;
	
	String result;
	
	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(rtmController).build();
	}
	@Test
	void testTest() {
		try {
		
		// for Object isNull
		result = rtmController.showRtm(request, model, session);
		
		// for tlms admin
		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		result = rtmController.showRtm(request, model, session);
		
		// for developer
		when(userData.getRoleName()).thenReturn("developer");
		when(session.getAttribute("userData")).thenReturn(userData);
		result = rtmController.showRtm(request, model, session);
		
		// for else Condition
		when(userData.getRoleName()).thenReturn("user");
		when(session.getAttribute("userData")).thenReturn(userData);
		ArrayList<Integer> ids = new ArrayList<>();
		ids.add(1);
		when(projectTeamService.getProjectByRoleAndStaffId(0, 0)).thenReturn(ids);
		result = rtmController.showRtm(request, model, session);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void getDetailsByProjectIdTest() {
		//  if condition
		rtmController.getDetailsByProjectId(1, session);
		
		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		rtmController.getDetailsByProjectId(1, session);
		
	}
	
	@Test
	void getAllDataForAddTestCaseTest() {
		rtmController.getAllDataForAddTestCase(1, session);
	}
	
	@Test
	void findRtmByProjectIDTest() {
		rtmController.findRtmByProjectID(1, session);
	}
	
	@Test
	void deleteRtmTest() {
		// if Condition
		rtmController.deleteRtm(1, session, redirectAttributes);
		
		rtmController.deleteRtm(1, session, redirectAttributes);
		// else Condition
		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		BusinessRequirement brt = new BusinessRequirement();
		brt.setBrId(1);
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectID(1);
		Rtm rtm = new Rtm();
		rtm.setBrId(brt);
		rtm.setProjectMaster(projectMaster);
		when(rtmService.findById(1)).thenReturn(rtm);
		rtmController.deleteRtm(1, session, redirectAttributes);
		
	}
	@Test
	void deleteTest() {
		// if Condition
		rtmController.delete(1, session);
		
		rtmController.delete(1, session);
		// else Condition
		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		BusinessRequirement brt = new BusinessRequirement();
		brt.setBrId(1);
		ProjectMaster projectMaster = new ProjectMaster();
		projectMaster.setProjectID(1);
		Rtm rtm = new Rtm();
		rtm.setBrId(brt);
		rtm.setProjectMaster(projectMaster);
		when(rtmService.findById(1)).thenReturn(rtm);
		rtmController.delete(1, session);
		
	}
	
	@Test
	void getAllProjectById1Test() {
		rtmController.getAllProjectById(1, 1);
	}
	
	@Test
	void getRtmExpandDataTest() {
		rtmController.getRtmExpandData(1, 1);
	}
	
	@Test
	void getScenarioforAddTest() {
		//result = rtmController.getScenarioforAdd(1, result, 1, result, redirectAttributes);
	}
	
	@Test
	void getTestCaseforAddTest() {
		//result = rtmController.getTestCaseforAdd(1, result, 2, 3, result, result, result, redirectAttributes, session);
	}
	
	@Test
	void getScenarioforLinkTest() {
		result = rtmController.getScenarioforLink(1, redirectAttributes);
	}
	
	@Test
	void getTestCaseforLinkTest() {
		result = rtmController.getTestCaseforLink(1, redirectAttributes);
	}
	
	@Test
	void updateStatusTest() {
		rtmController.updateStatus(1, null);
	}
	
	@Test
	void getStatusTest() {
		rtmController.getStatus(1);
	}
	
	//@Test
	void downloadExcelReportTest() {
		//rtmController.downloadExcelReport(1, mp, session);
		
		UserLoginDto userData = mock(UserLoginDto.class);
		when(userData.getRoleName()).thenReturn("tlms admin");
		when(session.getAttribute("userData")).thenReturn(userData);
		ProjectMaster projectMaster = new ProjectMaster();
		when(projectMasterService.findById(1)).thenReturn(projectMaster);
		when(bugService.findBugCount(1)).thenReturn(10);
		List<ProjectTeamDto> project = new ArrayList<>();
		ProjectTeamDto  projectTeamDto = new ProjectTeamDto();
		projectTeamDto.setRole("tester");
		project.add(projectTeamDto);
		when(projectTeamService.findProjectTesterByProjectId(1)).thenReturn(project);
	//	rtmController.downloadExcelReport(1, mp, session);
	}
	
	@Test
	void getAutoPopulatedRequirementIdTest() {
		rtmController.getAutoPopulatedRequirementId(1, null);
	}
	
	@Test
	void updateRtmbyIdTest() {
		Rtm rtm = new Rtm();
		when(rtmService.findRtmById(1)).thenReturn(Optional.of(rtm));
		rtmController.updateRtmbyId(1, "requirement", "requirementDesc");
	}
	
	@Test
	void saveRtmDataTest() {
		RtmDto rtmDto = new RtmDto();
		rtmController.saveRtmData(rtmDto, session);
	}
}
