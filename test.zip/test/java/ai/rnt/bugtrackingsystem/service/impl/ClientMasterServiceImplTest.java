package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.ClientMaster;
import ai.rnt.bugtrackingsystem.repository.ClientMasterRepository;

@ExtendWith(MockitoExtension.class)
class ClientMasterServiceImplTest {

	
	@Mock
	private ClientMasterRepository clientMaster;
	
	@InjectMocks
	ClientMasterServiceImpl clientMasterServiceImpl;
	
	
	@Test
	void findAllTest() {
		clientMasterServiceImpl.findAll();
	}
	@Test
	void findByIdTest() {
		
		ClientMaster cm = new ClientMaster();
		cm.setAccountNo("1");
		when(clientMaster.findById(1)).thenReturn(Optional.of(cm));
		clientMasterServiceImpl.findById(1);
		when(clientMaster.findById(1)).thenReturn(null);
		clientMasterServiceImpl.findById(1);
	}

}
