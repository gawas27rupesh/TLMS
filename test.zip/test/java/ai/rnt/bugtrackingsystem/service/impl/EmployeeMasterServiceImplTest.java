package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.repository.EmployeeMasterRepository;
import ai.rnt.bugtrackingsystem.util.StringEncryption;

@ExtendWith(MockitoExtension.class)
class EmployeeMasterServiceImplTest {
	
	@Mock
	private EmployeeMasterRepository employeeMaster;

	@Mock
	private StringEncryption stringEncryption;

	@InjectMocks
	EmployeeMasterServiceImpl employeeMasterServiceImpl;
	
	@Test
	void findByUserIdAndPasswordTest() {
		employeeMasterServiceImpl.findByUserIdAndPassword("1", "h");
		EmployeeMaster emp = new  EmployeeMaster();
		when(employeeMaster.findByUserIdAndPassword("1", "h")).thenReturn(Optional.of(emp));
		employeeMasterServiceImpl.findByUserIdAndPassword("1", "h");
	}
	@Test
	void findAllByIDTest() {
		employeeMasterServiceImpl.findAllByID(1);
	}
	@Test
	void findByIdTest() {
		employeeMasterServiceImpl.findById(1);
		EmployeeMaster emp = new  EmployeeMaster();
		when(employeeMaster.findById(1)).thenReturn(Optional.of(emp));
		employeeMasterServiceImpl.findById(1);
	}
	@Test
	void findAllEmployeeTest() {
		employeeMasterServiceImpl.findAllEmployee();
	}
}
