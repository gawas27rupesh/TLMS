package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import ai.rnt.bugtrackingsystem.entity.BugImage;
import ai.rnt.bugtrackingsystem.repository.BugImageRepository;

@ExtendWith(MockitoExtension.class)
class BugImageServiceImplTest {

	@Autowired
	MockMvc mockMvc;
	
	@Mock
	BugImageRepository bugImageRepository;
	
	@InjectMocks
	BugImageServiceImpl bugImageServiceImpl;
	
	@Mock
	BugImage bugImage;
	
	
	@Test
	void findBugImageByBugIdTest() {
		bugImageServiceImpl.findBugImageByBugId(1);
	}
	
	
	@Test
	void findByIdTest() {
		when(bugImageRepository.findById(1)).thenReturn(Optional.of(bugImage));
		bugImageServiceImpl.findById(1);
		when(bugImageRepository.findById(1)).thenReturn(null);
		bugImageServiceImpl.findById(1);
	}

}
