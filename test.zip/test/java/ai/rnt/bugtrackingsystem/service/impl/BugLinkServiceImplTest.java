package ai.rnt.bugtrackingsystem.service.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import ai.rnt.bugtrackingsystem.entity.BugLink;
import ai.rnt.bugtrackingsystem.repository.BugLinkRepository;

@ExtendWith(MockitoExtension.class)
class BugLinkServiceImplTest {

	@Autowired
	MockMvc mockMvc;
	
	@Mock
	BugLinkRepository bugLinkRepository;

	@InjectMocks
	BugLinkServiceImpl bugLinkServiceImpl;
	BugLink bugLink;
	
	@Test
	void findBugLinkByBugIdTest() {
		bugLinkServiceImpl.findBugLinkByBugId(1);
	}
}
