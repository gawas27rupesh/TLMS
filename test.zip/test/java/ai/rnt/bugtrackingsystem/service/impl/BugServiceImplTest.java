package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.repository.BugRepository;

@ExtendWith(MockitoExtension.class)
class BugServiceImplTest {

	@Autowired
	MockMvc mockMvc;

	@Mock
	BugRepository bugRepository;

	Bug bug;

	@InjectMocks
	BugServiceImpl bugServiceImpl;


	@Test
	void findByIdTest() {
		bugServiceImpl.findById(1);
	}

	@Test
	void getBugIdTest() {
		Bug bug = new Bug();
		when(bugRepository.findById(1)).thenReturn(Optional.of(bug));
		bugServiceImpl.getBugId(1);
	}

	@Test
	void findAllTest() {
		//bugServiceImpl.findAll();
	}

	@Test
	void saveTest() {
		//bugServiceImpl.save(bug);
	}
	@Test
	void findAllBugByProjectIdTest() {
		//bugServiceImpl.findAllBugByProjectId(1);
	}
	@Test
	void deleteByBugIdTest() {
		bugServiceImpl.deleteByBugId(1);
	}
	@Test
	void getBugCountByCurrentDateTest() {
		bugServiceImpl.getBugCountByCurrentDate("28-02-2023");
	}
	@Test
	void findBugCountTest() {
		bugServiceImpl.findBugCount(1);
	}
	@Test
	void findBugtoCheckRepeatTest() {
		bugServiceImpl.findBugtoCheckRepeat("1", 1);
	}
	
}

