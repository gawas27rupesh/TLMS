package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.repository.TestCaseRepository;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.util.TlmsGeneralFunctionality;

@ExtendWith(MockitoExtension.class)
class TestCaseServiceImplTest {

	@Mock
	Model model;

	@Mock
	ModelMap mp;

	@Mock
	RedirectAttributes red;

	@Mock
	HttpSession session;

	@Mock
	HttpServletResponse response;

	@Mock
	HttpServletRequest request;

	@Mock
	TestCaseRepository testCaseRepository;

	@Mock
	StatusService statusService;

	@Mock
	private TlmsGeneralFunctionality tlmsGenFun;

	@InjectMocks
	TestCaseServiceImpl testCaseServiceImpl;

	TestCase testCaseData;


	@Test
	void findAllTest() {
		testCaseServiceImpl.findAll();
	}

	@Test
	void getReferenceByIdTest() {
		testCaseServiceImpl.getReferenceById(1);
	}

	@Test
	void saveTest() {
		testCaseServiceImpl.save(testCaseData);
	}

	@Test
	void findByIdTest() {
		testCaseServiceImpl.findById(1);
	}

	@Test
	void deleteTest() {
		testCaseServiceImpl.delete(testCaseData);
	}

	@Test
	void deleteByIdTest() {
		testCaseServiceImpl.deleteById(1);
	}

	@Test
	void findTestCaseByProjectIdTest() {
		testCaseServiceImpl.findTestCaseByProjectId(1);
	}

	@Test
	void findTestCaseByRtmIdTest() {
		testCaseServiceImpl.findTestCaseByRtmId(1);
	}

	@Test
	void findByTestCaseIdTest() {
		testCaseServiceImpl.findByTestCaseId("1");
	}

	@Test
	void findByRtmAndTestScenarioTest() {
		testCaseServiceImpl.findByRtmAndTestScenario(1, 1);
	}

	@Test
	void findTestCaseInfoByBugIdTest() {
		testCaseServiceImpl.findTestCaseInfoByBugId(1);
	}

	@Test
	void findTestCaseByIdTest() {
		TestCase testcase = new TestCase();
		when(testCaseRepository.findById(1)).thenReturn(Optional.of(testcase));
		testCaseServiceImpl.findTestCaseById(1);
	}

	@Test
	void getDataforAddTabelTest() {
		Object[] obj = new Object[7];
		Integer num = 4;
		obj[4] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testCaseRepository.getDataforAddTabel(1)).thenReturn(list);
		testCaseServiceImpl.getDataforAddTabel(1);

		when(testCaseRepository.getDataforAddTabel(1)).thenReturn(null);
		testCaseServiceImpl.getDataforAddTabel(1);
	}

	@Test
	void findTestCaseCountTest() {
		testCaseServiceImpl.findTestCaseCount(1);
	}

	@Test
	void checkDuplicateTestCaseTest() {
		when(testCaseRepository.findByCaseIdAndProjectMasterProjectIDAndTestScenarioScenarioId("1", 1, 1, 1)).thenReturn(testCaseData);
		testCaseServiceImpl.checkDuplicateTestCase("1", 1, 1, 1);
	}

	@Test
	void findStatusByProjectIdTest() {
		when(testCaseRepository.findStatusByProjectId(1)).thenReturn(1);
		testCaseServiceImpl.findStatusByProjectId(1);
	}

	@Test
	void updateAllByProjectId() {
		testCaseServiceImpl.updateAllByProjectId(1, 1);
	}

	@Test
	void getByIdTest() {
		testCaseServiceImpl.getById(1);
	}

	
	@Test
	void getCountByProjectIdTest() {
		when(testCaseRepository.getMaxTestCaseId(1, 1)).thenReturn(1);
		TestCase testCase = new TestCase();
		testCase.setTestCaseId("br_1");
		when(testCaseRepository.findById(1)).thenReturn(Optional.of(testCase));
		testCaseServiceImpl.getCountByProjectId(1, 1, "1");
		
		when(testCaseRepository.getMaxTestCaseId(1, 1)).thenReturn(null);
		testCaseServiceImpl.getCountByProjectId(1, 1, "1");


	}
	
	@Test
	void suffleTC_NoTest() {
		TestCase testCase = new TestCase();
		List<TestCase> list = new ArrayList<>();
		list.add(testCase);
		when(testCaseRepository.findByProjectMasterProjectIDAndTestScenarioScenarioId(1, 1)).thenReturn(list);
		testCaseServiceImpl.suffleTC_No(1, 1);
	}
	
	@Test
	void findTestCaseStatusTest() {
		when(testCaseRepository.findStatusByProjectId(1)).thenReturn(1);
		testCaseServiceImpl.findTestCaseStatus(1);
		when(testCaseRepository.findStatusByProjectId(1)).thenReturn(null);
		testCaseServiceImpl.findTestCaseStatus(1);
	}

}
