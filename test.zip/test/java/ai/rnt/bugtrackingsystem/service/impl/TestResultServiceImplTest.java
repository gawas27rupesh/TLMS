package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.TestResultDto;
import ai.rnt.bugtrackingsystem.entity.TestResult;
import ai.rnt.bugtrackingsystem.repository.TestResultRepository;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.util.TlmsGeneralFunctionality;

@ExtendWith(MockitoExtension.class)
class TestResultServiceImplTest {

	@Mock
	Model model;
	
	@Mock
	ModelMap mp;
	
	@Mock
	RedirectAttributes redirectAttributes;
	
	@Mock
	HttpSession session;
	
	@Mock
	HttpServletResponse response;
	
	@Mock
	HttpServletRequest request;
	
	@Mock
	TestResultRepository testResult;

	@Mock
	EntityManager entityManager;

	@Mock
	StatusService statusService;

	@Mock
	private TlmsGeneralFunctionality tlmsGenFun;

	
	TestResult testResult1;
	
	@InjectMocks
	TestResultServiceImpl testResultServiceImpl;
	
	@Test
	void saveTest() {
		testResultServiceImpl.testResultSave(testResult1);
	}
	
	@Test
	void findStatusByProject() {
		testResultServiceImpl.findStatusByProject(1);
	}
	@Test
	void deleteTest() {
		testResultServiceImpl.delete(testResult1);
	}
	@Test
	void deleteByIdTest() {
		testResultServiceImpl.deleteById(1);
	}
	
	@Test
	void getTestResultByIdTest() {
		Object[] rtm = new TestResultDto[10];
		List<Object[]> obj = new ArrayList<>();
		obj.add(rtm);
		when(testResult.getTestResultById(1)).thenReturn(obj);
//		when(testList.size()).thenReturn(1);
		testResultServiceImpl.getTestResultById(1);
	}
	
	@Test
	void getResultExpandDtlTest() {
		Object[] rtm = new TestResultDto[10];
		List<Object[]> obj = new ArrayList<>();
		obj.add(rtm);
		when(testResult.getResultExpandDtl(1, 1, 1)).thenReturn(obj);
		testResultServiceImpl.getResultExpandDtl(1, 1, 1);
		
		Object[] rtm1 = new TestResultDto[13];
		List<Object[]> obj1 = new ArrayList<>();
		obj1.add(rtm1);
		when(testResult.getResultExpandDtl(1, 1, 1)).thenReturn(obj1);
		testResultServiceImpl.getResultExpandDtl(1, 1, 1);
	}
	
	@Test
	void stepByActualResultTest() {
		Object[] rtm = new TestResultDto[1];
		List<Object[]> obj = new ArrayList<>();
		obj.add(rtm);
		when(testResult.stepByActualResult(1)).thenReturn(obj);
		testResultServiceImpl.stepByActualResult(1);
		
		Object[] rtm1 = new TestResultDto[13];
		List<Object[]> obj1 = new ArrayList<>();
		obj1.add(rtm1);
		when(testResult.stepByActualResult(1)).thenReturn(obj1);
		testResultServiceImpl.stepByActualResult(1);
	}
	
	//@Test
	void findByIdTest() {
		testResultServiceImpl.findById(1);
		
		TestResult testR = new TestResult();
		when(testResult.findById(1)).thenReturn(Optional.of(testR));
		testResultServiceImpl.findById(1);
	}
	
	
	@Test
	void findByTestscriptIdTest() {
		testResultServiceImpl.findByTestscriptId(1);
	}
	
	
	@Test
	void addDataListTest() {
		List<TestResultDto> testList = new ArrayList<>();
		Integer o = 27;
		Object[] obj = new Object[20];
		Timestamp tp = new Timestamp(0);
		obj[10]=o;
		obj[12]=o;
		obj[13]=tp;
		obj[14]=o;
		obj[16]=o;
		
		try {
			testResultServiceImpl.addDataList(testList, obj);
		}
		catch(Exception e) {}
	}
	
	@Test
	void findUsingIteratorTest() {
		List<TestResultDto> list1 = new ArrayList<>();
		testResultServiceImpl.findUsingIterator("1", 1, list1);

		
		TestResultDto trd = new TestResultDto();
		trd.setReqId("1");
		trd.setCaseId(1);
		List<TestResultDto> list = new ArrayList<>();
		list.add(trd);
		testResultServiceImpl.findUsingIterator("1", 1, list);
	}
	
	@Test
	void getExportDataForResult() {
		Object[] obj = new Object[15];
		Integer o = 27;
		obj[11] = o;
		List<Object[]> obj1 = new ArrayList<>();
		obj1.add(obj);
		when(testResult.getExportDataForResult(1)).thenReturn(obj1);
		testResultServiceImpl.getExportDataForResult(1);
		
		when(testResult.getExportDataForResult(1)).thenReturn(null);
		testResultServiceImpl.getExportDataForResult(1);
	}
	
	
	@Test
	void findStatusByProjectIdTest() {
		testResultServiceImpl.findStatusByProjectId(1);
	}
	@Test
	void updateAllByProjectIdTest() {
		testResultServiceImpl.updateAllByProjectId(1, 1);
	}
	
	@Test
	void downloadZipFileTest() throws IOException {
		TestResult testResult = new TestResult();
		testResult.setTestResultId(1);
		testResult.setResultScreenshot("output");
		List<TestResult> listOfFileNames = new ArrayList<>();
		listOfFileNames.add(testResult);
		HttpServletResponse response = new MockHttpServletResponse();
		response.setStatus(0);
		//when(testResult.getResultScreenshot()).thenReturn("output");
		testResultServiceImpl.downloadZipFile(response, listOfFileNames);
	}
	
	@Test
	void getScreenShotbyProjectIdTest() {
		testResultServiceImpl.getScreenShotbyProjectId(1);
	}
}
