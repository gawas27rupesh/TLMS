package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.repository.ProjectMasterRpository;
import ai.rnt.bugtrackingsystem.service.ClientMasterService;

@ExtendWith(MockitoExtension.class)
class ProjectMasterServiceImplTest {


	@Mock
	private ProjectMasterRpository projectMaster;

	@Mock
	private ClientMasterService client;
	
	@InjectMocks
	ProjectMasterServiceImpl projectMasterServiceImpl;
	
	@Test
	void findAllTest() {
		projectMasterServiceImpl.findAll();
	}
	@Test
	void findAllByProjectAndClientTest() {
		projectMasterServiceImpl.findAllByProjectAndClient();
	}
	@Test
	void findByKeyWordTest() {
		projectMasterServiceImpl.findByKeyWord("Data", null);
	}
	@Test
	void saveTest() {
		ProjectMaster updatedPm = new ProjectMaster();
		projectMasterServiceImpl.save(updatedPm);
	}
	@Test
		void findByIdTest() {
		ProjectMaster master = new ProjectMaster();
		when(projectMaster.findById(1)).thenReturn(Optional.of(master));
		projectMasterServiceImpl.findById(1);
		when(projectMaster.findById(1)).thenReturn(null);
		projectMasterServiceImpl.findById(1);
	}
	@Test
	void getProjectDataByClientIdTest() {
		projectMasterServiceImpl.getProjectDataByClientId(1);
	}

}
