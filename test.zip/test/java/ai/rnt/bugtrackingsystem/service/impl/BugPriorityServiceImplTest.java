package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;

import ai.rnt.bugtrackingsystem.entity.BugPriority;
import ai.rnt.bugtrackingsystem.repository.BugPriorityRepository;

@ExtendWith(MockitoExtension.class)
class BugPriorityServiceImplTest {

	@Mock
	MockMvc mockMvc;
	
	@Mock
	BugPriorityRepository bugPriorityRepository;

	@InjectMocks
	BugPriorityServiceImpl bugPriorityServiceImpl;
	
	@Test
	void findAllTest() {
		ArrayList<BugPriority> list = new ArrayList<>();
		when(bugPriorityRepository.findAll()).thenReturn(list);
		bugPriorityServiceImpl.findAll();
	}
	
	@Test
	void findByIdTest() {
		BugPriority bugPriority = new BugPriority();
		when(bugPriorityRepository.findById(1)).thenReturn(Optional.of(bugPriority));
		bugPriorityServiceImpl.findById(1);
	}

}
