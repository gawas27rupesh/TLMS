package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.TestScenarioDto;
import ai.rnt.bugtrackingsystem.entity.TestScenario;
import ai.rnt.bugtrackingsystem.repository.TestScenarioRepository;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.util.EntityFunctionality;
import ai.rnt.bugtrackingsystem.util.TlmsGeneralFunctionality;
@ExtendWith(MockitoExtension.class)
class TestScenarioServiceImplTest {


	@Mock
	Model model;

	@Mock
	ModelMap mp;

	@Mock
	RedirectAttributes red;

	@Mock
	HttpSession session;

	@Mock
	HttpServletResponse response;

	@Mock
	HttpServletRequest request;

	@Mock
	TestScenarioRepository testScenario;

	@Mock
	EntityFunctionality entityFunctionality;

	@Mock
	EntityManager entityManager;

	@Mock
	StatusService statusService;

	@Mock
	TlmsGeneralFunctionality tlmsGenFun;

	List<TestScenarioDto> list;
	TestScenario testScenarioD;

	@InjectMocks
	TestScenarioServiceImpl testScenarioServiceImpl;


	@Test
	void findAllTest() {
		testScenarioServiceImpl.findAll();
	}

	@Test
	void getReferenceByIdTest() {
		testScenarioServiceImpl.getReferenceById(1);
	}

	@Test
	void saveTest() {
		testScenarioServiceImpl.save(testScenarioD);
	}

	@Test
	void findByIdTest() {
		TestScenario test = new TestScenario();
		when(testScenario.findById(1)).thenReturn(Optional.of(test));
		testScenarioServiceImpl.findById(1);

	}

	@Test
	void deleteTest() {
		testScenarioServiceImpl.delete(testScenarioD);
	}

	@Test
	void deleteByIdTest() {
		testScenarioServiceImpl.deleteById(1);
	}

	@Test
	void findTestScenarioByRtmIdTest() {
		testScenarioServiceImpl.findTestScenarioByRtmId(1);
	}

	@Test
	void deleteByRtmIdTest() {
		testScenarioServiceImpl.deleteByRtmId(1);
	}

	@Test
	void findByTestScenarioByIdTest() {
		testScenarioServiceImpl.findByTestScenarioById(1);
	}

	@Test
	void getDataforAddTabelTest() {
		Object[] obj = new Object[5];
		Integer num = 4;
		obj[3] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testScenario.getDataforAddTabel(1)).thenReturn(list);
		testScenarioServiceImpl.getDataforAddTabel(1);
		when(testScenario.getDataforAddTabel(1)).thenReturn(null);
		testScenarioServiceImpl.getDataforAddTabel(1);
	}

	@Test
	void findTestScenarioCountTest() {
		testScenarioServiceImpl.findTestScenarioCount(1);
	}
	@Test
	void getTestScenarioDataByProjectIdTest() {
		List<Object[]> results = new ArrayList<Object[]>();
		Object[] record1 = { 1,1, "TS_1", "scenario_desc", "FR_1.1","Test_case","Requirement", new Timestamp(1650616821000L) };
		Object[] record2 = { 1,1, "TS_1", "scenario_desc", "FR_1.1","Test_case","Requirement", new Timestamp(1650616821000L) };
		Object[] record3 = { 1,1, "TS_1", "scenario_desc", "FR_1.1","Test_case","Requirement", new Timestamp(1650616821000L) };
		results.add(record1);
		results.add(record2);
		results.add(record3);
		when(testScenario.getTestScenarioDataByProjectId(1)).thenReturn(results);
		testScenarioServiceImpl.getTestScenarioDataByProjectId(1);
		
		when(testScenario.getTestScenarioDataByProjectId(1)).thenReturn(null);
		testScenarioServiceImpl.getTestScenarioDataByProjectId(1);
	}
	
	@Test
	void findStatusByProjectIdTest() {
		when(testScenario.findStatusByProjectId(1)).thenReturn(0);
		testScenarioServiceImpl.findStatusByProjectId(1);
	}
	@Test
	void updateAllByProjectIdStatusTest() {
		testScenarioServiceImpl.updateAllByProjectIdStatus(1, 1);
	}
	@Test
	void expandDataTestScenarioTest() {
		Object[] obj = new Object[7];
		Integer num = 4;
		obj[0] = num;
		obj[3] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testScenario.expandDataTestScenarioByRtmId(1)).thenReturn(list);
		testScenarioServiceImpl.expandDataTestScenario(1);
		
		when(testScenario.expandDataTestScenarioByRtmId(1)).thenReturn(null);
		testScenarioServiceImpl.expandDataTestScenario(1);
	}
	
	@Test
	void findByRtmIdTest() {
		testScenarioServiceImpl.findByRtmId(1);
	}
	@Test
	void findByTestScenarioIdAndProjectMasterTest() {
		testScenarioServiceImpl.findByTestScenarioIdAndProjectMaster("1", 1, 1);
	}
	@Test
	void getExcelReportDataTest() {
		Object[] obj = new Object[15];
		Integer num = 4;
		obj[0] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testScenario.getExcelReport(1)).thenReturn(list);
		testScenarioServiceImpl.getExcelReportData(1);
		when(testScenario.getExcelReport(1)).thenReturn(null);
		testScenarioServiceImpl.getExcelReportData(1);
	}
	@Test
	void checkDuplicateTestScenarioTest() {
		testScenarioServiceImpl.checkDuplicateTestScenario("1", 1, 1);
	}
	
	@Test
	void getAutoGenerated() {
		when(testScenario.countByProjectMasterProjectId(1, 1)).thenReturn(1);
		TestScenario test = new TestScenario();
		test.setTestScenarioId("1_2_3");
		when(testScenario.findById(1)).thenReturn(Optional.of(test));
		testScenarioServiceImpl.getAutoGenerated(1, 1, "1");
	}
	
	@Test
	void suffleTS_NoTest() {
		List<TestScenario> testSce = new ArrayList<>();
		TestScenario test = new TestScenario();
		testSce.add(test);
		when(testScenario.findByProjectMasterProjectIdAndRtmId(1, 1)).thenReturn(testSce);
		testScenarioServiceImpl.suffleTS_No(1, 1);
	}
	
	@Test
	void findTestScenarioStatusTest() {
		when(testScenario.findStatusByProjectId(1)).thenReturn(1);
		testScenarioServiceImpl.findTestScenarioStatus(1);
		

	}

}
