package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.UserLoginDto;
import ai.rnt.bugtrackingsystem.entity.BusinessRequirement;
import ai.rnt.bugtrackingsystem.repository.BusinessReuirementRepository;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.util.TlmsGeneralFunctionality;

@ExtendWith(MockitoExtension.class)
class BusinessRequirementServiceImplTest {

	@Mock
	Model model;

	@Mock
	ModelMap mp;

	@Mock
	RedirectAttributes red;

	@Mock
	HttpSession session;

	@Mock
	HttpServletResponse response;

	@Mock
	HttpServletRequest request;
	
	@Mock
	BusinessReuirementRepository businessReuirementRepository;

	@Mock
	StatusService statusService;

	@Mock
	TlmsGeneralFunctionality tlmsGenFun;
	
	BusinessRequirement busr;
	
	@InjectMocks
	BusinessRequirementServiceImpl businessRequirementServiceImpl;
	
	
	@Test
	void save(){
		businessRequirementServiceImpl.save(busr);
	}
	@Test
	void TestfindBrById(){
		businessRequirementServiceImpl.findBrById(1);
	}
	@Test
	void findBrtoCheckRepeatTest(){
		businessRequirementServiceImpl.findBrtoCheckRepeat("1", 1);
	}
	@Test
	void deleteBrTest(){
		businessRequirementServiceImpl.deleteBr(1);
	}
	@Test
	void findBrByBrIdTest(){
		businessRequirementServiceImpl.findBrByBrId(1);
	}
	@Test
	void findBrStatusTest(){
		when(businessReuirementRepository.findbrStatusByProjectId(1)).thenReturn(1);
		businessRequirementServiceImpl.findBrStatus(1);
		when(businessReuirementRepository.findbrStatusByProjectId(1)).thenReturn(null);
		businessRequirementServiceImpl.findBrStatus(1);
	}
	@Test
	void updateAllByProjectIdStatusTest(){
		//when(businessReuirementRepository.updateAllBrByProjectIdStatus(1, 1)).thenReturn(1);
		businessRequirementServiceImpl.updateAllByProjectIdStatus(1, 1);
	}
	@Test
	void findByIdTest(){
		BusinessRequirement brq = new BusinessRequirement();
		when(businessReuirementRepository.findById(1)).thenReturn(Optional.of(brq));
		businessRequirementServiceImpl.findById(1);
		when(businessReuirementRepository.findById(1)).thenReturn(null);
		businessRequirementServiceImpl.findById(1);
	}
	
	@Test
	void getBrIdAndBusReqIdTest() {
		businessRequirementServiceImpl.getBrIdAndBusReqId(1, session);
		
		UserLoginDto userData = mock(UserLoginDto.class);
		when(session.getAttribute("userData")).thenReturn(userData);
		Object[] obj = new Object[5];
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(businessReuirementRepository.getBrIdAndBusReqId(1)).thenReturn(list);
		businessRequirementServiceImpl.getBrIdAndBusReqId(1, session);
	}
	
	@Test
	void findBrStatusByProjectIdTest() {
		when(businessReuirementRepository.findbrStatusByProjectId(1)).thenReturn(1);
		businessRequirementServiceImpl.findBrStatusByProjectId(1);
	}
	

}
