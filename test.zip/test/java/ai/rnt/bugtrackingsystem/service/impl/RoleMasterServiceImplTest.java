package ai.rnt.bugtrackingsystem.service.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.repository.RoleMasterRepository;

@ExtendWith(MockitoExtension.class)
class RoleMasterServiceImplTest {
	
	@Mock
	RoleMasterRepository roleMaster;
	
	@InjectMocks
	RoleMasterServiceImpl roleMasterServiceImpl;

	
	@Test
	void findRoleOfEmployeeById() {
		roleMasterServiceImpl.findRoleOfEmployeeById(1);
	}

}
