package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import ai.rnt.bugtrackingsystem.entity.BugVideo;
import ai.rnt.bugtrackingsystem.repository.BugVideoRepository;

@ExtendWith(MockitoExtension.class)
class BugVideoServiceImplTest {

	@InjectMocks
	BugVideoServiceImpl bugVideoServiceImpl;
	
	@Mock
	BugVideoRepository bugVideoRepository;

	@Autowired
	MockMvc mockMvc;
	
	@Mock
	BugVideo bugVideo;
	
	@Test
	void saveRecordingTest() {
		BugVideo bugVideo = new BugVideo();
		String tx = "Test";
		bugVideo.setFileName(tx);
		bugVideo.setRecording(tx.getBytes());
		when(bugVideoRepository.save(bugVideo)).thenReturn(bugVideo);
		bugVideoServiceImpl.saveRecording(bugVideo);
	}
	
	
	@Test
	void getBugRecordingByBIdTEst() {
		when(bugVideoRepository.findByIdData(1)).thenReturn(bugVideo);
		bugVideoServiceImpl.getBugRecordingByBId(1);
	}
	@Test
	void deleteRecordingByBIdTEst() {
		when(bugVideoRepository.findByIdData(1)).thenReturn(bugVideo);
		bugVideoServiceImpl.deleteRecordingByBId(1);
		when(bugVideoRepository.findByIdData(1)).thenThrow(NullPointerException.class);
		bugVideoServiceImpl.deleteRecordingByBId(1);
	}
	
	@Test
	void getVideoDataByIdTest() {
		when(bugVideoRepository.findByIdData(1)).thenReturn(bugVideo);
		bugVideoServiceImpl.getVideoDataById(1);
		when(bugVideoRepository.findByIdData(1)).thenThrow(NullPointerException.class);
		bugVideoServiceImpl.getVideoDataById(1);
	}


}
