package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.dto.TestScriptDto;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestScript;
import ai.rnt.bugtrackingsystem.repository.RtmRepository;
import ai.rnt.bugtrackingsystem.repository.TestScriptRepository;
import ai.rnt.bugtrackingsystem.service.StatusService;
import ai.rnt.bugtrackingsystem.util.TlmsGeneralFunctionality;

@ExtendWith(MockitoExtension.class)
class TestScriptServiceImplTest {


	@Mock
	Model model;

	@Mock
	ModelMap mp;

	@Mock
	RedirectAttributes red;

	@Mock
	HttpSession session;

	@Mock
	HttpServletResponse response;

	@Mock
	HttpServletRequest request;

	@Mock
	TestScriptRepository testScriptRepository;

	@Mock
	EntityManager entityManager;

	@Mock
	RtmRepository rtmRepository;

	@Mock
	StatusService statusService;

	@Mock
	TlmsGeneralFunctionality tlmsGenFun;

	@InjectMocks
	TestScriptServiceImpl testScriptServiceImpl;
	
	
	List<TestScript> testScriptList;
	
	
	TestScript testScript;


	@Test
	void saveAllTest() {
		testScriptServiceImpl.saveAll(testScriptList);
	}

	@Test
	void getTestScriptStepsByIdTest() {
		testScriptServiceImpl.getTestScriptStepsById(1);
	}

	@Test
	void findStatusByProjectIdTest() {
		testScriptServiceImpl.findStatusByProjectId(1);
	}

	@Test
	void findByTestCaseTest() {
		testScriptServiceImpl.findByTestCase(1);
	}

	@Test
	void findTestScriptInfoByProjectIdTest() {
		testScriptServiceImpl.findTestScriptInfoByProjectId(1);
	}

	@Test
	void findTestcriptBySubmoduleTest() {
		testScriptServiceImpl.findTestcriptBySubmodule("br");
	}

	@Test
	void findTestScriptInfoByBugIdTest() {
		testScriptServiceImpl.findTestScriptInfoByBugId(1);
	}

	@Test
	void findByIdTest() {
		testScriptServiceImpl.findById(1);
		
		TestScript test = new TestScript();
		test.setCreatedBy(null);
	//	when(testScriptRepository.findById(1)).thenReturn(Optional.of(test));
		testScriptServiceImpl.findById(1);
	}

	@Test
	void getModuleSubModuleListByCaseIdTest() {
		testScriptServiceImpl.getModuleSubModuleListByCaseId(1);
	}

	@Test
	void findAllTest() {
		testScriptServiceImpl.findAll();
	}

	@Test
	void saveTest() {
		testScriptServiceImpl.save(testScript);
	}

	@Test
	void getTestScriptByIdTest() {
		Object[] obj = new Object[15];
		Integer num = 4;
		obj[0] = "FR_1.1";
		obj[9] = num;
		obj[10] = num;
		obj[8] = num;
		obj[11] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testScriptRepository.getTestScriptById(1)).thenReturn(list);
		testScriptServiceImpl.getTestScriptById(1);
		when(testScriptRepository.getTestScriptById(1)).thenReturn(null);
		testScriptServiceImpl.getTestScriptById(1);
	}

	@Test
	void ExpandForTestScriptTest() {
		Object[] obj = new Object[15];
		Integer num = 4;
		obj[7] = num;
		obj[8] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testScriptRepository.ExpandForTestScript("1", 1)).thenReturn(list);
		testScriptServiceImpl.ExpandForTestScript("1", 1);
		when(testScriptRepository.ExpandForTestScript("1", 1)).thenReturn(null);
		testScriptServiceImpl.ExpandForTestScript("1", 1);
	}

	@Test
	void FetchEditFromRtmIdTest() {
		Object[] obj = new Object[15];
		Integer num = 4;
		obj[7] = num;
		obj[8] = num;
		obj[9] = num;
		obj[10] = num;
		obj[11] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testScriptRepository.FetchEditFromRtmId(1, 1)).thenReturn(list);
		testScriptServiceImpl.FetchEditFromRtmId(1, 1);
		when(testScriptRepository.FetchEditFromRtmId(1, 1)).thenReturn(null);
		testScriptServiceImpl.FetchEditFromRtmId(1, 1);
	}

	@Test
	void findByTestCaseIdTest() {
		testScriptServiceImpl.findByTestCaseId(1);
	}

	@Test
	void findUsingIteratorTest() {
		TestScriptDto testScriptDto = new TestScriptDto();
		testScriptDto.setRequirementId("1");
		testScriptDto.setTestCaseId(1);
		List<TestScriptDto> list = new ArrayList<>();
		list.add(testScriptDto);
		testScriptServiceImpl.findUsingIterator("1", 1, list);
	}

	@Test
	void getExcelReportByIDTest() {
		Object[] obj = new Object[15];
		Integer num = 4;
		obj[7] = num;
		obj[8] = num;
		obj[9] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(obj);
		when(testScriptRepository.getExcelReportByID(1)).thenReturn(list);
		testScriptServiceImpl.getExcelReportByID(1);
		when(testScriptRepository.getExcelReportByID(1)).thenReturn(null);
		testScriptServiceImpl.getExcelReportByID(1);
	}

	@Test
	void updateAllByProjectId() {
		testScriptServiceImpl.updateAllByProjectId(1, 1);
	}

	@Test
	void deleteByIdTest() {
		TestCase testCase = new TestCase();
		testCase.setTestCase("br_1");
		TestScript test = new TestScript();
		test.setTestCase(testCase);
		when(testScriptRepository.findById(1)).thenReturn(Optional.of(test));
		testScriptServiceImpl.deleteById(1);
	}

	@Test
	void findTestScriptStatusTest() {
		when(testScriptRepository.findStatusByProjectId(1)).thenReturn("Aproved");
		testScriptServiceImpl.findTestScriptStatus(1);
		when(testScriptRepository.findStatusByProjectId(1)).thenReturn("");
		testScriptServiceImpl.findTestScriptStatus(1);
	}
}
