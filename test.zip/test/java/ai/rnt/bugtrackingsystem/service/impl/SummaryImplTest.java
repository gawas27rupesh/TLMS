package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.repository.ProjectTeamRepository;

@ExtendWith(MockitoExtension.class)
class SummaryImplTest {

	
	@Mock
	ProjectTeamRepository projectTeamRepository;
	
	@InjectMocks
	SummaryImpl summaryImpl;

	@Test
	void getAllDetailsTest() {
		Object[] ob = new Object[10];
		BigInteger num = BigInteger.ONE;
		ob[7] = num;
		ob[8] = num;
		ob[9] = num;
		List<Object[]> list = new ArrayList<>();
		list.add(ob);
		when(projectTeamRepository.getAllDetails(1)).thenReturn(list);
		summaryImpl.getAllDetails(1);
		when(projectTeamRepository.getAllDetails(1)).thenReturn(null);
		summaryImpl.getAllDetails(1);
	}
}
