package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.StatusByDeveloper;
import ai.rnt.bugtrackingsystem.repository.StatusByDeveloperRepository;


@ExtendWith(MockitoExtension.class)
class StatusByDeveloperServiceImplTest {

	
	@Mock
	StatusByDeveloperRepository StatusByDeveloperRepository; 
	
	@InjectMocks
	StatusByDeveloperServiceImpl statusByDeveloperServiceImpl;
	
	
	@Test
	void findAllTest() {
		ArrayList<StatusByDeveloper> list = new ArrayList<>();
		statusByDeveloperServiceImpl.findAll();
	}
	@Test
	void Test() {
		StatusByDeveloper sbd = new StatusByDeveloper();
		when(StatusByDeveloperRepository.findById(1)).thenReturn(Optional.of(sbd));
		statusByDeveloperServiceImpl.findById(1);
	}

}
