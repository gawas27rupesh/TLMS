package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.StatusByTester;
import ai.rnt.bugtrackingsystem.repository.StatusByTesterRepository;

@ExtendWith(MockitoExtension.class)
class StatusByTesterServiceImplTest {
	
	@Mock
	StatusByTesterRepository statusByTesterRepository;

	@InjectMocks
	StatusByTesterServiceImpl statusByTesterServiceImpl;

	
	@Test
	void findAllTest(){
		ArrayList<StatusByTester> list = new ArrayList<>();
		when(statusByTesterRepository.findAll()).thenReturn(list);
		statusByTesterServiceImpl.findAll();
	}
	@Test
	void findByIdTest(){
		StatusByTester st = new StatusByTester();
		when(statusByTesterRepository.findById(1)).thenReturn(Optional.of(st));
		statusByTesterServiceImpl.findById(1);
	}
}
