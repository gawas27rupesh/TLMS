package ai.rnt.bugtrackingsystem.service.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ai.rnt.bugtrackingsystem.entity.ProjectTeam;
import ai.rnt.bugtrackingsystem.repository.ProjectTeamRepository;


@ExtendWith(MockitoExtension.class)
class ProjectTemServiceImplTest {

	
	@Autowired
	MockMvc mockMvc;

	@Mock
	Model model;

	@Mock
	ModelMap mp;

	@Mock
	RedirectAttributes red;

	@Mock
	HttpSession session;

	@Mock
	HttpServletResponse response;

	@Mock
	HttpServletRequest request;
	@Mock
	ProjectTeamRepository repo34;
	
	@Mock
	EntityManager entityManager;
	List<ProjectTeam> projectlist;
	
	@InjectMocks
	ProjectTemServiceImpl projectTemServiceImpl;
	

	
	@Test
	void getAllProjectDveloperTeamDetailsByProjectIdTEst(){
		projectTemServiceImpl.getAllProjectDveloperTeamDetailsByProjectId(1);
	}
	@Test
	void getProjectByRoleAndStaffIdTest(){
		projectTemServiceImpl.getProjectByRoleAndStaffId(1, 1);
		projectTemServiceImpl.getProjectByRoleAndStaffId(null, 1);
	}
	
}
