package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import ai.rnt.bugtrackingsystem.entity.BugSeverity;
import ai.rnt.bugtrackingsystem.repository.BugSeverityRepository;

@ExtendWith(MockitoExtension.class)
class BugSeverityServiceImplTest {

	@Autowired
	MockMvc mockMvc;
	
	@Mock
	BugSeverityRepository bugSeverityRepository;

	@InjectMocks
	BugSeverityServiceImpl bugSeverityServiceImpl;
	
	
	@Test
	void findAllTest() {
		ArrayList<BugSeverity> list = new ArrayList<>();
		when(bugSeverityRepository.findAll()).thenReturn(list);
		bugSeverityServiceImpl.findAll();
	}
	@Test
	void findByIdTest() {
		BugSeverity bs = new BugSeverity();
		when(bugSeverityRepository.findById(1)).thenReturn(Optional.of(bs));
		bugSeverityServiceImpl.findById(1);
	}
}
