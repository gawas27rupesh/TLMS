package ai.rnt.bugtrackingsystem.service.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.repository.StatusRepository;

@ExtendWith(MockitoExtension.class)
class StatusServiceImplTest {

	
	@Mock
	private StatusRepository repo;
	
	@InjectMocks
	StatusServiceImpl statusServiceImpl;

	
	@Test
	void getAllStatusTest(){
		statusServiceImpl.getAllStatus();
	}
	@Test
	void findByIdTest(){
		statusServiceImpl.findById(1);
	}

}
