package ai.rnt.bugtrackingsystem.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.BugDefectType;
import ai.rnt.bugtrackingsystem.repository.BugDefectTypeRepository;

@ExtendWith(MockitoExtension.class)
class BugDefectTypeServiceImplTest {

	@Mock
	BugDefectTypeRepository bugDefectTypeRepository;

	@InjectMocks
	BugDefectTypeServiceImpl bugDefectTypeServiceImpl;
	
	@Test
	void findAllTest() {
		ArrayList<BugDefectType> list = new ArrayList<>();
		when(bugDefectTypeRepository.findAll()).thenReturn(list);
		bugDefectTypeServiceImpl.findAll();
	}
	
	@Test
	void findByIdTest() {
		BugDefectType bdt = new BugDefectType();
		when(bugDefectTypeRepository.findById(1)).thenReturn(Optional.of(bdt));
		bugDefectTypeServiceImpl.findById(1);
	}

}
