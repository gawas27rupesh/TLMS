package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.Status;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestScenario;
import ai.rnt.bugtrackingsystem.entity.TestScript;

@ExtendWith(MockitoExtension.class)
public class TestCaseTest {

	private Logger log = LoggerFactory.getLogger(TestCaseTest.class);

	TestCase testCase = new TestCase();
	Rtm rtm = new Rtm();
	ProjectMaster projectMaster = new ProjectMaster();
	List<Bug> bug = new ArrayList<Bug>();
	TestScenario tetsScenario = new TestScenario();
	ArrayList<TestScript> testScript = new ArrayList<TestScript>();
	Status status = new Status();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;

	@Test
	public void setterTest() {

		testCase.setRtm(rtm);
		testCase.setTestCaseId("TC_1");
		testCase.setTestCase("Add testCase");
		testCase.setProject(projectMaster);
		testCase.setBug(bug);
		testCase.setStatus("complete");
		testCase.setTestScenario(tetsScenario);
		testCase.setTestScript(testScript);
		testCase.setCreatedBy(1);
		testCase.setCreatedDate(createdDate);
		testCase.setUpdatedBy(1);
		testCase.setUpdatedDate(updatedDate);
		testCase.setSheetstatus(status);
	}

	@Test
	void getterTest() {
		testCase.getRtm();
		testCase.getTestCaseId();
		testCase.getTestCase();
		testCase.getProject();
		testCase.getBug();
		testCase.getStatus();
		testCase.getTestScenario();
		testCase.getTestScript();
		testCase.getCreatedBy();
		testCase.getCreatedDate();
		testCase.getUpdatedBy();
		testCase.getUpdatedDate();
		testCase.getTestResult();
		testCase.getCaseId();
		testCase.getSheetstatus();
		testCase.toString();
	}

	@Test
	public void testCaseConstructor() {
		Integer caseId = 1;
		String testCaseId = "TC001";
		String module = "Login";
		String subModule = "Password";
		String testCase = "Verify user can login with valid credentials";
		Integer createdBy = 1;
		LocalDateTime createdDate = LocalDateTime.now();
		Integer updatedBy = 2;
		LocalDateTime updatedDate = LocalDateTime.now();
		Integer deletedBy = 3;
		LocalDateTime deletedDate = LocalDateTime.now();

//		TestCase testCaseObj = new TestCase(caseId, testCaseId, module, subModule, testCase, createdBy, createdDate,
//				updatedBy, updatedDate, deletedBy, deletedDate);
//
//		assertEquals(caseId, testCaseObj.getCaseId());
//		assertEquals(testCaseId, testCaseObj.getTestCaseId());
//		assertEquals(testCase, testCaseObj.getTestCase());
//		assertEquals(createdBy, testCaseObj.getCreatedBy());
//		assertEquals(createdDate, testCaseObj.getCreatedDate());
//		assertEquals(updatedBy, testCaseObj.getUpdatedBy());
//		assertEquals(updatedDate, testCaseObj.getUpdatedDate());
	}

}
