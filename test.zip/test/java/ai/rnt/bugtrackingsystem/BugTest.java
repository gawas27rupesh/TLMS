package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.entity.BugDefectType;
import ai.rnt.bugtrackingsystem.entity.BugImage;
import ai.rnt.bugtrackingsystem.entity.BugLink;
import ai.rnt.bugtrackingsystem.entity.BugPriority;
import ai.rnt.bugtrackingsystem.entity.BugSeverity;
import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.ProjectTeam;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.StatusByDeveloper;
import ai.rnt.bugtrackingsystem.entity.StatusByTester;
import ai.rnt.bugtrackingsystem.entity.TestCase;
import ai.rnt.bugtrackingsystem.entity.TestResult;
import ai.rnt.bugtrackingsystem.entity.TestScenario;
import ai.rnt.bugtrackingsystem.entity.TestScript;

@ExtendWith(MockitoExtension.class)
public class BugTest {

	private Logger log = LoggerFactory.getLogger(BugTest.class);

	Bug bug = new Bug();
	BugDefectType bugDefectType = new BugDefectType();
	List<BugImage> bugImage = new ArrayList<BugImage>();
	List<BugLink> bugLink = new ArrayList<BugLink>();
	BugPriority bugPriority = new BugPriority();
	BugSeverity bugSeverity = new BugSeverity();
	EmployeeMaster employeeMaster = new EmployeeMaster();
	ProjectMaster projectMaster = new ProjectMaster();
	ProjectTeam projectTeam = new ProjectTeam();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	Rtm rtm = new Rtm();
	StatusByDeveloper statusByDeveloper = new StatusByDeveloper();
	StatusByTester statusByTester = new StatusByTester();
	TestCase testCase = new TestCase();
	TestResult testResult = new TestResult();
	TestScenario testScenario = new TestScenario();
	TestScript testScript = new TestScript();
			
	@Test
	void setterTest() {
		bug.setAssignedDate("12-01-2023");
		bug.setBugDefectType(bugDefectType);
		//bug.setBugId("Bug_1");
		bug.setBugImage(bugImage);
		bug.setBugLink(bugLink);
		bug.setBugPriority(bugPriority);
		bug.setBugSeverity(bugSeverity);
		bug.setClosedDate("22-01-2023");
		bug.setCreatedBy(1304);
		bug.setCreatedDate(createdDate);
		bug.setDefectArea("Front End");
		bug.setDescription("Bug Id Validation");
		bug.setDeveloperComment("Resolved");
		bug.setEmployeeMaster(employeeMaster);
		//bug.setId(1);
		bug.setPriority("P1");
		bug.setProjectMaster(projectMaster);
		bug.setProjectTeam(projectTeam);
		bug.setReopenDate("24-01-2023");
		bug.setRtm(rtm);
		bug.setSeverity("Critical");
		bug.setStatByDeveloper(statusByDeveloper);
		bug.setStatByTester(statusByTester);
		bug.setStatusByDeveloper("Resolved");
		bug.setStatusByTester("Open");
		bug.setTestCase(testCase);
		bug.setTesterComment("Added bug ");
		bug.setTestResult(testResult);
		bug.setTestRound(1);
		bug.setTestScenario(testScenario);
		bug.setTestScript(testScript);
		bug.setUpdatedBy(1304);
		bug.setUpdatedDate(updatedDate);
		bug.setResolvedDate("22-01-2023");
		
	}
	
	@Test
	void getterTest() {
		bug.getAssignedDate();
		bug.getBugDefectType();
		bug.getBugId();
		bug.getBugImage();
		bug.getBugLink();
		bug.getBugPriority();
		bug.getBugSeverity();
		bug.getClosedDate();
		bug.getCreatedBy();
		bug.getCreatedDate();
		bug.getDefectArea();
		bug.getDescription();
		bug.getDeveloperComment();
		bug.getEmployeeMaster();
		//bug.getId();
		bug.getPriority();
		bug.getProjectMaster();
		bug.getProjectTeam();
		bug.getReopenDate();
		bug.getRtm();
		bug.getSeverity();
		bug.getStatByDeveloper();
		bug.getStatByTester();
		bug.getStatusByDeveloper();
		bug.getStatusByTester();
		bug.getTestCase();
		bug.getTesterComment();
		bug.getTestResult();
		bug.getTestRound();
		bug.getTestScenario();
		bug.getTestScript();
		bug.getUpdatedBy();
		bug.getUpdatedDate();
		bug.getResolvedDate();
	}
}
