package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.StatusByDeveloper;

@ExtendWith(MockitoExtension.class)

public class StatusByDeveloperTest {
	//private Logger log = LoggerFactory.getLogger(RtmTest.class);

	StatusByDeveloper statusByDeveloper = new StatusByDeveloper();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;

	@Test
	void setterTest() {
		statusByDeveloper.setCreatedBy(1);
		statusByDeveloper.setCreatedDate(createdDate);
		statusByDeveloper.setStatusByDeveloper("Resolved");
		statusByDeveloper.setStatusDeveloperId(1);
		statusByDeveloper.setUpdatedBy(1);
		statusByDeveloper.setUpdatedDate(updatedDate);
	}

	@Test
	void getterTest() {
		statusByDeveloper.getCreatedBy();
		statusByDeveloper.getCreatedDate();
		statusByDeveloper.getStatusByDeveloper();
		statusByDeveloper.getStatusDeveloperId();
		statusByDeveloper.getUpdatedBy();
		statusByDeveloper.getUpdatedDate();
	}
}
