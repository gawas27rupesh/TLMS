package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.Designation;
import ai.rnt.bugtrackingsystem.entity.EmployeeMaster;

@ExtendWith(MockitoExtension.class)
public class DesignationTest {

	private Logger log = LoggerFactory.getLogger(RtmTest.class);
	Designation designation = new Designation();
	EmployeeMaster employeeMaster = new EmployeeMaster();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;

	@Test
	void setterTest() {
		designation.setCreatedBy(1);
		designation.setCreatedDate(createdDate);
		designation.setDesignation("tester");
		designation.setEmployeeMaster(employeeMaster);
		designation.setUpdatedBy(1);
		designation.setUpdatedDate(updatedDate);
	}

	@Test
	void getterTest() {
		designation.getCreatedBy();
		designation.getCreatedDate();
		designation.getDesignation();
		designation.getEmployeeMaster();
		designation.getUpdatedBy();
		designation.getUpdatedDate();
		designation.getId();
	}
}
