
package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ai.rnt.bugtrackingsystem.entity.ProjectMaster;
import ai.rnt.bugtrackingsystem.entity.Rtm;
import ai.rnt.bugtrackingsystem.entity.TestScenario;

/**
 * @author Madhuri Patil
 * @Date 31th Jan 2023
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
public class TestScenarioTest {

	private Logger log = LoggerFactory.getLogger(TestScenarioTest.class);

	/*
	 * @Autowired private TestScenarioService testScenario1;
	 */
	Rtm rtm = new Rtm();
	TestScenario testScenario = new TestScenario();
	ProjectMaster projMaster = new ProjectMaster();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;

	@Test
	public void setterTest() {
		testScenario.setTestScenarioId("TS_1");
		testScenario.setTestScenarioDescription("Add the test scenario data");
		testScenario.setCreatedBy(1);
		testScenario.setCreatedDate(createdDate);
		testScenario.setUpdatedBy(1);
		testScenario.setUpdatedDate(createdDate);
		testScenario.setProjectMaster(projMaster);
		testScenario.setRtm(rtm);
	}

	@Test
	public void getterTest() {
		testScenario.getTestScenarioId();
		testScenario.getTestScenarioDescription();
		testScenario.getCreatedBy();
		testScenario.getCreatedDate();
		testScenario.getUpdatedBy();
		testScenario.getUpdatedDate();
		testScenario.getProjectMaster();
		testScenario.getRtm();
		testScenario.getSheetStatus();
		testScenario.getScenarioId();
		testScenario.toString();
	}

//	@Test
//	void testAllArgsConstructor() {
//		TestScenario ts = new TestScenario("1", "Test Scenario Description", 1, LocalDateTime.now(), 2,
//				LocalDateTime.now(), 3, LocalDateTime.now());
//		assertNotNull(ts);
//		assertEquals("1", ts.getTestScenarioId());
//		assertEquals("Test Scenario Description", ts.getTestScenarioDescription());
//		assertEquals(1, ts.getCreatedBy());
//		assertEquals(2, ts.getUpdatedBy());
//
//	}

}