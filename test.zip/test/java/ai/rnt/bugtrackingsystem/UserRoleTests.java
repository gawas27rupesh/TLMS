/*
 * package ai.rnt.bugtrackingsystem;
 * 
 * import javax.persistence.EntityManager; import
 * javax.transaction.Transactional;
 * 
 * import org.junit.jupiter.api.Test; import org.slf4j.Logger; import
 * org.slf4j.LoggerFactory; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * import ai.rnt.bugtrackingsystem.entity.RoleMaster;
 * 
 *//**
	 * @author Pankaj Chauhan
	 * @Date 25th July 2022
	 * @version 1.0
	 *//*
		 * @SpringBootTest class UserRoleTests {
		 * 
		 * private Logger log = LoggerFactory.getLogger(UserRoleTests.class);
		 * 
		 * 
		 * @Autowired private EntityManager entityManager;
		 * 
		 * @Test
		 * 
		 * @Transactional void checkUserAndPassword() { RoleMaster r1 =
		 * entityManager.find(RoleMaster.class, 1); System.out.println(r1);
		 * log.info("{}", r1); System.out.println(r1.getEmployees()); }
		 * 
		 * }
		 */