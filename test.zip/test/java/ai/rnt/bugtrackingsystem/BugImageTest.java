package ai.rnt.bugtrackingsystem;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import ai.rnt.bugtrackingsystem.entity.Bug;
import ai.rnt.bugtrackingsystem.entity.BugImage;
@ExtendWith(MockitoExtension.class)
public class BugImageTest {

	//private Logger log = LoggerFactory.getLogger(RtmTest.class);
	
	BugImage bugImage = new BugImage();
	Bug bug = new Bug();
	LocalDateTime createdDate;
	LocalDateTime updatedDate;
	@Test
	void setterTest() {
		bugImage.setBug(bug);
		bugImage.setCreatedBy(1304);
		bugImage.setCreatedDate(createdDate);
		bugImage.setFileName("BugFile");
		bugImage.setFiletype(".pdf");
		bugImage.setImage(null);
		bugImage.setUpdatedBy(1);
		bugImage.setUpdatedDate(updatedDate);
	}
	@Test
	void getterTest() {
		bugImage.getBug();
		bugImage.getCreatedBy();
		bugImage.getCreatedDate();
		bugImage.getFileName();
		bugImage.getFiletype();
		bugImage.getImage();
		bugImage.getUpdatedBy();
		bugImage.getUpdatedDate();
		bugImage.getImgId();
	}
}
